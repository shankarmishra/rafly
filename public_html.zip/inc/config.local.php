<?php
define('DB_DSN',  'mysql:host=localhost;dbname=u668573499_rafly_official;charset=utf8mb4');
define('DB_USER', 'u668573499_adminRafly');
define('DB_PASS', 'WeAreRafly.in.MySql@1407');
define('ADMIN_BASE_PATH', '/v9q7x2m4p');