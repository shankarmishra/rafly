<?php
require __DIR__ . '/inc/bootstrap.php';

// One-shot page: reachable only immediately after a successful POST.
// Without this guard it would be a crawlable, shareable "success" URL.
if (empty($_SESSION['lead_ok'])) {
    header('Location: /', true, 302);
    exit;
}
unset($_SESSION['lead_ok']);

$page = [
    'id'        => 'contact',
    'title'     => 'Thank You | ' . SITE_NAME,
    'desc'      => 'Your request has been received. The Rafly team will be in touch shortly.',
    'bodyClass' => 'page-thank-you',
    'noindex'   => true,
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>

<main id="main" class="thanks-wrap">
    <div class="thanks-card" data-animate="scale-in">
        <div class="thanks-icon"><?= icon('check', 'icon-xl') ?></div>
        <h1>Thank you — we've got your request.</h1>
        <p>
            A member of the <?= e(SITE_NAME) ?> team will review your requirements and get
            back to you within one business day.
        </p>
        <p class="thanks-meta">
            Need something urgently? Message us directly and we'll pick it up straight away.
        </p>
        <div class="thanks-actions">
            <a class="btn-primary" href="<?= e(whatsapp_link('Hi Rafly team, I just submitted an enquiry through your website.')) ?>"
               target="_blank" rel="noopener">
                <?= icon('whatsapp') ?> Chat on WhatsApp
            </a>
            <a class="btn-dark-pill" href="/">Back to homepage</a>
        </div>
    </div>
</main>

<?php require __DIR__ . '/partials/tail.php'; ?>
