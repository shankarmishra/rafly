<?php
require __DIR__ . '/inc/bootstrap.php';

/**
 * A single article.
 *
 * This page is what makes the Insights section more than a list of headlines:
 * every post body already lived in the database, written and complete, with no
 * page that rendered it. Both the "Read More" links and the admin "View" button
 * pointed at a URL that returned 404.
 *
 * Bodies are sanitised by sanitize_html() on save (admin/posts.php) AND AGAIN
 * ON RENDER below. The save-time pass is not sufficient on its own: it is not
 * the only writer — inc/tools/seed-posts.php inserts bodies untouched — and
 * rows can predate the allow-list. Sanitising on read is the layer that holds
 * regardless of how a row arrived, and it is idempotent, so it costs a parse and
 * nothing else.
 */

$slug = trim((string)($_GET['post'] ?? ''));

/**
 * Resolve the post before emitting a single byte, because a miss has to be able
 * to send a 404 status and swap in the whole 404 page. Anything printed first
 * would lock in a 200.
 *
 * status/published_at are both checked: a post scheduled for the future is not
 * public yet, and 'published' alone would leak it.
 */
$post = null;

if ($slug !== '' && db_available()) {
    $post = one(
        "SELECT id, slug, title, tag, excerpt, meta_desc, body, published_at,
                updated_at, read_minutes
           FROM posts
          WHERE slug = ?
            AND status = 'published'
            AND published_at IS NOT NULL
            AND published_at <= now()",
        [$slug]
    );
}

if ($post === null) {
    // Reuse the real 404 page rather than printing a bespoke "not found" here,
    // so a mistyped slug looks identical to any other dead URL.
    require __DIR__ . '/404.php';
    exit;
}

$published = !empty($post['published_at']) ? strtotime((string)$post['published_at']) : null;

$page = [
    'id'        => 'insights',
    'title'     => $post['title'] . ' | ' . SITE_NAME,
    'desc'      => (string)($post['meta_desc'] ?: $post['excerpt']),
    'bodyClass' => 'page-insight',
    'styles'    => ['insights', 'insight'],
    'ogType'    => 'article',

    // The content varies by slug, so the canonical must be set explicitly —
    // otherwise every article claims to be /insights/{first-one-crawled} and
    // Google indexes one while dropping the rest.
    'canonical' => 'insights/' . rawurlencode((string)$post['slug']),

    'articleMeta' => [
        'published' => $post['published_at'],
        'modified'  => $post['updated_at'] ?: $post['published_at'],
        'section'   => $post['tag'] ?: null,
    ],

    'schema'    => [
        schema_article($post),
        schema_breadcrumbs($crumbs = [
            ['name' => 'Home',     'url' => '/'],
            ['name' => 'Insights', 'url' => '/insights'],
            ['name' => (string)$post['title'], 'url' => '/insights/' . rawurlencode((string)$post['slug'])],
        ]),
    ],
];

require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';

/**
 * Up to three more posts, newest first, excluding this one. Pulled before the
 * article renders so a database hiccup half-way down the page cannot leave a
 * half-written document.
 */
$more = all(
    "SELECT slug, title, tag, excerpt
       FROM posts
      WHERE status = 'published'
        AND published_at IS NOT NULL
        AND published_at <= now()
        AND id <> ?
   ORDER BY published_at DESC
      LIMIT 3",
    [(int)$post['id']]
);
?>
<main id="main" class="insight-main">

    <article class="insight-article">
        <?= breadcrumbs($crumbs) ?>

        <header class="insight-header">
            <?php if (!empty($post['tag'])): ?>
                <div class="blog-card-tag insight-tag"><?= e((string)$post['tag']) ?></div>
            <?php endif; ?>

            <h1><?= e((string)$post['title']) ?></h1>

            <?php if (!empty($post['excerpt'])): ?>
                <p class="insight-standfirst"><?= e((string)$post['excerpt']) ?></p>
            <?php endif; ?>

            <p class="insight-meta">
                <?php if ($published !== null): ?>
                    <time datetime="<?= e(date(DATE_ATOM, $published)) ?>"><?= e(date('j F Y', $published)) ?></time>
                <?php endif; ?>
                <?php if ($published !== null && (int)$post['read_minutes'] > 0): ?>
                    <span aria-hidden="true">·</span>
                <?php endif; ?>
                <?php if ((int)$post['read_minutes'] > 0): ?>
                    <span><?= (int)$post['read_minutes'] ?> min read</span>
                <?php endif; ?>
            </p>
        </header>

        <?php
        /* Sanitised HERE, at render, not merely trusted from the save path.

           admin/posts.php does call sanitize_html() on save, but that is not the
           only way a row gets into this table: inc/tools/seed-posts.php inserts
           bodies with no sanitiser at all, and inc/sanitize.php notes that rows
           may predate the allow-list entirely. Relying on "every writer sanitises"
           means this render breaks the day someone adds a sixth writer.

           sanitize_html() is idempotent — already-clean markup passes through
           unchanged — so running it again here costs one parse and makes the
           render site correct independent of every write path, present and
           future. e() would be wrong: it would print the markup as visible text
           instead of rendering it. */
        ?>
        <div class="insight-body"><?= sanitize_html((string)$post['body']) ?></div>

        <footer class="insight-cta">
            <h2>Want this handled for you?</h2>
            <p>
                Every Rafly package bundles web, content, marketing, security and
                e-commerce support under one team — so the things in this article
                actually get done rather than added to a list.
            </p>
            <div class="insight-cta-actions">
                <button class="btn-primary" type="button" data-modal-open="consultationModal">
                    Get a free consultation
                </button>
                <a class="btn-dark-pill"
                   href="<?= e(whatsapp_link('Hi Rafly team, I just read "' . $post['title'] . '" and would like to know more.')) ?>"
                   target="_blank" rel="noopener">
                    <?= icon('whatsapp') ?> Message us
                </a>
            </div>
        </footer>
    </article>

    <?php if ($more): ?>
        <section class="insight-more">
            <h2>More from the team</h2>
            <div class="blog-grid">
                <?php foreach ($more as $m): ?>
                    <article class="blog-card">
                        <?php if (!empty($m['tag'])): ?>
                            <div class="blog-card-tag"><?= e((string)$m['tag']) ?></div>
                        <?php endif; ?>
                        <h4><?= e((string)$m['title']) ?></h4>
                        <p><?= e(str_cut((string)$m['excerpt'], 130)) ?></p>
                        <a href="/insights/<?= e(rawurlencode((string)$m['slug'])) ?>" class="blog-read-more">
                            Read More <?= icon('arrow-right') ?>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php require __DIR__ . '/partials/tail.php'; ?>
