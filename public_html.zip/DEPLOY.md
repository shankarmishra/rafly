# Deploying to Hostinger

Everything in this repository currently runs only on the development machine.
`rafly.in` is still serving the old site — that is why none of the new work is
visible there. This document is what closes that gap.

Read it once end to end before starting. The order matters: the database has to
exist before the site can talk to it.

---

## Running locally

```
serve.bat
```

which is just `php -S 127.0.0.1:8899 router.php`. **The `router.php` argument
is required.** The site uses clean URLs (`/about`, `/pricing`,
`/web-development`, ...) that are normally resolved by the `.htaccess`
rewrite rules below — PHP's built-in server never reads `.htaccess`, so
without `router.php` every clean URL falls through to the homepage instead of
404ing or rendering the right page, and the contact form's `/submit` action
silently stops saving leads. `router.php` reproduces the same rewrite/redirect
rules for local use only; Apache/LiteSpeed never load it. If you edit
`.htaccess`, mirror the change in `router.php` (its header comment explains
the mapping).

---

## 0. What you are deploying

| | |
|---|---|
| Runtime | PHP 8.1 or newer (8.3 recommended) |
| Database | MySQL / MariaDB |
| Server | LiteSpeed or Apache — **`.htaccess` must be honoured, and `mod_rewrite` must be enabled** |
| Payload | ~2.5 MB, images included |
| Composer | none — there are no dependencies to install |
| Build step | none — nothing to compile |

**`mod_rewrite` is not optional.** Every page on the site is reached through a
clean URL (`/about`, `/pricing`, `/web-development`, the `/submit` form
action, `/sitemap.xml`, ...) that only exists because of the rewrite rules in
`.htaccess`. Without `mod_rewrite` enabled, none of those URLs resolve —
visitors get 404s site-wide and the contact form cannot submit. Hostinger's
LiteSpeed stack has it on by default; if you move hosts, confirm it explicitly.

**Images ship with the code.** All photographs live in `assets/photos/` and are
tracked in git, so uploading the project uploads them too. There is no separate
image deployment step and no CDN to configure.

**LiteSpeed matters.** `uploads/.htaccess` blocks PHP execution inside the
uploads directory, which is a real security control. LiteSpeed and Apache honour
it; **nginx ignores `.htaccess` entirely**. Hostinger's shared stack is
LiteSpeed, so this works — but if you ever move to an nginx host, that
protection silently disappears and must be reimplemented in the server config.

---

## 1. PHP version

hPanel → **Advanced → PHP Configuration**.

- Set PHP to **8.1+**.
- On the **PHP extensions** tab confirm these are enabled:
  `pdo_mysql`, `mbstring`, `fileinfo`, `gd`, `json`, `openssl`.

**`pdo_mysql` is the one to double-check.** It is not always on by default, and
its absence does not produce an error page — `db_available()` catches the
failure and every database-backed section simply renders empty. The symptom is
a site that loads fine but has no articles, no case studies and no testimonials,
with articles 404ing. If you see that, this extension is the first thing to
check. (This exact failure showed up during local testing, which is how it
earned a mention here.)

`fileinfo` is not optional either — media uploads use it to sniff real file
types rather than trusting the browser. `gd` is needed for image dimension checks.

---

## 2. Create the database

hPanel → **Databases → MySQL Databases**.

1. Create a database (e.g. `u123456789_rafly`).
2. Create a user with a long random password. **Do not reuse your hPanel
   password.**
3. Grant the user all privileges on that database.
4. Write down the four values — you need them in step 4:
   - database name
   - username
   - password
   - host (usually `localhost`)

---

## 3. Import the schema

**Preferred — let the migration runner do it.** If you have SSH (step 6), this
is one command and it records what it applied:

```bash
cd ~/public_html && php inc/migrate.php
```

It detects the driver, picks `inc/migrations/mysql/`, applies files in order,
and writes to `schema_migrations` so a second run is a no-op.

**Otherwise** — hPanel → **Databases → phpMyAdmin** → select your database →
**Import**, and import the files in `inc/migrations/mysql/` **in filename
order**. Order is not optional: later files reference tables earlier ones create.

> This whole path has been run for real against MariaDB 12.3 on a clean
> database: all three migrations applied, the site seeded, and create / edit /
> delete exercised through the admin. It is not a paper port.

Then confirm the table list is complete — you should see `users`, `roles`,
`user_roles`, `admin_sessions`, `login_attempts`, `leads`, `posts`,
`case_studies`, `testimonials`, `bundles`, `bundle_points`, `media`,
`settings`, `audit_log`, `schema_migrations`.

---

## 4. Create `inc/config.local.php` **on the server**

This file holds your database credentials. It is in `.gitignore` and **must
never be committed**. Create it directly on the server, after uploading.

```php
<?php
define('DB_DSN',  'mysql:host=localhost;dbname=YOUR_DB_NAME;charset=utf8mb4');
define('DB_USER', 'YOUR_DB_USER');
define('DB_PASS', 'YOUR_DB_PASSWORD');
```

`charset=utf8mb4` is required, not cosmetic — the older `utf8` alias silently
truncates four-byte characters (emoji, several Indic sequences).

---

## 5. Upload the files

hPanel → **Files → File Manager**, or FTP. Everything goes into `public_html/`.

Upload the whole project **except**:

```
.git/          version control history
private/       never web-reachable
node_modules/  does not exist here, but never upload one if it appears
```

If you upload a zip and extract in File Manager, delete the zip afterwards.

**Directory permissions** — set `uploads/` to **755**, owned by the web user.
The admin media library writes here. Files inside it are created 0644 by the
application.

---

## 6. Create your admin user

Hostinger shared plans usually expose SSH on Business tier and above. If you
have SSH:

```bash
cd ~/public_html
php inc/tools/create-user.php you@example.com "Your Name" admin
```

It prompts for a password (minimum 12 characters) and never takes it as an
argument — arguments show up in shell history and the process list.

**No SSH?** Run the same file once via a browser is *not* possible by design —
it refuses to run outside CLI, deliberately, so that a forgotten web installer
can never become an account-creation backdoor. Instead, use hPanel's **Cron
Jobs** to run the command once, then delete the cron entry.

---

## 7. Force HTTPS

hPanel → **Security → SSL** — install the free certificate and enable
**Force HTTPS**.

This is load-bearing, not decorative: session cookies are only marked `Secure`
when the request is HTTPS (`inc/bootstrap.php`). Over plain HTTP the admin
session cookie can travel in the clear.

---

## 8. Point the domain

If `rafly.in` is not already pointing at this hosting account, update the
nameservers at your registrar to Hostinger's, then wait for propagation
(minutes to a few hours).

---

## 9. Post-deploy checklist

Work through all of it. Anything that fails here is much cheaper to find now
than from a customer.

**Public site**
- [ ] `https://rafly.in/` loads over HTTPS with a valid padlock
- [ ] **Photographs appear** on the homepage, About, Insights and all five
      service pages — this is the specific thing that was missing before
- [ ] `https://rafly.in/about` — hero is centred, not split across two columns
- [ ] All five service pages load at their clean URL: `/web-development`,
      `/web-security`, `/marketing-advertisement`, `/content-creation`,
      `/ecommerce-support`
- [ ] `https://rafly.in/pricing` and `https://rafly.in/case-studies` load
- [ ] The old URLs 301 to the clean ones — `/about.php` → `/about`,
      `/service.php?service=web-development` → `/web-development`
- [ ] Insights lists articles and each "Read More" opens a full article at
      `/insights/<slug>`
- [ ] `https://rafly.in/sitemap.xml` returns XML
- [ ] A deliberately wrong URL returns the styled 404, not a server error
- [ ] Submit the contact form once (its action is `/submit`) and confirm the
      enquiry appears in the admin with a name and email

**Admin**
- [ ] `/admin/login.php` is styled (correct fonts, icons in the sidebar). If it
      looks like plain unstyled HTML, `asset()` paths are not resolving — check
      that the site is at the domain root and not in a subdirectory
- [ ] You can sign in
- [ ] Visiting `/admin/leads.php` **while signed out** redirects to the login page
- [ ] Uploading an image in Media works, and the file appears under `/uploads/`

**Security**
- [ ] `https://rafly.in/inc/config.local.php` returns **403 or 404** — never the
      file contents. If you can read it, stop and fix `.htaccess` before going
      further
- [ ] `https://rafly.in/private/` is not listable
- [ ] Error pages show no file paths or stack traces

---

## 10. If something breaks

**Blank white page.** PHP fatal error with display off. Read the error log in
hPanel → **Advanced → Error Log**. Do not switch debug on to diagnose a live
site — the log has the same information without showing it to visitors.

**"Database connection failed."** `inc/config.local.php` is missing, has a typo,
or the DB user lacks privileges. Re-check all four values from step 2.

**Admin renders as unstyled HTML.** Asset paths are root-relative (`/admin/...`).
This breaks if the site is installed in a subdirectory rather than at the domain
root.

**Images missing.** Confirm `assets/photos/` actually uploaded — some FTP
clients skip binary files on a failed transfer without reporting it. Compare the
file count against the repository.

---

## What is deliberately not automated

There is no deploy script that takes your hosting credentials, and that is on
purpose. Anything holding a password to your production host is a credential
store, and it does not belong in a git repository or in a chat transcript. The
manual path above is short, and you keep control of the secrets.
