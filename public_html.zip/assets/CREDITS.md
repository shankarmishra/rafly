# Asset credits & licences

Every third-party asset used on this site, with its source and licence.
**Only commercially-free licences are permitted here** (CC0 / MIT / ISC / OFL / Apache-2.0).
Nothing is hotlinked — everything is self-hosted, which is also why the site's
Content-Security-Policy can forbid all third-party origins.

Add a row here **when you download the asset**, not afterwards.

---

## Libraries

**None.** The site has zero third-party JavaScript. All behaviour lives in
`js/app.js` and `js/motion.js`, both hand-written and dependency-free.

> An earlier version of this file listed three.js r170 at
> `vendor/three/three.module.min.js`, and a "3D hero scene" at
> `js/three-scene.js`. **Neither file has ever existed in this repository.** The
> hero is pure SVG and CSS (`index.php`, `css/pages/home.css`). Those rows were
> aspirational, not descriptive, and are removed — a credits file that lists
> dependencies you do not ship is worse than no credits file, because it is the
> one document a client or auditor will trust.
>
> `.htaccess` still declares `.glb`/`.gltf`/`.wasm` MIME types from that plan.
> They are harmless and cost nothing, so they stay in case 3D is revisited.

## Fonts

| Family | Source | Licence | Notes |
|---|---|---|---|
| Space Grotesk | https://fonts.google.com/specimen/Space+Grotesk | SIL OFL 1.1 | Headings. Variable, latin subset — `vendor/fonts/space-grotesk-var.woff2` |
| Inter | https://fonts.google.com/specimen/Inter | SIL OFL 1.1 | Body. Variable, latin subset — `vendor/fonts/inter-var.woff2` |

Both downloaded from Google Fonts and self-hosted. No requests are made to
`fonts.googleapis.com` or `fonts.gstatic.com` at runtime.

## Icons

| Set | Source | Licence | Notes |
|---|---|---|---|
| Lucide | https://lucide.dev | ISC | All UI icons in `vendor/icons/sprite.svg` (`#i-*`, stroked) |
| Simple Icons | https://simpleicons.org | CC0 1.0 | Brand marks only — LinkedIn, Instagram, Facebook, WhatsApp, YouTube (filled) |

These replaced Font Awesome, which was the site's only external dependency and
carried attribution requirements.

## Illustrations & textures

| Asset | Source | Licence | Notes |
|---|---|---|---|
| Section illustrations | Original work | Owned by Rafly | Hand-authored SVG in `partials/illustrations.php` |
| Ornamental motif | Original work | Owned by Rafly | Generated SVG in `css/08-texture.css` |
| Grain / mesh / grid textures | Original work | Owned by Rafly | CSS gradients and SVG `feTurbulence`, no image files |
| Hero scene | Original work | Owned by Rafly | SVG + CSS in `index.php` / `css/pages/home.css` |
| `favicon.svg` | Original work | Owned by Rafly | **Stopgap** — a plain "R" monogram, NOT the real Rafly mark. See below. |

## Photography

All in `assets/photos/`, downloaded from Unsplash and self-hosted (the site's CSP
is `img-src 'self'`, so a hotlinked photo would simply be blocked). Delivered as
1600px-wide JPEG at q78. The Unsplash Licence permits commercial use without
attribution; the source IDs are recorded anyway so any image can be traced back.

| File | Unsplash ID | Depicts | Used on |
|---|---|---|---|
| `team-collaboration.jpg` | `photo-1522071820081-009f0129c71c` | Four people working together on laptops | About — "Who We Are" |
| `developer-desk.jpg` | `photo-1531482615713-2afd69097998` | Two developers reviewing code on screen | Insights — "Engineering & Solution Teams" |
| `ecommerce-packing.jpg` | `photo-1556742049-0cfed4f6a45d` | Shop counter, customer paying by phone | Service — E-commerce Support |
| `security-work.jpg` | `photo-1550751827-4bd374c3f58b` | Backlit circuit schematic | Service — Web Security |
| `content-writing.jpg` | `photo-1499750310107-5fef28a66643` | Writing at a desk | Service — Content Creation |
| `marketing-analytics.jpg` | `photo-1551288049-bebda4e38f71` | Analytics dashboard on screen | Service — Marketing |
| `meeting-strategy.jpg` | `photo-1517245386807-bb43f82c33c4` | Team planning session | Service — Web Development |
| `abstract-gradient.jpg` | `photo-1550745165-9bc0b252726f` | Abstract colour field | Decorative |
| `engineer-server-room.jpg` | `photo-1573164713988-8665fc963095` | An engineer with a laptop beside server racks | Insights — "Our Operational Core" |

**Two downloads were rejected rather than shipped**, both caught by opening the
files and looking at them — worth recording, because neither would have been
found by any automated check:

- `photo-1600880292203-757bb62b4baf` — a staged corporate "high five". The exact
  stock-photo cliché that makes a site read as generic.
- `photo-1460925895917-afdab827c52f` — a laptop whose dashboard contains the
  placeholder string *"Some shitty stuff 1-4"*. Illegible at render size, but
  profanity does not belong on a commercial site at any resolution.

---

## Approved sources for future assets

**Use these.** Photography: Pexels, Unsplash (read each licence — neither is CC0,
and both restrict redistributing the asset itself as a competing service; site
imagery is fine). 3D models: Poly Pizza, Poly Haven, Khronos glTF-Sample-Assets,
Quaternius, Kenney — all CC0. Textures/HDRI: Poly Haven, ambientCG (CC0).
Illustrations: unDraw, Storyset (check attribution terms).

**Do not use** anything CC-BY-NC, CC-BY-SA (viral for a commercial site),
"free for personal use", or with no stated licence. For a registered company
pitching clients on professionalism, an unlicensed asset is a genuine liability
— and "found on Google Images" is not a licence.

If an asset requires attribution (CC-BY), it must be credited visibly on the
site, not only in this file.

---

## Placeholder content still to replace

These are marked in the UI with an orange `PLACEHOLDER` badge (the
`.is-placeholder` class in `css/07-utilities.css`). Remove the class once real
content is in.

All of these now carry `.is-placeholder`, so none can ship unnoticed:

- Case studies — 3 cards with invented metrics, `index.php` `#work`
- Testimonials — 3 cards, all `[Client Name]`, `index.php`
- Trust-bar figures — 120 projects and 98% satisfaction, `index.php`
- `insights.php` — 4 sample blog cards whose "Read More" links go nowhere

Not marked in the UI, but still outstanding:

- `assets/favicon.svg` — the one remaining stopgap. It is a drawn "R" monogram,
  not the real mark. Every other icon is now resampled from the real artwork, so
  this file is the odd one out; a proper SVG export of the mark would retire it.

---

## Generated brand assets

`logo.png` in the project root is the **master artwork** (1408x736, 176 KB) and
is no longer served to visitors. Everything in `assets/` below is derived from
it by cropping and resampling — no redrawing, no tracing, so these are the real
mark rather than an approximation. Regenerate them from the master if the logo
is ever updated.

| File | Size | Used by |
|---|---|---|
| `logo.png` | 320x99, 21 KB | header (120x37) and footer (100x31) |
| `og-cover.png` | 1200x630, 64 KB | `og:image` / `twitter:image` |
| `apple-touch-icon.png` | 180x180, 12 KB | iOS home screen (opaque white — iOS composites transparency on black) |
| `favicon-32.png` | 32x32, 1.4 KB | SVG-favicon fallback |
| `icon-192.png` / `icon-512.png` | 11 KB / 50 KB | PWA manifest, and `Organization.logo` in JSON-LD |

Two constraints drove the formats: no social-share crawler accepts SVG for
`og:image`, and iOS ignores an SVG `apple-touch-icon` — so those had to be PNG
regardless of preference. The 512 is also what JSON-LD points at, because Google
rejects an `Organization.logo` under 112px on either axis and the horizontal
lockup is only 99px tall.

The header logo went from 176 KB to 21 KB, and `og:image:width/height` (1200x630)
are now true instead of describing a 1408x736 image.

---

Resolved: the domain is now `rafly.in` (`inc/config.php`, and literally in
`robots.txt`, which cannot read the constant). The phone discrepancy is gone —
`CONTACT_PHONE` and `WHATSAPP_NUMBER` both derive from `RAW_PHONE`
(8796882212), so the number a visitor calls and the one they message are the
same line.

The earlier note here about a "client logo marquee — 6 slots" is out of date:
that was replaced by the 8-chip sector strip in `index.php`, which makes no
claim about specific clients and needs nothing swapped in.

See `CONTENT-CHECKLIST.md` at the repo root for the full handoff list.
