<?php
require __DIR__ . '/inc/bootstrap.php';

/**
 * Single source for the FAQ: renders the accordion further down AND the
 * FAQPage structured data below. Keeping one array means the rich result can
 * never claim something the page does not actually say.
 *
 * Trimmed to 8 from an earlier 12 — a long FAQ signals an unclear offer.
 */
$FAQS = [
    ['q' => 'How quickly can you start?',
     'a' => 'Most engagements begin within a week of our first call. For urgent fixes — a broken checkout, a security gap — we can have someone looking at it within 48 hours.'],
    ['q' => 'Do you work with existing websites?',
     'a' => 'Yes. Most of our work is on live sites and stores, not blank slates. We audit what is already there before we touch anything.'],
    ['q' => 'Who actually does the work?',
     'a' => 'A dedicated Rafly team — developers, a security reviewer, a content writer and a marketer — not a rotating cast of freelancers.'],
    ['q' => 'How do you price engagements?',
     'a' => 'Through bundled packages built around what you actually need. Instead of separate invoices for web, content, marketing and support, you get one scope and one price agreed up front.'],
    ['q' => 'What about security and compliance?',
     'a' => 'Every project includes a baseline security review — forms, sessions and access handling — as part of the package, not an optional add-on.'],
    ['q' => 'Do you offer ongoing support?',
     'a' => 'Yes. Bundled packages include a support window after launch, and we offer ongoing monthly plans for sites and stores that need continuous attention.'],
    ['q' => 'Can you integrate with our existing tools?',
     'a' => 'In most cases, yes — payment gateways, CRMs, analytics and e-commerce platforms. We confirm feasibility during discovery before committing.'],
    ['q' => 'Do you sign NDAs and transfer IP?',
     'a' => 'Yes. We sign NDAs on request, and full IP ownership transfers to you on final payment.'],
];

/**
 * Homepage content that the admin owns: case studies and testimonials.
 *
 * Both are read here, before any output, so a slow or failed query cannot leave
 * a half-rendered page. db_available() never throws — with the database down
 * each section renders empty and the rest of the homepage is unaffected, which
 * matters because everything else on this page is static and still sells.
 *
 * Three of each is what the grids are designed for; LIMIT keeps an
 * over-enthusiastic admin from breaking the layout.
 */
$caseStudies = db_available()
    ? all("SELECT client_name, sector, problem, action, metric_value, metric_label,
                  is_placeholder, tags
             FROM case_studies
            WHERE is_published
         ORDER BY sort_order, id
            LIMIT 3")
    : [];

$testimonials = db_available()
    ? all("SELECT quote, author_name, author_role, author_company,
                  consent_given, is_placeholder
             FROM testimonials
            WHERE is_published
         ORDER BY sort_order, id
            LIMIT 3")
    : [];

$page = [
    'id'        => 'home',
    'title'     => 'Rafly | Digital Growth — Build Fast, Grow Faster, Scale Smarter',
    'desc'      => 'One partner, one bundled package — web development,Ai automation, content creation, digital marketing, web security and e-commerce support, working together instead of stitched together from multiple vendors.',
    'bodyClass' => 'page-home',
    'styles'    => ['home'],
    'schema'    => [
        schema_faq($FAQS),
    ],
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="hero tex-grain tex-bloom" id="home">
        <div class="hero-container">
            <div class="hero-copy">
                <div class="badge-wrapper hero-badge">
                    <span class="section-badge">One partner. Multiple services.</span>
                </div>
                <h1 data-animate="split-text">Build Fast. Grow Faster. Scale Smarter.</h1>
                <p>One partner, one bundled package — web development, content creation, digital marketing, web security, and e-commerce support, all working together instead of stitched together from multiple vendors.</p>
                <div class="hero-actions">
                    <a href="#contact" class="btn-primary" data-animate="magnetic">Get Started</a>
                    <button class="btn-dark-pill" data-modal-open="consultationModal">Book a free consultation</button>
                </div>
            </div>

            <!--
                Hero scene. Five service satellites converge on one core — the
                value proposition performed rather than described.
                Rings/connectors/core are SVG so their paths can be drawn;
                satellites and chips are HTML for real shadows and hover.
            -->
            <div class="hero-visual">
                <div class="hero-scene" id="heroScene" data-pointer-scene>

                    <div class="scene-glow" aria-hidden="true"></div>
                    <div class="scene-mandala" aria-hidden="true"></div>

                    <div class="scene-svg" aria-hidden="true">
                        <svg viewBox="0 0 760 760" role="img" aria-label="Five services connecting into one system">
                            <defs>
                                <linearGradient id="coreGrad" x1="0" y1="0" x2="1" y2="1">
                                    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
                                </linearGradient>
                                <linearGradient id="rimGrad" x1="0" y1="0" x2="1" y2="1">
                                    <stop offset="0" stop-color="#7dd3fc"/><stop offset="0.6" stop-color="#7dd3fc" stop-opacity="0"/>
                                </linearGradient>
                                <linearGradient id="connGrad" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="0" stop-color="#0d47a1" stop-opacity="0.10"/>
                                    <stop offset="1" stop-color="#0d47a1" stop-opacity="0.55"/>
                                </linearGradient>
                                <path id="c1" d="M380 168 Q414 250 380 306"/>
                                <path id="c2" d="M600 310 Q470 316 416 352"/>
                                <path id="c3" d="M516 566 Q444 452 404 410"/>
                                <path id="c4" d="M244 566 Q316 452 356 410"/>
                                <path id="c5" d="M160 310 Q290 316 344 352"/>
                            </defs>

                            <g fill="none" stroke="rgba(13,71,161,.16)" stroke-width="1">
                                <circle class="ring ring-1" cx="380" cy="380" r="190"/>
                                <circle class="ring ring-2" cx="380" cy="380" r="262" stroke-dasharray="2 10"/>
                                <circle class="ring ring-3" cx="380" cy="380" r="330" stroke-dasharray="1 14"/>
                            </g>

                            <g fill="none" stroke="url(#connGrad)" stroke-width="2" stroke-linecap="round">
                                <use class="conn draw-path" href="#c1"/>
                                <use class="conn draw-path" href="#c2"/>
                                <use class="conn draw-path" href="#c3"/>
                                <use class="conn draw-path" href="#c4"/>
                                <use class="conn draw-path" href="#c5"/>
                            </g>

                            <!-- Travelling highlight: a short bright dash sweeps each connector in
                                 sync with its flow dot, reading as energy brightening the line. -->
                            <g class="conn-glows" fill="none" stroke-linecap="round">
                                <use class="conn-glow draw-path" href="#c1"/>
                                <use class="conn-glow draw-path" href="#c2"/>
                                <use class="conn-glow draw-path" href="#c3"/>
                                <use class="conn-glow draw-path" href="#c4"/>
                                <use class="conn-glow draw-path" href="#c5"/>
                            </g>

                            <!-- Ground contact shadow: what makes a 2D object feel physical -->
                            <ellipse class="core-shadow" cx="380" cy="496" rx="104" ry="15" fill="rgba(13,71,161,.16)"/>

                            <g class="core">
                                <circle class="pulse" cx="380" cy="380" r="110" fill="none" stroke="rgba(56,189,248,.35)" stroke-width="1.5"/>
                                <polygon class="core-fill" points="380,284 463,332 463,428 380,476 297,428 297,332" fill="url(#coreGrad)"/>
                                <polygon points="380,284 463,332 463,428 380,476 297,428 297,332" fill="none" stroke="url(#rimGrad)" stroke-width="1.5"/>
                                <polygon points="380,300 449,340 449,420 380,460 311,420 311,340" fill="none" stroke="rgba(255,255,255,.16)" stroke-width="1"/>
                                <g fill="none" stroke="#fff" stroke-opacity=".9" stroke-width="2">
                                    <circle cx="380" cy="380" r="20"/>
                                    <path d="M380 360v40M362 370l36 20M398 370l-36 20"/>
                                </g>
                            </g>

                            <g fill="#38bdf8">
                                <circle class="flow" r="3.5" style="offset-path:path('M380 168 Q414 250 380 306')"/>
                                <circle class="flow" r="3.5" style="offset-path:path('M600 310 Q470 316 416 352')"/>
                                <circle class="flow" r="3.5" style="offset-path:path('M516 566 Q444 452 404 410')"/>
                                <circle class="flow" r="3.5" style="offset-path:path('M244 566 Q316 452 356 410')"/>
                                <circle class="flow" r="3.5" style="offset-path:path('M160 310 Q290 316 344 352')"/>
                            </g>

                            <!-- Arrival flashes: one per connector, timed to match its flow dot -->
                            <g class="core-sparks" fill="#e0f2fe">
                                <circle class="core-spark" cx="380" cy="380" r="5"/>
                                <circle class="core-spark" cx="380" cy="380" r="5"/>
                                <circle class="core-spark" cx="380" cy="380" r="5"/>
                                <circle class="core-spark" cx="380" cy="380" r="5"/>
                                <circle class="core-spark" cx="380" cy="380" r="5"/>
                            </g>
                        </svg>
                    </div>

                    <div class="scene-particles" aria-hidden="true">
                        <?php
                        /* Ambient drift dots — index-derived placement, not random, so the
                           layout never shifts between requests or a cached response. Purely
                           decorative and capped at 20 to stay cheap. */
                        for ($i = 0; $i < 20; $i++):
                            $px = 6 + (($i * 37) % 90);
                            $py = 6 + (($i * 53) % 88);
                            $pdur = 6 + ($i % 6);
                            $pdelay = ($i % 10) * 0.4;
                        ?>
                            <span class="particle" style="--x:<?= $px ?>%; --y:<?= $py ?>%; --dur:<?= $pdur ?>s; --delay:<?= $pdelay ?>s"></span>
                        <?php endfor; ?>
                    </div>

                    <div class="scene-sats">
                        <a class="sat" style="--a:-90deg"  href="/web-development"><?= icon('code') ?><span>Web</span></a>
                        <a class="sat" style="--a:-18deg"  href="/content-creation"><?= icon('pencil') ?><span>Automation</span></a>
                        <a class="sat" style="--a:54deg"   href="/marketing-advertisement"><?= icon('megaphone') ?><span>Marketing</span></a>
                        <a class="sat" style="--a:126deg"  href="/web-security"><?= icon('shield') ?><span>Security</span></a>
                        <a class="sat" style="--a:198deg"  href="/ecommerce-support"><?= icon('shopping-cart') ?><span>E-commerce</span></a>
                    </div>

                    <div class="scene-chips" aria-hidden="true">
                        <div class="scene-chip glass c1"><strong>5</strong> services</div>
                        <div class="scene-chip glass c2"><strong>1</strong> invoice</div>
                        <div class="scene-chip glass c3"><strong>0</strong> handoffs</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
    /* The first two figures are claims about the business, so they come from the
       settings table and are editable in the admin — no code change to correct a
       number that turns out to be wrong.

       The .is-placeholder badge is driven by the matching trust.*.verified flag
       rather than being hardcoded, so marking a figure as verified in the admin
       is what removes the badge. A figure is unverified until someone says
       otherwise: these are the two claims most likely to be challenged by a
       prospect, and shipping them unmarked makes them read as audited fact.

       The last two (5 services, 24/7) are structural facts about the offer, not
       metrics, so they carry no flag. */
    $trustStats = [
        [
            'value'    => (int)setting('trust.projects.value', '20'),
            'suffix'   => '+',
            'label'    => 'Projects Delivered',
            'verified' => setting('trust.projects.verified', '0') === '1',
        ],
        [
            'value'    => (int)setting('trust.satisfaction.value', '98'),
            'suffix'   => '%',
            'label'    => 'Client Satisfaction',
            'verified' => setting('trust.satisfaction.verified', '0') === '1',
        ],
        [
            'value'    => (int)setting('trust.services.value', '5'),
            'suffix'   => '+',
            'label'    => 'Services Under One Roof',
            'verified' => true,
        ],
        [
            'value'    => 24,
            'suffix'   => '/7',
            'label'    => 'Support Availability',
            'verified' => true,
        ],
    ];
    ?>
    <section class="trust-bar">
        <div class="trust-bar-grid">
            <?php foreach ($trustStats as $stat): ?>
                <div class="trust-stat<?= $stat['verified'] ? '' : ' is-placeholder' ?>">
                    <?php /* aria-label carries the real static value (e.g. "120+") so a
                       crawler or screen reader that never runs the count-up JS reads the
                       real number instead of the "0" runCounter() starts from — same
                       pattern the hero h1 already uses for its JS-rebuilt text
                       (js/motion.js setupSplitText). Values/verified-badge unchanged. */ ?>
                    <h3 aria-label="<?= (int)$stat['value'] . e($stat['suffix']) ?>">
                        <span data-count="<?= (int)$stat['value'] ?>"<?= $stat['suffix'] !== '' ? ' data-suffix="' . e($stat['suffix']) . '"' : '' ?> aria-hidden="true">0</span>
                    </h3>
                    <p><?= e($stat['label']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Sectors we serve. This replaced a marquee of six placeholder chips
         reading "CLIENT LOGO" — fake logos are read instantly and damage
         credibility more than an empty space would. Swap back to real
         wordmarks here when they exist; the markup does not change. -->
    <section class="logo-strip surface-white hairline-bottom hairline-top">
        <p class="strip-label">Trusted across</p>
        <div class="marquee" style="--marquee-dur:42s">
            <div class="marquee-track">
                <span class="logo-chip">E-commerce</span>
                <span class="logo-chip">SaaS & Startups</span>
                <span class="logo-chip">Healthcare</span>
                <span class="logo-chip">Real Estate</span>
                <span class="logo-chip">Hospitality</span>
                <span class="logo-chip">Education</span>
                <span class="logo-chip">Manufacturing</span>
                <span class="logo-chip">Professional Services</span>
            </div>
        </div>
    </section>

    <!-- Challenges -->
    <section class="section-container surface-light tex-grain tex-mandala plate-a">
        <div class="badge-wrapper"><span class="section-badge">Are You Facing These Challenges?</span></div>
        <h2 class="section-title">Still Managing Growth Through Multiple Vendors?</h2>
        <p class="section-subtitle">Endless handoffs, mismatched timelines, and no single team accountable for the outcome — sound familiar?</p>
        <div class="grid-3" data-animate="stagger" data-stagger="90">
            <div class="challenge-card" data-animate="tilt" data-max="5">
                <div class="challenge-visual"><?= illo('fragmented') ?></div>
                <div class="card-body">Juggling <strong>separate vendors for your website, ads, content,automation and store</strong> — and none of them are talking to each other?</div>
            </div>
            <div class="challenge-card" data-animate="tilt" data-max="5">
                <div class="challenge-visual"><?= illo('delays') ?></div>
                <div class="card-body">Watching launches slip because <strong>the designer is waiting on the developer who is waiting on the marketer</strong>?</div>
            </div>
            <div class="challenge-card" data-animate="tilt" data-max="5">
                <div class="challenge-visual"><?= illo('insecure') ?></div>
                <div class="card-body">Not sure if your <strong>site, checkout, and customer data are actually secure</strong> — or just assumed to be?</div>
            </div>
        </div>
    </section>

    <!-- Who We Are -->
    <section class="section-container surface-white" id="about">
        <div class="split is-wide-right">
            <div class="illustration-box is-photo is-tinted">
                <img src="<?= e(asset('assets/photos/team-collaboration.jpg')) ?>"
                     alt="One team working together around a single table"
                     width="1400" height="934" loading="lazy" decoding="async">
            </div>
            <div class="who-we-are-content" data-animate="fade-left">
                <div class="badge-wrapper" style="text-align:left"><span class="section-badge">Who We Are</span></div>
                <h2>One team instead of multiple vendors</h2>
                <p>Rafly is a digital growth partner built around one idea: your website, content, marketing, security, and store operations shouldn't come from five different places. We package web development, content creation, digital marketing, web security, and e-commerce support into one coordinated team — and we're actively building out AI automation and app development capabilities to round out the offering.</p>

                <div class="mini-stats">
                    <div class="mini-stat"><strong data-count="5" data-suffix="">0</strong><span>Services bundled</span></div>
                    <div class="mini-stat"><strong data-count="1" data-suffix="">0</strong><span>Point of contact</span></div>
                    <div class="mini-stat"><strong data-count="0" data-suffix="">0</strong><span>Handoff gaps</span></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-container surface-light tex-grain tex-mandala plate-b">
        <div class="badge-wrapper"><span class="section-badge">Our Baseline Methodology</span></div>
        <h2 class="section-title">The P.E.A.C.E. Framework Behind Every Package</h2>
        <p class="section-subtitle">One coordinated method behind every bundled package we deliver — not five different vendors running five different processes.</p>

        <!-- .grid-even centres the trailing pair so five cards never strand an
             empty sixth cell the way the old 3-column grid did. -->
        <div class="grid-even" data-animate="stagger" data-stagger="80">
            <div class="peace-card glass" data-letter="P">
                <span class="peace-step">Step 01</span>
                <h3><?= icon('compass') ?> Planning</h3>
                <p>We map your goals, current setup, and where the gaps are — before any code, content, or campaign work begins.</p>
            </div>
            <div class="peace-card glass" data-letter="E">
                <span class="peace-step">Step 02</span>
                <h3><?= icon('terminal') ?> Execution</h3>
                <p>Our web, content, marketing, and security specialists build and ship inside one coordinated workflow.</p>
            </div>
            <div class="peace-card glass" data-letter="A">
                <span class="peace-step">Step 03</span>
                <h3><?= icon('search') ?> Analysis</h3>
                <p>We track traffic, engagement, and conversion data so decisions are based on evidence, not guesswork.</p>
            </div>
            <div class="peace-card glass" data-letter="C">
                <span class="peace-step">Step 04</span>
                <h3><?= icon('message-circle') ?> Consultation</h3>
                <p>Plain-language updates and recommendations — no technical jargon, no hiding behind reports.</p>
            </div>
            <div class="peace-card glass" data-letter="E">
                <span class="peace-step">Step 05</span>
                <h3><?= icon('gauge') ?> Enhancement</h3>
                <p>Ongoing improvements to your site, campaigns, and security posture as your business grows.</p>
            </div>
        </div>
    </section>

    <!-- How We Work — the connecting line fills as you scroll -->
    <section class="section-container">
        <div class="process-section surface-inverse tex-grain tex-mandala plate-f is-full">
            <div class="badge-wrapper"><span class="section-badge" style="background-color: rgba(255,255,255,0.1); color: #7dd3fc;">How We Work</span></div>
            <h2 class="section-title">A Process Built For Predictable Delivery</h2>
            <p class="section-subtitle">No mystery timelines. You always know exactly which stage your package is in.</p>
            <div class="process-track" data-animate="progress-line">
                <div class="process-line" aria-hidden="true"><span></span></div>
            <div class="process-grid">
                <div class="process-card">
                    <div class="process-num">01</div>
                    <h4>Discovery</h4>
                    <p>A call to understand your goals, current setup, and which parts of your growth need the most help.</p>
                    <div class="process-timeframe">2-3 Days</div>
                </div>
                <div class="process-card">
                    <div class="process-num">02</div>
                    <h4>Package &amp; Plan</h4>
                    <p>We scope a bundled package — web, content, marketing, security, e-commerce — matched to what you actually need.</p>
                    <div class="process-timeframe">3-5 Days</div>
                </div>
                <div class="process-card">
                    <div class="process-num">03</div>
                    <h4>Build &amp; Execute</h4>
                    <p>Development, content, and campaign work happen in parallel inside one coordinated team, not five separate vendors.</p>
                    <div class="process-timeframe">2-6 Weeks</div>
                </div>
                <div class="process-card">
                    <div class="process-num">04</div>
                    <h4>Launch</h4>
                    <p>Your site, store, or campaign goes live with a baseline security review already built into the process.</p>
                    <div class="process-timeframe">1 Week</div>
                </div>
                <div class="process-card">
                    <div class="process-num">05</div>
                    <h4>Ongoing Support</h4>
                    <p>Monitoring, updates, and continuous improvement so growth doesn't stall the day after launch.</p>
                    <div class="process-timeframe">Ongoing</div>
                </div>
            </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Rafly — the chart draws and the KPIs tick as it scrolls in -->
    <section class="section-container surface-white">
        <div class="split is-top">
            <div data-animate="fade-right">
                <div class="badge-wrapper" style="text-align:left"><span class="section-badge">Why Choose</span></div>
                <h2 class="section-title" style="text-align:left">Rafly For Your Business Growth?</h2>
                <p style="margin-bottom: var(--sp-5)">Managing web development, marketing, content, security, and e-commerce operations separately slows growth down. Rafly bundles them into a single package with one point of contact, so you spend less time coordinating vendors and more time running your business.</p>
                <ul class="checklist-wrapper" style="margin-bottom: var(--sp-6)">
                    <li><?= icon('circle-check') ?> Faster turnaround timelines</li>
                    <li><?= icon('circle-check') ?> One team, one point of contact</li>
                    <li><?= icon('circle-check') ?> Professional, hands-on delivery</li>
                    <li><?= icon('circle-check') ?> Proven, repeatable process</li>
                    <li><?= icon('circle-check') ?> Transparent bundled packages</li>
                </ul>
                <a class="btn-dark-pill" href="#contact" data-animate="magnetic">Know more <?= icon('arrow-right') ?></a>
            </div>

            <div class="mockup" data-animate="mask-up">
                <div class="mockup-bar">
                    <span class="mockup-dot"></span><span class="mockup-dot"></span><span class="mockup-dot"></span>
                </div>
                <div class="mockup-body">
                    <div class="mockup-kpis">
                        <div class="mockup-kpi"><strong data-count="182" data-suffix="%">0</strong><span>Traffic</span></div>
                        <div class="mockup-kpi"><strong data-count="64" data-suffix="%">0</strong><span>Conversion</span></div>
                        <div class="mockup-kpi"><strong data-count="3" data-suffix="x">0</strong><span>Faster launch</span></div>
                    </div>
                    <div data-animate="draw"><?= illo('growth') ?></div>
                </div>
            </div>
        </div>
    </section>

    <section class="services-overview surface-light tex-grain tex-mandala plate-c" id="services">
        <div class="section-container">
            <div class="badge-wrapper"><span class="section-badge">What We Do</span></div>
            <h2 class="section-title">Digital Growth, Bundled Into One Package</h2>
            <p class="section-subtitle">Web development, content, marketing, security, and e-commerce support — packaged together instead of scattered across vendors.</p>

            <!-- .grid-even keeps five cards from stranding an empty sixth cell -->
            <div class="grid-even" data-animate="stagger" data-stagger="70">
                <a href="/web-development" class="service-card glass">
                    <span class="svc-icon"><?= icon('code') ?></span>
                    <h3>Web Development</h3>
                    <p>Responsive, performance-focused websites and web apps built to support your growth.</p>
                    <span class="svc-more">Explore <?= icon('arrow-right') ?></span>
                </a>
                <a href="/web-security" class="service-card glass">
                    <span class="svc-icon"><?= icon('shield') ?></span>
                    <h3>Web Security</h3>
                    <p>Practical security reviews and hardening for your site, forms, and customer data.</p>
                    <span class="svc-more">Explore <?= icon('arrow-right') ?></span>
                </a>
                <a href="/content-creation" class="service-card glass">
                    <span class="svc-icon"><?= icon('pencil') ?></span>
                    <h3>Content Creation</h3>
                    <p>Website copy, social content, and brand messaging that sounds like you, not a template.</p>
                    <span class="svc-more">Explore <?= icon('arrow-right') ?></span>
                </a>
                <a href="/marketing-advertisement" class="service-card glass">
                    <span class="svc-icon"><?= icon('trending-up') ?></span>
                    <h3>Marketing &amp; Advertisement</h3>
                    <p>Targeted campaigns and audience strategy built around measurable results.</p>
                    <span class="svc-more">Explore <?= icon('arrow-right') ?></span>
                </a>
                <a href="/ecommerce-support" class="service-card glass">
                    <span class="svc-icon"><?= icon('shopping-cart') ?></span>
                    <h3>E-commerce Support</h3>
                    <p>Storefront structure, listings, and operational support for online sellers.</p>
                    <span class="svc-more">Explore <?= icon('arrow-right') ?></span>
                </a>
            </div>

            <p class="muted" style="text-align:center; font-size:var(--fs-xs); margin-top:var(--sp-6); font-style:italic;">
                We're also actively building out AI automation and app development capabilities — reach out if you'd like to be among the first to try them.
            </p>

            <hr class="rule-fade" style="margin: var(--sp-7) 0 var(--sp-5)">
            <p class="strip-label">Built on</p>
            <div class="stack-grid" data-animate="stagger" data-stagger="50">
            <div class="stack-chip"><?= icon('code') ?>PHP &amp; Laravel</div>
            <div class="stack-chip"><?= icon('layers') ?>WordPress</div>
            <div class="stack-chip"><?= icon('shopping-cart') ?>Shopify</div>
            <div class="stack-chip"><?= icon('terminal') ?>JavaScript</div>
            <div class="stack-chip"><?= icon('database') ?>MySQL</div>
            <div class="stack-chip"><?= icon('trending-up') ?>Google Ads</div>
            <div class="stack-chip"><?= icon('pie-chart') ?>Analytics 4</div>
            <div class="stack-chip"><?= icon('lock') ?>SSL &amp; WAF</div>
        </div>
        </div>
    </section>

    <!-- Work / case studies -->
    <section class="section-container surface-white" id="work">
        <div class="badge-wrapper"><span class="section-badge">Selected Work</span></div>
        <h2 class="section-title">Results, Not Just Deliverables</h2>
        <p class="section-subtitle">A snapshot of what bundled delivery looks like in practice.</p>

        <?php if (!$caseStudies): ?>
        <p class="muted" style="text-align:center; padding: var(--sp-6) 0;">Case studies are on the way — check back soon.</p>
        <?php else: ?>
        <div class="work-grid" data-animate="stagger" data-stagger="90">
            <?php
            /* Case studies come from the admin. is_placeholder is a column, so a
               card stops being badged the moment someone fills in a real client
               and outcome — no code change, and no risk of a seeded example
               quietly shipping as fact because a class was forgotten.

               tags is a comma-separated column; empty segments are filtered so a
               trailing comma does not render an empty chip. */
            foreach ($caseStudies as $w):
                $tags = array_values(array_filter(array_map('trim', explode(',', (string)$w['tags'])), 'strlen'));
                $isPlaceholder = !empty($w['is_placeholder']);
            ?>
                <article class="work-card<?= $isPlaceholder ? ' is-placeholder' : '' ?>" data-animate="tilt" data-max="7">
                    <div class="work-cover"><?= illo('work-cover') ?></div>
                    <div class="work-body">
                        <span class="section-badge"><?= e((string)$w['sector']) ?></span>
                        <div>
                            <div class="work-metric"><?= e((string)$w['metric_value']) ?></div>
                            <p class="muted" style="font-size:var(--fs-sm)"><?= e((string)$w['metric_label']) ?></p>
                        </div>
                        <p style="font-size:var(--fs-sm)">
                            <strong><?= e((string)$w['client_name']) ?></strong><?php
                            /* Prefer the real write-up. Fall back to the honest
                               "not filled in yet" line only while the card is
                               still flagged as a placeholder. */
                            if (trim((string)$w['action']) !== ''): ?> — <?= e((string)$w['action']) ?><?php
                            elseif (trim((string)$w['problem']) !== ''): ?> — <?= e((string)$w['problem']) ?><?php
                            elseif ($isPlaceholder): ?> — example card; a real case study replaces this.<?php
                            endif; ?>
                        </p>
                        <?php if ($tags): ?>
                            <div class="work-tags">
                                <?php foreach ($tags as $t): ?><span><?= e($t) ?></span><?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <p class="muted" style="text-align:center; margin-top:var(--sp-6); font-size:var(--fs-sm)">
            <a href="/case-studies">See all case studies</a>
        </p>
        <?php endif; ?>
    </section>

    <!-- Pricing — promoted out of the nav dropdown -->
    <section class="section-container surface-light tex-grain tex-mandala plate-e tex-aurora" id="pricing">
        <div class="badge-wrapper"><span class="section-badge">Bundle Packages</span></div>
        <h2 class="section-title">One Package, Every Service Included</h2>
        <p class="section-subtitle">Pick a starting point — every package is tailored to you during a free consultation.</p>

        <div class="pricing-grid" data-animate="stagger" data-stagger="110">
            <?php
            /* Same source partials/header.php's mega-dropdown renders —
               bundles_all() (inc/helpers.php), DB-backed via admin/bundles.php
               with a hardcoded fallback when the database is unavailable. */
            foreach (bundles_all() as $t): ?>
                <div class="price-card <?= $t['featured'] ? 'is-featured' : '' ?>">
                    <div>
                        <div class="price-name"><?= e($t['name']) ?> Bundle</div>
                        <div class="price-sub"><?= e($t['sub']) ?></div>
                        <div class="price-value"><?= e($t['price_text']) ?></div>
                    </div>
                    <ul class="price-list" data-animate="stagger" data-stagger="60">
                        <?php foreach ($t['points'] as $p): ?>
                            <li><?= icon('circle-check') ?><span><?= e($p) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <a class="btn-whatsapp-bundle" target="_blank" rel="noopener"
                       href="<?= e(whatsapp_link("Hi Rafly team! I'm interested in the {$t['name']} Bundle. Could you share an exact quote?")) ?>">
                        <?= icon('whatsapp', 'icon-fill') ?> Get exact quote
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <p class="muted" style="text-align:center; margin-top:var(--sp-6); font-size:var(--fs-sm)">
            <a href="/pricing">See full pricing details</a> &middot;
            Prefer to talk first? <a href="#contact">Request a free consultation</a> instead.
        </p>
    </section>

    <!-- NEW MODULE 4B: Why Growing Businesses Choose Rafly - Comparison Table -->
    <section class="section-container">
        <div class="badge-wrapper"><span class="section-badge">Why Growing Businesses Choose Rafly</span></div>
        <h2 class="section-title">Rafly vs. Traditional Agencies vs. Freelancers</h2>
        <p class="section-subtitle">Compare how a bundled Rafly package stacks up against hiring separately.</p>
        <div class="compare-grid" data-animate="stagger" data-stagger="35">
            <div class="compare-head"></div>
            <div class="compare-head compare-highlight">Rafly</div>
            <div class="compare-head">Traditional Agencies</div>
            <div class="compare-head">Freelancers &amp; DIY Tools</div>

            <div class="compare-label">Service Coverage</div>
            <?php /* data-col is rendered as the cell's own label by CSS below
                     768px, where the four column headings are hidden. Without
                     it a phone reader gets 18 cells in a row with nothing
                     saying which column any of them belongs to. */ ?>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> Web, content, marketing, security &amp; e-commerce in one team</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Usually just one specialty</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('circle-x') ?> No shared context between people</div>

            <div class="compare-label">Accountability</div>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> One point of contact, accountable for outcomes</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Account manager, execution outsourced further</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('circle-x') ?> You coordinate everyone yourself</div>

            <div class="compare-label">Security</div>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> Baseline review included in every package</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Usually a separate paid add-on</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('circle-x') ?> Rarely considered at all</div>

            <div class="compare-label">Delivery Speed</div>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> Parallel execution across one coordinated team</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Sequential handoffs between departments</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('circle-x') ?> Depends entirely on individual availability</div>

            <div class="compare-label">Pricing Structure</div>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> Clear, bundled packages</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Custom retainers, scope creep</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('alert-triangle') ?> Paid per task, costs add up</div>

            <div class="compare-label">Communication</div>
            <div class="compare-cell compare-highlight" data-col="Rafly"><?= icon('circle-check') ?> Plain-language updates, no jargon</div>
            <div class="compare-cell" data-col="Traditional Agencies"><?= icon('alert-triangle') ?> Layered reporting, slower answers</div>
            <div class="compare-cell" data-col="Freelancers &amp; DIY Tools"><?= icon('circle-x') ?> Manual coordination on your end</div>
        </div>
    </section>

    <section class="section-container section-cta-banner">
        <div class="cta-banner-wrapper">
            <div class="badge-wrapper"><span class="section-badge is-on-dark">Ready To Stop Juggling Vendors?</span></div>
            <h2>Take The Next Step Towards Bundled Growth</h2>
            <p>One team, one package, one point of contact — for your website, content, marketing, security, and e-commerce operations. Let's put a plan together.</p>
            <button class="btn-consultation btn-on-dark" type="button" data-modal-open="consultationModal">Get Started Today</button>
            <ul class="cta-features-list">
                <li><?= icon('circle-check') ?> Dedicated Team</li>
                <li><?= icon('circle-check') ?> Bundled Pricing</li>
                <li><?= icon('circle-check') ?> Transparent Process</li>
            </ul>
        </div>
    </section>

    <!--
        Testimonials.
        The previous version of this page opened with a "video testimonial":
        a play button over an empty black box with no video behind it. A control
        that plays nothing costs more trust than it earns, so it is replaced by
        a featured written quote.
    -->
    <section class="section-container surface-white">
        <div class="badge-wrapper"><span class="section-badge">What Our Clients Say</span></div>
        <h2 class="section-title">Real Stories, Real Success</h2>
        <p class="section-subtitle">Businesses that replaced a handful of scattered vendors with one bundled Rafly package.</p>

        <?php
        /* Quotes come from the admin, and the badge is driven by the
           is_placeholder column rather than a hardcoded class.

           Note the consent_given column: a quote is only publishable once the
           client has agreed to be named. Until then the card keeps its
           placeholder badge even if the attribution has been filled in, because
           publishing a named client without permission is the expensive kind of
           mistake to make on a public homepage. */
        ?>
        <?php if (!$testimonials): ?>
        <p class="muted" style="text-align:center; padding: var(--sp-6) 0;">Client testimonials are coming soon — we're just getting started.</p>
        <?php else: ?>
        <div class="grid-3" data-animate="stagger" data-stagger="90">
            <?php foreach ($testimonials as $t):
                $isPlaceholder = !empty($t['is_placeholder']) || empty($t['consent_given']);

                // "Founder, D2C Skincare Brand" — either half may be blank.
                $attribution = implode(', ', array_values(array_filter([
                    trim((string)$t['author_role']),
                    trim((string)$t['author_company']),
                ], 'strlen')));
            ?>
                <figure class="testimonial-card<?= $isPlaceholder ? ' is-placeholder' : '' ?>">
                    <div>
                        <div class="testimonial-stars">
                            <span class="sr-only">Rated 5 out of 5</span>
                            <?= str_repeat(icon('star'), 5) ?>
                        </div>
                        <blockquote class="testimonial-text">"<?= e((string)$t['quote']) ?>"</blockquote>
                    </div>
                    <figcaption class="testimonial-profile">
                        <div class="profile-avatar"><?= icon('user') ?></div>
                        <div class="profile-info">
                            <h5><?= e((string)$t['author_name']) ?></h5>
                            <?php if ($attribution !== ''): ?><p><?= e($attribution) ?></p><?php endif; ?>
                        </div>
                    </figcaption>
                </figure>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </section>

    <!-- FAQ — narrow measure after eleven wide sections; the page settling
         before the ask. Trimmed 12 -> 8: a long FAQ signals an unclear offer. -->
    <section class="section-container band-narrow surface-light tex-grain" id="faq">
        <div class="faq-head">
            <span class="section-badge">FAQ</span>
            <h2>Questions, answered</h2>
            <p class="muted">Still unsure about something? <a href="#contact">Ask us directly</a>.</p>
        </div>

        <?php
        /* Rendered from $FAQS (defined at the top of this file), which also
           feeds the FAQPage JSON-LD. Hand-writing the markup and the structured
           data separately is how the two silently drift — and a schema that
           disagrees with the visible page is a manual-action risk, not just a
           lost rich result. */
        ?>
        <div class="faq-list" data-animate="stagger" data-stagger="50">
<?php foreach ($FAQS as $i => $faq): ?>
            <div class="faq-node">
                <button class="faq-node-header" aria-expanded="false" aria-controls="faq-p<?= $i ?>">
                    <span><?= e($faq['q']) ?></span>
                    <svg class="icon" aria-hidden="true"><use href="#i-chevron-down"></use></svg>
                </button>
                <div class="faq-node-panel" id="faq-p<?= $i ?>"><div>
                    <div class="faq-node-content"><?= e($faq['a']) ?></div>
                </div></div>
            </div>
<?php endforeach; ?>
        </div>
    </section>

    <!-- Contact Operations Core -->
    <section class="contact-section" id="contact">
        <div class="section-container">
            <h2 class="section-title">Ready to Bundle Your Digital Growth?</h2>
            <p class="section-subtitle">Tell us what's slowing you down and we'll put together a package that covers it.</p>
            
            <div class="contact-split">
            <div class="contact-details-bar">
                <div class="detail-box">
                    <?= icon('map-pin') ?>
                    <h4>Our Address</h4>
                    <p>A523, T3, NX-One, Tech Zone IV,<br>Greater Noida West, 201306</p>
                </div>
                <div class="detail-box">
                    <?= icon('mail') ?>
                    <h4>Email Us</h4>
                    <p><?= e(CONTACT_EMAIL) ?></p>
                </div>
                <div class="detail-box">
                    <?= icon('phone') ?>
                    <h4>Call Us</h4>
                    <p><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', CONTACT_PHONE)) ?>"><?= e(CONTACT_PHONE) ?></a><br><?= e(setting('contact.hours', 'Mon - Fri, 09:00 - 18:00 IST')) ?></p>
                </div>
            </div>

            <div class="form-wrapper">
                <form action="/submit" method="POST" id="contactForm" data-ajax-form="true" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <?= lead_context_fields() ?>
                    <?php require __DIR__ . '/partials/honeypot.php'; ?>
                    <?php require __DIR__ . '/partials/antibot.php'; ?>
                    <div class="form-group">
                        <label for="contact_name">Your Name</label>
                        <input type="text" id="contact_name" name="contact_name" class="form-control" required placeholder="Jane Doe" autocomplete="name">
                    </div>
                    <div class="form-group">
                        <label for="contact_email">Email</label>
                        <input type="email" id="contact_email" name="contact_email" class="form-control" required placeholder="jane@example.com" autocomplete="email">
                    </div>
                    <div class="form-group">
                        <label for="company_name">Company Name</label>
                        <input type="text" id="company_name" name="company_name" class="form-control" required placeholder="Rafly Tech Corp" autocomplete="organization">
                    </div>
                    <div class="form-group">
                        <label for="contact_number">Contact Number</label>
                        <input type="tel" id="contact_number" name="contact_number" class="form-control" required placeholder="+1 234 567 8900" autocomplete="tel">
                    </div>
                    <div class="form-group">
                        <label for="description">Project Context / Requirements</label>
                        <textarea id="description" name="description" class="form-control" required placeholder="Describe what you want us to execute..."></textarea>
                    </div>
                    <div class="form-group consent-group">
                        <input type="checkbox" id="consent" name="consent" required>
                        <label for="consent">I agree to the <a href="/privacy" target="_blank" rel="noopener">Privacy Policy</a> and consent to my information being processed as described.</label>
                    </div>
                    <button type="submit" class="btn-submit">Submit Requirements</button>
                </form>
            </div>
            </div>
        </div>
    </section>

    <!-- Assistant widget. Both controls are real <button>s: they were <div>/<span>
         with onclick, which meant the whole widget was unreachable by keyboard
         and kept 'unsafe-inline' in the CSP. -->
    <button class="bot-trigger" type="button"
            data-bot-toggle
            aria-expanded="false"
            aria-controls="botWindow"
            aria-label="Open the Rafly assistant"><?= icon('message-circle') ?></button>

    <div class="bot-window" id="botWindow" role="dialog" aria-label="Rafly Interactive Assistant" hidden>
        <div class="bot-header">
            <span class="bot-title"><?= icon('bot') ?> Rafly Interactive Assistant</span>
            <button class="bot-close" type="button" data-bot-toggle aria-label="Close the assistant">&times;</button>
        </div>
        <!-- aria-live so replies are announced; without it a screen-reader user
             presses an option and hears nothing. -->
        <div class="bot-logs" id="botLogs" role="log" aria-live="polite" aria-atomic="false">
            <div class="msg server">Welcome. Select a structural information requirement option below to query our solutions index instantly.</div>
        </div>
        <div class="bot-options" id="botOptions"></div>
    </div>
</main>

<?php require __DIR__ . '/partials/tail.php'; ?>
