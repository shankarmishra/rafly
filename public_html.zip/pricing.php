<?php
require __DIR__ . '/inc/bootstrap.php';

/**
 * Dedicated pricing page. The homepage's #pricing section already shows the
 * same three cards; this exists because every CTA on the site otherwise
 * routes straight to WhatsApp with zero price signal, which loses any visitor
 * who won't message a stranger before knowing a ballpark figure. Ranges are
 * indicative (price_text, admin-editable via admin/bundles.php) — not exact
 * quotes, which is why "Get exact quote" stays on every card rather than
 * disappearing.
 */

$page = [
    'id'        => 'pricing',
    'title'     => 'Pricing | Rafly Digital Growth',
    'desc'      => 'Indicative pricing for our bundled packages — Starter, Growth and Enterprise. Get an exact quote for your specific requirements.',
    'bodyClass' => 'page-pricing',
    'styles'    => ['home', 'about'],
    'schema'    => [
        schema_breadcrumbs($crumbs = [
            ['name' => 'Home',    'url' => '/'],
            ['name' => 'Pricing', 'url' => '/pricing'],
        ]),
    ],
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="hero tex-grain">
        <div class="hero-container is-single">
            <?= breadcrumbs($crumbs) ?>
            <div class="hero-copy">
                <div class="badge-wrapper"><span class="section-badge">Pricing</span></div>
                <h1>Indicative pricing, so you know before you message us.</h1>
                <p>Ranges below are a starting point, not a final invoice — every engagement is scoped to what you actually need during a free consultation. Nothing here is a substitute for an exact quote, it's just enough to know whether we're in the right ballpark.</p>
            </div>
        </div>
    </section>

    <section class="section-container">
        <div class="pricing-grid" data-animate="stagger" data-stagger="110">
            <?php foreach (bundles_all() as $t): ?>
                <div class="price-card <?= $t['featured'] ? 'is-featured' : '' ?>">
                    <div>
                        <div class="price-name"><?= e($t['name']) ?> Bundle</div>
                        <div class="price-sub"><?= e($t['sub']) ?></div>
                        <div class="price-value"><?= e($t['price_text']) ?></div>
                    </div>
                    <ul class="price-list" data-animate="stagger" data-stagger="60">
                        <?php foreach ($t['points'] as $p): ?>
                            <li><?= icon('circle-check') ?><span><?= e($p) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <a class="btn-whatsapp-bundle" target="_blank" rel="noopener"
                       href="<?= e(whatsapp_link("Hi Rafly team! I'm interested in the {$t['name']} Bundle. Could you share an exact quote?")) ?>">
                        <?= icon('whatsapp', 'icon-fill') ?> Get exact quote
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <p class="muted" style="text-align:center; margin-top:var(--sp-6); font-size:var(--fs-sm)">
            Not sure which package fits? <a href="/#contact">Request a free consultation</a> and we'll help you figure it out.
        </p>
    </section>
</main>
<?php require __DIR__ . "/partials/tail.php"; ?>
