<?php
require __DIR__ . '/inc/bootstrap.php';

$page = [
    'id'        => 'about',
    'title'     => 'About Rafly | Digital Growth',
    'desc'      => 'We build efficient digital systems and growth strategies for modern businesses — one partner across web, content, marketing, security and e-commerce.',
    'bodyClass' => 'page-about',
    'styles'    => ['about'],
    'schema'    => [
        [
            '@type'       => 'AboutPage',
            '@id'         => schema_id('about'),
            'url'         => SITE_ORIGIN . '/about',
            'name'        => 'About Rafly | Digital Growth',
            'description' => 'We build efficient digital systems and growth strategies for modern businesses — one partner across web, content, marketing, security and e-commerce.',
            'isPartOf'    => ['@id' => schema_id('website')],
            'about'       => ['@id' => schema_id('organization')],
        ],
        schema_breadcrumbs($crumbs = [
            ['name' => 'Home',  'url' => '/'],
            ['name' => 'About', 'url' => '/about'],
        ]),
    ],
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="hero tex-grain">
        <?php
        /* The .hero-copy wrapper is load-bearing, not decoration.
           At >=1025px .hero-container becomes a two-column grid (1.05fr 0.95fr)
           built for the homepage's copy + visual split. This page has no visual,
           so its four children were being dealt into the grid two per row:
           eyebrow | headline on row one, paragraph | button on row two. Wrapping
           them makes the grid see a single child again. is-single then collapses
           it to one centred track, so the breadcrumb row above .hero-copy just
           stacks as its own centred row rather than fighting the grid. */
        ?>
        <div class="hero-container is-single">
            <?= breadcrumbs($crumbs) ?>
            <div class="hero-copy">
                <div class="badge-wrapper"><span class="section-badge">About Rafly</span></div>
                <h1>We build efficient digital systems and growth strategies for modern businesses.</h1>
                <p>Rafly is a digital growth partner that bundles web development, content creation, digital marketing, web security, and e-commerce support into one coordinated team — so you get one accountable point of contact instead of five separate vendors.</p>
                <a href="/#contact" class="btn-primary">Discover Our Work</a>
            </div>
        </div>
    </section>

    <section class="section-container" id="about">
        <div class="grid-2">
            <div class="illustration-box is-photo is-tinted">
                <img src="<?= e(asset('assets/photos/team-collaboration.jpg')) ?>"
                     alt="A team working together around one table, laptops open"
                     width="1400" height="934" loading="lazy" decoding="async">
            </div>
            <div>
                <h2 class="section-title" style="text-align:left;">Who We Are</h2>
                <p class="section-subtitle" style="text-align:left; margin:0 0 20px 0; max-width:none;">Rafly combines technical execution with business understanding. Instead of hiring separate people for your website, content, marketing, security, and store operations, you work with one team that already shares the same plan.</p>
                <ul class="checklist-wrapper">
                    <li><?= icon('circle-check') ?> Dedicated, bundled support for growing businesses</li>
                    <li><?= icon('circle-check') ?> Reliable web development and security guidance</li>
                    <li><?= icon('circle-check') ?> Strategy-led marketing, content, and e-commerce support</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="section-container surface-light tex-grain tex-jaali">
        <div class="badge-wrapper"><span class="section-badge">Our Mission and Vision</span></div>
        <h2 class="section-title">Bundled Growth, Not Fragmented Vendors</h2>
        <p class="section-subtitle">Two commitments that shape how every package is scoped and delivered.</p>

        <div class="mv-grid" data-animate="stagger" data-stagger="120">
            <div class="mv-card glass">
                <div class="mv-icon"><?= icon('compass') ?></div>
                <h3>Our Mission</h3>
                <p>To give growing businesses one accountable team for every part of their digital presence — website, content, marketing, security, and store operations — bundled into clear packages instead of scattered contracts. We focus on dependable delivery, transparent pricing, and outcomes you can actually measure.</p>
            </div>
            <div class="mv-card is-vision">
                <div class="mv-icon"><?= icon('rocket') ?></div>
                <h3>Our Vision</h3>
                <p>To become the go-to bundled growth partner for small and mid-sized businesses — the team you call once, instead of five different vendors, whenever something digital needs to get done.</p>
            </div>
        </div>
    </section>

    <section class="section-container" style="background-color: #ffffff; border-radius: 16px;">
        <h2 class="section-title what-we-do-title">What We Do</h2>
        <p class="section-subtitle what-we-do-subtitle">Our services are designed to support every stage of digital growth, from launch to scale.</p>
        <div class="grid-3 services-grid">
            <div class="card">
                <?= icon('code') ?>
                <h3>Web Development</h3>
                <p>We create clean, responsive, and performance-oriented websites and web applications that align with business goals.</p>
            </div>
            <div class="card">
                <?= icon('shield') ?>
                <h3>Security & Infrastructure</h3>
                <p>We help identify vulnerabilities, harden systems, and establish safer digital environments for long-term stability.</p>
            </div>
            <div class="card">
                <?= icon('trending-up') ?>
                <h3>Marketing & Growth</h3>
                <p>Our growth-focused approach helps businesses increase visibility, improve engagement, and strengthen conversion opportunities.</p>
            </div>
            <div class="card">
                <?= icon('shopping-cart') ?>
                <h3>E-commerce Support</h3>
                <p>We support online sellers with operational clarity, product listing structure, and practical systems that improve day-to-day management.</p>
            </div>
            <div class="card">
                <?= icon('pencil') ?>
                <h3>Content & Brand Presence</h3>
                <p>We build clear messaging and visual direction that helps businesses communicate value more confidently online.</p>
            </div>
            <div class="card">
                <?= icon('settings') ?>
                <h3>Operational Support</h3>
                <p>We simplify complex business processes so teams can execute faster, reduce friction, and stay focused on growth.</p>
            </div>
        </div>
    </section>

    <section class="section-container">
        <div class="grid-2">
            <div>
                <h2 class="section-title" style="text-align:left;">Our Approach</h2>
                <p class="section-subtitle" style="text-align:left; margin:0 0 20px 0; max-width:none;">We work with a practical, structured method that aligns technology, content, marketing, and growth objectives across one bundled package. Every solution is shaped around clarity, delivery reliability, and business value.</p>
                <ul class="checklist-wrapper">
                    <li><?= icon('circle-check') ?> Understand goals before implementation</li>
                    <li><?= icon('circle-check') ?> Build systems that are scalable and maintainable</li>
                    <li><?= icon('circle-check') ?> Focus on measurable business impact, not just deliverables</li>
                </ul>
            </div>
            <div class="illustration-box is-photo is-tinted">
                <img src="<?= e(asset('assets/photos/meeting-strategy.jpg')) ?>"
                     alt="A planning session in progress"
                     width="1400" height="934" loading="lazy" decoding="async">
            </div>
        </div>
    </section>

    <section class="section-container" id="contact">
        <div class="hero-container">
            <div class="badge-wrapper"><span class="section-badge">Ready to Work With Us?</span></div>
            <h2 class="section-title">Let’s build a stronger digital foundation for your business.</h2>
            <p class="section-subtitle">Tell us what you need and we’ll help you move forward with a clear plan and practical execution.</p>
            <a href="/#contact" class="btn-primary">Contact Rafly</a>
        </div>
    </section>
</main>

<?php require __DIR__ . "/partials/tail.php"; ?>
