<?php
/**
 * Dev-only router for PHP's built-in server: `php -S 127.0.0.1:8899 router.php`
 * (or just run serve.bat).
 *
 * PHP's built-in server never reads .htaccess, so none of the clean-URL
 * rewrites, the old-URL redirects, or the "block application internals"
 * rules apply without this file. Without it, any clean URL (/about,
 * /pricing, /web-development, ...) falls through to the nearest index.php
 * and silently renders the homepage instead of 404ing or routing correctly
 * — which is exactly the bug this file exists to prevent.
 *
 * Apache/LiteSpeed NEVER load this file — .htaccess is what runs in
 * production. The two must be kept in sync by hand; if you add a rewrite
 * rule to .htaccess, add the matching case here too.
 */

$uri  = $_SERVER['REQUEST_URI'] ?? '/';
$path = trim((string)parse_url($uri, PHP_URL_PATH), '/');
$root = __DIR__;

// -----------------------------------------------------------------------
// 1. Block application internals — mirrors .htaccess's
//    RedirectMatch 404 /\.git and RedirectMatch 404 /(inc|partials)/ and
//    RedirectMatch 404 /admin/lib/
// -----------------------------------------------------------------------
if (
    $path === '.git' || str_starts_with($path, '.git/') ||
    str_starts_with($path, 'inc/') ||
    str_starts_with($path, 'partials/') ||
    str_starts_with($path, 'private/') ||
    str_starts_with($path, 'admin/lib/')
) {
    http_response_code(404);
    require $root . '/404.php';
    return true;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$isSafe = in_array($method, ['GET', 'HEAD'], true);

/** Sends a 301 to $to, GET/HEAD only — never redirect a POST. */
$redirect = static function (string $to) use ($isSafe): bool {
    if (!$isSafe) {
        return false;
    }
    header('Location: ' . $to, true, 301);
    return true;
};

/** Runs $file with $params merged into $_GET (query-string rewrites). */
$dispatch = static function (string $file, array $params = []) use ($root): bool {
    foreach ($params as $k => $v) {
        $_GET[$k] = $v;
    }
    if ($params) {
        $_SERVER['QUERY_STRING'] = http_build_query($params)
            . (($_SERVER['QUERY_STRING'] ?? '') !== '' ? '&' . $_SERVER['QUERY_STRING'] : '');
    }
    require $root . '/' . $file;
    return true;
};

// -----------------------------------------------------------------------
// 2. Old .php URLs -> clean URL (301), mirrors .htaccess:56-72.
//
// This MUST run before the real-file passthrough below: about.php etc.
// are real files on disk, and .htaccess redirects them unconditionally
// (its RewriteRules have no `-f` exists-check), so a naive "serve real
// files as-is" rule here would silently skip the redirect and diverge
// from production.
// -----------------------------------------------------------------------
$oldToClean = [
    'index.php'        => '',
    'about.php'        => 'about',
    'team.php'         => 'team',
    'insights.php'     => 'insights',
    'privacy.php'      => 'privacy',
    'thank-you.php'    => 'thank-you',
    'submit.php'       => 'submit',
    'pricing.php'      => 'pricing',
    'case-studies.php' => 'case-studies',
];
if (isset($oldToClean[$path]) && $redirect('/' . $oldToClean[$path])) {
    return true;
}

if ($path === 'service.php' && isset($_GET['service'])) {
    $slug = (string)$_GET['service'];
    if (in_array($slug, ['web-development', 'web-security', 'marketing-advertisement', 'content-creation', 'ecommerce-support'], true)
        && $redirect('/' . $slug)) {
        return true;
    }
}

if ($path === 'insight.php' && isset($_GET['post'])) {
    $slug = (string)$_GET['post'];
    if (preg_match('/^[a-z0-9-]+$/', $slug) && $redirect('/insights/' . $slug)) {
        return true;
    }
}

// -----------------------------------------------------------------------
// 3. Clean URL -> real file, mirrors .htaccess:76-96.
// -----------------------------------------------------------------------
$cleanToFile = [
    'pricing'      => 'pricing.php',
    'case-studies' => 'case-studies.php',
    'about'        => 'about.php',
    'team'         => 'team.php',
    'insights'     => 'insights.php',
    'privacy'      => 'privacy.php',
    'thank-you'    => 'thank-you.php',
    'submit'       => 'submit.php',
];
if (isset($cleanToFile[$path])) {
    return $dispatch($cleanToFile[$path]);
}

if ($path === 'sitemap.xml') {
    return $dispatch('sitemap.php');
}

if (preg_match('#^insights/([a-z0-9-]+)$#', $path, $m)) {
    return $dispatch('insight.php', ['post' => $m[1]]);
}

if (preg_match('#^(web-development|web-security|marketing-advertisement|content-creation|ecommerce-support)$#', $path, $m)) {
    return $dispatch('service.php', ['service' => $m[1]]);
}

if (preg_match('#^admin-gate/([A-Za-z0-9_-]+)$#', $path, $m)) {
    return $dispatch('admin/login.php', ['gate_key' => $m[1]]);
}

// -----------------------------------------------------------------------
// 4. Anything else that's a real file/dir — let the built-in server serve
//    it as-is (CSS, JS, images, fonts, uploads, and every remaining
//    /admin/*.php page, which already uses plain .php URLs and needs no
//    rewriting).
// -----------------------------------------------------------------------
$file = $root . '/' . $path;
if ($path !== '' && (is_file($file) || is_dir($file))) {
    return false;
}

// -----------------------------------------------------------------------
// 5. Homepage.
// -----------------------------------------------------------------------
if ($path === '') {
    require $root . '/index.php';
    return true;
}

// -----------------------------------------------------------------------
// 6. Nothing matched -> real 404, mirrors .htaccess's ErrorDocument 404.
// -----------------------------------------------------------------------
http_response_code(404);
require $root . '/404.php';
return true;
