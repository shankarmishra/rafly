<?php
require __DIR__ . '/inc/bootstrap.php';

/**
 * Custom 404. Wired up via ErrorDocument in .htaccess.
 *
 * Apache includes this file rather than redirecting, so the URL the visitor
 * typed stays in the address bar — which is what we want — but it also means
 * PHP's own response code starts at 200. Setting it explicitly is what makes
 * this a real 404 to crawlers rather than a soft-404 that gets indexed.
 */
http_response_code(404);

$page = [
    'id'        => '',
    'title'     => 'Page not found | ' . SITE_NAME,
    'desc'      => 'That page does not exist. Browse our services or get in touch with the Rafly team.',
    'bodyClass' => 'page-404',
    'styles'    => ['legal'],
    'noindex'   => true,
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>

<main id="main" class="notfound-wrap">
    <div class="notfound-inner">
        <p class="notfound-code" aria-hidden="true">404</p>

        <h1>We can't find that page.</h1>
        <p class="notfound-lead">
            The link may be out of date, or the address may have a typo. Nothing is broken
            on your side — here's where most people are heading.
        </p>

        <nav class="notfound-links" aria-label="Popular pages">
            <a class="notfound-link" href="/">
                <?= icon('compass') ?>
                <span><strong>Home</strong>What Rafly does, and how the bundles work</span>
            </a>
            <a class="notfound-link" href="/#services">
                <?= icon('layers') ?>
                <span><strong>Services</strong>All five, and how they fit together</span>
            </a>
            <a class="notfound-link" href="/#pricing">
                <?= icon('package') ?>
                <span><strong>Packages</strong>Starter, Growth and Enterprise</span>
            </a>
            <a class="notfound-link" href="/insights">
                <?= icon('file-pen') ?>
                <span><strong>Insights</strong>Notes from the team doing the work</span>
            </a>
        </nav>

        <div class="notfound-actions">
            <button class="btn-primary" type="button" data-modal-open="consultationModal">
                Get a free consultation
            </button>
            <a class="btn-dark-pill" href="<?= e(whatsapp_link('Hi Rafly team, I hit a broken link on your website.')) ?>"
               target="_blank" rel="noopener">
                <?= icon('whatsapp') ?> Message us
            </a>
        </div>
    </div>
</main>

<?php require __DIR__ . '/partials/tail.php'; ?>
