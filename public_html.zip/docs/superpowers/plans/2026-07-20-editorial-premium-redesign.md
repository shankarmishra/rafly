# Editorial Premium Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Elevate the Rafly public site to the approved "editorial premium" light design — display typography, brand-gradient color system, aurora/grain atmosphere, upgraded component physics, motion polish, and an SVG illustration depth pass — entirely through the existing token architecture.

**Architecture:** All changes flow through the layered CSS system (`00-tokens` → `08-texture` → `pages/*`). PHP markup changes are limited to adding utility classes and SVG edits in `partials/illustrations.php`. No JS libraries; only surgical additions to existing CSS. The dev server runs at `http://127.0.0.1:8899` (start with `php -S 127.0.0.1:8899` from repo root if down).

**Tech Stack:** Hand-written CSS custom properties, PHP 8.3 partials, vanilla JS (`js/motion.js`, `js/app.js` — mostly untouched).

## Global Constraints

- Light theme throughout; public pages only; admin untouched.
- No build step, no new JS libraries, no external requests; CSP stays `script-src 'self'`.
- Vector-first: no downloaded raster assets.
- WCAG AA contrast maintained; `prefers-reduced-motion` honored (the global reduce block in `06-animations.css:189` already freezes all animations/transitions — new animations need no extra handling unless noted).
- CSS budget: baseline is **135,572 bytes** total across `css/*.css` + `css/pages/*.css`. Final total must stay ≤ **143,900 bytes** (~8 KB growth). Check with: `ls css/*.css css/pages/*.css | xargs wc -c | tail -1`
- CMS markup contracts: class names rendered by PHP loops (`.work-card`, `.testimonial-card`, `.blog-card`, `.trust-stat`, `.is-placeholder`, `.price-card`, `.section-badge`) keep their names and semantics.
- After every PHP edit: `php -l <file>` must pass. After every task: the smoke URLs (Task 10 Step 2 list) must return expected status codes.

## Spec corrections discovered during planning

1. **Footer** — the spec assumed a "plain" footer; it is already dark navy (`.site-footer`, `05-footer.css:7`). Keep its dark identity (it already bookends); add grain texture + gradient hairline top instead of converting to light. This preserves the user's "light site" intent — the footer was always dark.
2. **Reading progress bar** — already exists sitewide (`.scroll-progress` in `04-nav.css:20`, driven by `js/motion.js`). Restyle to the brand gradient instead of building a scroll-timeline duplicate.
3. **FAQ accordion physics** — already implemented via `grid-template-rows 0fr→1fr` (`03-components.css:426`). No work needed.
4. **Gradient hero keyword** — `data-animate="split-text"` rebuilds the `<h1>` from `textContent` (`js/motion.js:180`), destroying any inner span. Target the generated `.split-word:last-child` ("Smarter.") with CSS instead of adding markup.

---

### Task 1: Foundation tokens + eyebrow badge restyle

**Files:**
- Modify: `css/00-tokens.css` (inside `:root`, after the `--fs-4xl` line)
- Modify: `css/03-components.css:6-31` (badge block)

**Interfaces:**
- Produces tokens consumed by every later task: `--fs-display`, `--grad-brand`, `--grad-brand-soft`, `--aurora-blue`, `--aurora-warm`.

- [ ] **Step 1: Add new tokens**

In `css/00-tokens.css`, immediately after the line `--fs-4xl:  clamp(2.75rem, 2.20rem + 2.75vw, 4rem);`, insert:

```css
    /* Display tier — hero headline only. Larger than --fs-4xl, tighter than
       anything else on the site. */
    --fs-display: clamp(3.25rem, 2.4rem + 4.2vw, 5.5rem);
    --tracking-display: -0.035em;
```

After the `--tex-ink-warm: #f59e0b;` line, insert:

```css
    /* --- Brand gradient sweep -----------------------------------------------
       THE accent of the redesign. Used as: text-clip on one hero keyword,
       primary CTA fill, card hover glow, scroll progress. Never on body text. */
    --grad-brand: linear-gradient(120deg, #0d47a1, #2563eb 55%, #38bdf8);
    --grad-brand-soft: linear-gradient(120deg,
        rgba(13, 71, 161, 0.14), rgba(37, 99, 235, 0.14) 55%, rgba(56, 189, 248, 0.14));

    /* Aurora wash layers — composed into section backgrounds, ≤4% opacity so
       text contrast is untouched. */
    --aurora-blue: radial-gradient(52% 44% at 18% 22%, rgba(37, 99, 235, 0.05), transparent 70%);
    --aurora-sky:  radial-gradient(46% 40% at 84% 12%, rgba(56, 189, 248, 0.05), transparent 70%);
    --aurora-warm: radial-gradient(40% 36% at 70% 88%, rgba(245, 158, 11, 0.025), transparent 70%);
```

- [ ] **Step 2: Restyle section-header badges as editorial eyebrows**

In `css/03-components.css`, the current badge block (lines 6–31) styles every `.section-badge` as a tinted pill. Replace ONLY the section-header context (badges inside `.badge-wrapper`); standalone badges inside cards keep the pill. Replace the whole block from `.badge-wrapper {` through the `.section-badge::before` rule's closing `}` with:

```css
.badge-wrapper { text-align: center; margin-bottom: var(--sp-4); }

/* The leading dot is what turns a label into a badge. */
.section-badge {
    background: linear-gradient(180deg, #f0f9ff, #e0f2fe);
    border: 1px solid rgba(3, 105, 161, 0.16);
    box-shadow: var(--el-lip), 0 1px 2px rgba(15, 23, 42, 0.04);
    color: var(--badge-text);
    padding: 6px 12px 6px 10px;
    border-radius: var(--radius-pill);
    font-size: var(--fs-xs);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    display: inline-flex;
    align-items: center;
    gap: 7px;
}
.section-badge::before {
    content: '';
    width: 6px; height: 6px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.5;
    flex: none;
}

/* Section-header eyebrows — the editorial treatment. Quieter than a pill:
   bare letterspaced caps with a short amber rule. Card-level badges (work
   cards, dark CTA) are NOT inside .badge-wrapper and keep the pill above. */
.badge-wrapper .section-badge {
    background: none;
    border: 0;
    box-shadow: none;
    padding: 0;
    border-radius: 0;
    color: var(--ink-4);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.12em;
}
.badge-wrapper .section-badge::before {
    width: 20px; height: 2px;
    border-radius: 2px;
    background: var(--amber);
    opacity: 0.9;
}

/* Eyebrow on the dark CTA banner still needs to read on navy. */
.badge-wrapper .section-badge.is-on-dark {
    background: none;
    color: var(--sky-soft);
}
```

- [ ] **Step 3: Verify**

```bash
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8899/index.php   # expect 200
curl -s http://127.0.0.1:8899/index.php | grep -c "section-badge"          # expect ≥ 8 (unchanged markup)
```
Visual check: eyebrows above section titles are now quiet caps with an amber dash; the sector chips on work cards are still pills.

- [ ] **Step 4: Commit**

```bash
git add css/00-tokens.css css/03-components.css
git commit -m "redesign: display/gradient/aurora tokens, editorial eyebrow badges"
```

---

### Task 2: Aurora atmosphere + footer texture

**Files:**
- Modify: `css/08-texture.css` (append)
- Modify: `css/02-layout.css:72-78` (`.hero` background)
- Modify: `index.php:507` (pricing section class)
- Modify: `css/pages/service.css` (`.hero-card`)
- Modify: `css/05-footer.css:7-11` (`.site-footer`)
- Modify: `partials/footer.php:4` (footer class)

**Interfaces:**
- Consumes: `--aurora-blue`, `--aurora-sky`, `--aurora-warm` from Task 1.
- Produces: `.tex-aurora` utility class usable on any light section.

- [ ] **Step 1: Add the aurora utility**

Append to `css/08-texture.css`:

```css
/* --------------------------------------------------------------------------
   Aurora wash — faint drifting color atmosphere for light sections.
   Composed as background-image layers on the element itself (the ::before /
   ::after slots are already taken by mandala and grain), so it stacks with
   background-color and never affects text contrast (all layers ≤5% alpha).
   Drift is a slow background-position crawl; the global reduced-motion block
   freezes it. -------------------------------------------------------------- */
.tex-aurora {
    background-image: var(--aurora-blue), var(--aurora-sky), var(--aurora-warm);
    background-repeat: no-repeat;
    background-size: 160% 160%, 150% 150%, 140% 140%;
    animation: auroraDrift 120s var(--ease-in-out) infinite alternate;
}

@keyframes auroraDrift {
    from { background-position: 0% 0%,   100% 0%,  70% 100%; }
    to   { background-position: 30% 20%, 70% 25%,  45% 75%; }
}
```

- [ ] **Step 2: Hero gets the aurora (fold into its existing gradient)**

`.hero` (`css/02-layout.css:72`) already paints its own linear gradient, which would be overridden by the utility's `background-image`. Give the hero its own composed stack instead of the utility class. Replace:

```css
.hero {
    padding: clamp(140px, 14vh, 180px) var(--sp-5) var(--sp-11);
    background: linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
    text-align: center;
    position: relative;
    overflow: hidden;
}
```

with:

```css
.hero {
    padding: clamp(140px, 14vh, 180px) var(--sp-5) var(--sp-11);
    background-color: #eef2f7;
    background-image: var(--aurora-blue), var(--aurora-sky), var(--aurora-warm),
                      linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
    background-repeat: no-repeat;
    background-size: 160% 160%, 150% 150%, 140% 140%, 100% 100%;
    animation: auroraDrift 120s var(--ease-in-out) infinite alternate;
    text-align: center;
    position: relative;
    overflow: hidden;
}
```

Note: `auroraDrift` animates three aurora layers' positions; the fourth (linear) layer position is not listed in the keyframes, so it stays put — CSS repeats the last value.

- [ ] **Step 3: Pricing + service hero**

In `index.php:507`, change:

```html
<section class="section-container surface-light tex-grain tex-mandala plate-e" id="pricing">
```
to:
```html
<section class="section-container surface-light tex-grain tex-mandala plate-e tex-aurora" id="pricing">
```

In `css/pages/service.css`, find the `.hero-card` rule and add these declarations to it (composing with whatever background it has — if it declares `background:` shorthand, split it to `background-color:` first so the aurora layers survive):

```css
    background-image: var(--aurora-blue), var(--aurora-sky), var(--aurora-warm);
    background-repeat: no-repeat;
    background-size: 160% 160%, 150% 150%, 140% 140%;
    animation: auroraDrift 120s var(--ease-in-out) infinite alternate;
```

- [ ] **Step 4: Footer texture (spec correction #1 — stays dark)**

In `partials/footer.php:4`, change `<footer class="site-footer">` to `<footer class="site-footer tex-grain is-dark">`.

In `css/05-footer.css`, replace:

```css
.site-footer {
    background-color: var(--dark-bg);
    color: var(--slate-300);
    padding: 70px var(--sp-5) 0;
}
```

with:

```css
.site-footer {
    background-color: var(--dark-bg);
    color: var(--slate-300);
    padding: 70px var(--sp-5) 0;
    position: relative;
    border-top: 1px solid transparent;
}
/* Gradient hairline along the top edge — the light page hands off to the dark
   footer through a thin brand seam. */
.site-footer::before {
    content: '';
    position: absolute;
    top: -1px; left: 0; right: 0;
    height: 2px;
    background: var(--grad-brand);
    opacity: 0.85;
}
```

(`.tex-grain.is-dark::after` already exists in `08-texture.css:57` — the class addition is all the grain needs.)

- [ ] **Step 5: Verify**

```bash
php -l index.php && php -l partials/footer.php
curl -s http://127.0.0.1:8899/index.php | grep -c "tex-aurora"      # expect 1
curl -s http://127.0.0.1:8899/index.php | grep -c "site-footer tex-grain is-dark"  # expect 1
curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:8899/service.php?service=web-security"  # expect 200
```

- [ ] **Step 6: Commit**

```bash
git add css/08-texture.css css/02-layout.css css/05-footer.css css/pages/service.css index.php partials/footer.php
git commit -m "redesign: aurora atmosphere on hero/pricing/service, footer grain + brand seam"
```

---

### Task 3: Display typography + gradient keyword + trust numerals

**Files:**
- Modify: `css/02-layout.css:87-92` (`.hero h1`)
- Modify: `css/pages/home.css` (append gradient keyword rule)
- Modify: `css/03-components.css:259` (`.trust-stat h3`)

**Interfaces:**
- Consumes: `--fs-display`, `--tracking-display`, `--grad-brand` (Task 1).
- Produces: nothing consumed later.

- [ ] **Step 1: Hero headline to display tier**

In `css/02-layout.css`, replace:

```css
.hero h1 {
    font-size: var(--fs-4xl);
    font-weight: 800;
    color: var(--dark-bg);
    margin-bottom: var(--sp-5);
}
```

with:

```css
.hero h1 {
    font-size: var(--fs-display);
    font-weight: 800;
    letter-spacing: var(--tracking-display);
    line-height: 1.05;
    color: var(--dark-bg);
    margin-bottom: var(--sp-5);
}
```

- [ ] **Step 2: Gradient keyword (spec correction #4 — CSS targets the split word, no markup change)**

Append to `css/pages/home.css`:

```css
/* --------------------------------------------------------------------------
   Gradient keyword. split-text rebuilds the h1 into .split-word spans, so the
   last word ("Smarter.") is targeted positionally — inner markup would be
   destroyed by the splitter (motion.js setupSplitText). Fallback path: before
   JS runs there are no spans, and browsers without background-clip get the
   solid heading color from .hero h1. */
@supports (-webkit-background-clip: text) or (background-clip: text) {
    .hero h1 .split-word:last-child {
        background: var(--grad-brand);
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        color: transparent;
    }
}
```

- [ ] **Step 3: Trust numerals go editorial**

In `css/03-components.css`, replace:

```css
.trust-stat h3 { font-size: 34px; font-weight: 800; color: var(--primary-color); margin-bottom: 4px; font-variant-numeric: tabular-nums; }
```

with:

```css
.trust-stat h3 {
    font-family: var(--font-head);
    font-size: var(--fs-3xl);
    font-weight: 700;
    letter-spacing: var(--tracking-tight);
    color: var(--primary-color);
    margin-bottom: 4px;
    font-variant-numeric: tabular-nums;
}
```

- [ ] **Step 4: Verify**

```bash
curl -s http://127.0.0.1:8899/index.php | grep -c 'data-animate="split-text"'  # expect 1 (markup untouched)
```
Visual check at 1400px and 375px widths: headline larger but not clipping; last word gradient once JS runs; trust numbers larger.

- [ ] **Step 5: Commit**

```bash
git add css/02-layout.css css/pages/home.css css/03-components.css
git commit -m "redesign: display-tier hero type, gradient keyword, editorial trust numerals"
```

---

### Task 4: Button system + focus rings

**Files:**
- Modify: `css/03-components.css:62-77` (`.btn-primary`), `:90-99` (`.btn-consultation`)
- Modify: `css/01-reset.css` (append focus-visible rule)

- [ ] **Step 1: Primary buttons take the brand sweep**

In `css/03-components.css`, replace the `.btn-primary` background line:

```css
    background: linear-gradient(180deg, var(--secondary-color), var(--primary-color));
```
(inside the `.btn-primary { ... }` rule at line 62) with:

```css
    background: var(--grad-brand);
    background-size: 150% 100%;
    background-position: 0% 0%;
```

and add to `.btn-primary:hover` (alongside its existing declarations):

```css
    background-position: 60% 0%;
```

and extend the shared transition rule at line 51 — replace:

```css
    transition: transform 260ms var(--ease-out),
                box-shadow 260ms var(--ease-out),
                filter 260ms var(--ease-out);
```
with:
```css
    transition: transform 260ms var(--ease-out),
                box-shadow 260ms var(--ease-out),
                filter 260ms var(--ease-out),
                background-position 400ms var(--ease-out);
```

Apply the same background swap to `.btn-consultation` (line 90): replace its `background: linear-gradient(180deg, var(--secondary-color), var(--primary-color));` with the same three `background*` lines as `.btn-primary`.

Ghost/secondary (`.btn-dark-pill`) and WhatsApp buttons keep their identity — physics already match. No change.

- [ ] **Step 2: Consistent focus rings**

Append to `css/01-reset.css`:

```css
/* --------------------------------------------------------------------------
   Focus — one visible ring everywhere. :focus-visible keeps mouse clicks
   clean while keyboard focus is unmistakable. --------------------------- */
:focus-visible {
    outline: 2px solid var(--secondary-color);
    outline-offset: 2px;
    border-radius: 2px;
}
```

- [ ] **Step 3: Verify**

Visual: primary CTAs show the blue sweep, hover slides the gradient subtly and lifts. Keyboard-tab through the homepage: every link/button shows the ring.
```bash
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8899/index.php  # 200
```

- [ ] **Step 4: Commit**

```bash
git add css/03-components.css css/01-reset.css
git commit -m "redesign: brand-sweep primary buttons, universal focus-visible rings"
```

---

### Task 5: Card glow + featured halo

**Files:**
- Modify: `css/03-components.css:165-179` (card `::before` hover hairline)
- Modify: `css/pages/home.css` (append halo rule)

- [ ] **Step 1: Upgrade the hover hairline to a gradient edge-glow**

In `css/03-components.css`, replace the card `::before` block (lines 167–179):

```css
.challenge-card::before, .service-card::before, .work-card::before, .price-card::before {
    content: '';
    position: absolute;
    inset: 0 0 auto 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--sky), transparent);
    opacity: 0;
    transition: opacity 300ms var(--ease-out) 80ms;
    pointer-events: none;
    z-index: 2;
}
.challenge-card:hover::before, .service-card:hover::before,
.work-card:hover::before, .price-card:hover::before { opacity: 1; }
```

with:

```css
/* Gradient edge-glow on hover: a 1px brand-gradient frame drawn by a masked
   pseudo-element (padding-box mask knocks out the middle), so it follows any
   radius with no extra markup. The last beat of the hover sequence. */
.challenge-card::before, .service-card::before, .work-card::before,
.price-card::before, .blog-card::before, .testimonial-card::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: inherit;
    padding: 1px;
    background: var(--grad-brand);
    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
            mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
            mask-composite: exclude;
    opacity: 0;
    transition: opacity 300ms var(--ease-out) 80ms;
    pointer-events: none;
    z-index: 2;
}
.challenge-card:hover::before, .service-card:hover::before,
.work-card:hover::before, .price-card:hover::before,
.blog-card:hover::before, .testimonial-card:hover::before { opacity: 0.55; }
```

Also add `.testimonial-card:hover` and `.blog-card:hover` to the existing lift rule at line 158 if not present — the selector list should read:

```css
.challenge-card:hover, .service-card:hover, .solution-card:hover,
.work-card:hover, .price-card:hover, .blog-card:hover, .card:hover,
.testimonial-card:hover {
    transform: translateY(-6px);
    box-shadow: var(--el-3), var(--el-lip);
    border-color: var(--hair-2);
}
```

**Caution:** `.blog-card` in `css/pages/insights.css` and `insight.css` has its own hover (`translateY(-4px)` etc.). Page CSS loads after components and wins — remove the duplicate hover rule from `css/pages/insights.css` (line ~35 `.blog-card:hover { ... }`) so the shared physics apply.

- [ ] **Step 2: Featured pricing halo**

Append to `css/pages/home.css`:

```css
/* Featured tier gets a permanent soft aurora halo — hierarchy visible before
   any copy is read. Blur on a pseudo-element, behind the card. */
.price-card.is-featured { z-index: 1; }
.price-card.is-featured::after {
    content: '';
    position: absolute;
    inset: -14px;
    border-radius: inherit;
    background: var(--grad-brand-soft);
    filter: blur(22px);
    z-index: -1;
    pointer-events: none;
}
```

(Check first: if `.price-card.is-featured` already defines `::after` in `home.css`, use a different hook — `box-shadow: 0 0 0 1px var(--hair-2), 0 18px 60px rgba(37, 99, 235, 0.18);` on the card itself instead.)

- [ ] **Step 3: Verify**

Visual: hovering any card shows a faint gradient frame; middle pricing card has a soft glow at rest.
```bash
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8899/index.php   # 200
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8899/insights.php # 200
```

- [ ] **Step 4: Commit**

```bash
git add css/03-components.css css/pages/home.css css/pages/insights.css
git commit -m "redesign: gradient edge-glow card hover, featured pricing halo"
```

---

### Task 6: Glass navigation + brand progress bar

**Files:**
- Modify: `css/04-nav.css:5-28`

- [ ] **Step 1: Header goes glass**

Replace (`css/04-nav.css:5-17`):

```css
header {
    background-color: var(--white);
    position: fixed;
    width: 100%;
    top: 0; left: 0;
    z-index: var(--z-header);
    box-shadow: var(--shadow-md);
    transition: transform var(--dur-2) var(--ease-out), box-shadow var(--dur-2) var(--ease-out);
}

/* Hide-on-scroll-down, reveal-on-scroll-up. */
header.is-hidden { transform: translateY(-100%); }
header.scrolled { box-shadow: 0 6px 24px rgba(0, 0, 0, 0.10); }
```

with:

```css
header {
    background-color: rgba(255, 255, 255, 0.86);
    position: fixed;
    width: 100%;
    top: 0; left: 0;
    z-index: var(--z-header);
    box-shadow: none;
    border-bottom: 1px solid transparent;
    transition: transform var(--dur-2) var(--ease-out),
                box-shadow var(--dur-2) var(--ease-out),
                border-color var(--dur-2) var(--ease-out);
}

/* Glass where supported; the translucent white above is the fallback. */
@supports (backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px)) {
    header {
        background-color: rgba(255, 255, 255, 0.72);
        -webkit-backdrop-filter: blur(14px) saturate(1.4);
        backdrop-filter: blur(14px) saturate(1.4);
    }
}

/* Hide-on-scroll-down, reveal-on-scroll-up. */
header.is-hidden { transform: translateY(-100%); }

/* The hairline and shadow only exist once there is content to float over. */
header.scrolled {
    border-color: var(--hair-1);
    box-shadow: 0 6px 24px rgba(15, 23, 42, 0.06);
}
```

**Caution:** if any dropdown/mega-menu panel in `04-nav.css` is a child of `header`, `backdrop-filter` creates a containing block — verify the dropdown still positions correctly after this change; if it breaks, move the glass onto `.navbar`'s parent wrapper instead.

- [ ] **Step 2: Progress bar takes the brand gradient (spec correction #2)**

In the `.scroll-progress` rule (line 20), replace:

```css
    background: linear-gradient(90deg, var(--primary-color), var(--sky));
```
with:
```css
    background: var(--grad-brand);
```
and change `height: 3px;` to `height: 2px;`.

- [ ] **Step 3: Verify**

Visual: scroll the homepage — header blurs content behind it, hairline appears after 20px scroll, dropdowns still open in place, progress bar is the brand sweep.

- [ ] **Step 4: Commit**

```bash
git add css/04-nav.css
git commit -m "redesign: glass header with scroll hairline, brand-gradient progress bar"
```

---

### Task 7: Motion polish — reveal distances + satellite idle drift

**Files:**
- Modify: `css/06-animations.css:57-119`
- Modify: `css/pages/home.css:126-142` (hero scene `.sat` rules)

- [ ] **Step 1: Normalize reveal distance to 12px**

In `css/06-animations.css`:
- Line 59: `.reveal` — `transform: translateY(28px);` → `translateY(12px)`
- Line 83: `[data-animate="fade-up"]    { transform: translateY(28px); }` → `translateY(12px)`
- Line 84: `[data-animate="fade-left"]  { transform: translateX(28px); }` → `translateX(12px)`
- Line 85: `[data-animate="fade-right"] { transform: translateX(-28px); }` → `translateX(-12px)`
- Line 116 (stagger children): `transform: translateY(24px);` → `translateY(12px)`

- [ ] **Step 2: Satellite idle drift**

In `css/pages/home.css`, replace:

```css
.hero-scene.is-ready .sat           { animation: satIn 620ms var(--ease-spring) backwards; }
```
with:
```css
.hero-scene.is-ready .sat           { animation: satIn 620ms var(--ease-spring) backwards,
                                                 satDrift 8s ease-in-out 2.2s infinite alternate; }
```

and replace the per-satellite delay rules:

```css
.hero-scene.is-ready .sat:nth-of-type(1) { animation-delay: 480ms; }
.hero-scene.is-ready .sat:nth-of-type(2) { animation-delay: 590ms; }
.hero-scene.is-ready .sat:nth-of-type(3) { animation-delay: 700ms; }
.hero-scene.is-ready .sat:nth-of-type(4) { animation-delay: 810ms; }
.hero-scene.is-ready .sat:nth-of-type(5) { animation-delay: 920ms; }
```

with two-value delays (first = load-in, second = drift phase offset so the five never move in sync):

```css
.hero-scene.is-ready .sat:nth-of-type(1) { animation-delay: 480ms, 2.2s; }
.hero-scene.is-ready .sat:nth-of-type(2) { animation-delay: 590ms, 3.1s; }
.hero-scene.is-ready .sat:nth-of-type(3) { animation-delay: 700ms, 2.6s; }
.hero-scene.is-ready .sat:nth-of-type(4) { animation-delay: 810ms, 3.7s; }
.hero-scene.is-ready .sat:nth-of-type(5) { animation-delay: 920ms, 2.9s; }
```

then append the keyframes near the other hero keyframes in `home.css`:

```css
/* Idle drift — 3px of slow wander so the scene never fully freezes. Uses the
   same transform-box discipline as .float-el. */
@keyframes satDrift {
    from { translate: 0 0; }
    to   { translate: 2px -3px; }
}
```

**Note:** `satDrift` uses the `translate` property (not `transform`) deliberately — `satIn` animates `transform`, and two animations fighting over `transform` would cancel; `translate` composes with it.

- [ ] **Step 3: Verify**

Visual: hero satellites drift gently after load-in, each on its own phase; reveals across the site feel tighter (shorter travel). Reduced-motion (DevTools emulation) shows everything static.

- [ ] **Step 4: Commit**

```bash
git add css/06-animations.css css/pages/home.css
git commit -m "redesign: 12px reveal travel, hero satellite idle drift"
```

---

### Task 8: Article page polish

**Files:**
- Modify: `css/pages/insight.css`

- [ ] **Step 1: Body size +1, gradient link underlines**

In `css/pages/insight.css`, in `.insight-body` change `font-size: var(--fs-base, 16px);` to `font-size: calc(var(--fs-base, 16px) + 1px);`.

Replace:

```css
.insight-body a {
    color: var(--primary-color);
    text-decoration: underline;
    text-underline-offset: 2px;
}

.insight-body a:hover { text-decoration-thickness: 2px; }
```

with:

```css
/* Gradient underline: painted as a background layer so it can carry the brand
   sweep; grows on hover. Falls back to nothing exotic — the color alone still
   marks the link. */
.insight-body a {
    color: var(--primary-color);
    text-decoration: none;
    background-image: var(--grad-brand);
    background-repeat: no-repeat;
    background-size: 100% 1px;
    background-position: 0 100%;
    transition: background-size var(--dur-1) var(--ease-out);
}

.insight-body a:hover { background-size: 100% 2px; }
```

- [ ] **Step 2: Verify**

```bash
curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:8899/insight.php?post=bundled-packages-vs-freelancers"  # 200
```
Visual: article links show gradient underline, thicken on hover; body text a touch larger. (The reading-progress bar is the sitewide `.scroll-progress`, already gradient after Task 6.)

- [ ] **Step 3: Commit**

```bash
git add css/pages/insight.css
git commit -m "redesign: article body size, gradient link underlines"
```

---

### Task 9: SVG illustration depth pass

**Files:**
- Modify: `partials/illustrations.php` (all seven scenes)

**Interfaces:** none — self-contained rendering.

- [ ] **Step 1: Apply the depth recipe to each scene**

Read the full file first. For each of the seven scenes (`fragmented`, `delays`, `insecure`, `team`, `growth`, `orbit`, `work-cover`) apply exactly these transformations:

1. **Gradient fills.** Each scene's `<defs>` gets gradients with a scene-unique ID prefix (`fg-` for fragmented already exists as `fg1`; use `dl-`, `in-`, `tm-`, `gr-`, `or-`, `wc-` for the others — unique IDs because two scenes can render on one page). Every flat brand-blue `fill="#0d47a1"` / `fill="#1565c0"` / `fill="#60a5fa"` on a major shape becomes a 2-stop linear gradient of the same hue family, e.g.:

```xml
<linearGradient id="dl-a" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
</linearGradient>
```

Small detail shapes (<20px) keep flat fills — gradient noise at that size reads as banding.

2. **Cast shadow.** Under the scene's primary foreground group, insert one soft ellipse (before the group in document order so it paints beneath):

```xml
<ellipse cx="[center-x of main group]" cy="[baseline-y + 8]" rx="[~60% of group width]" ry="7" fill="#0f172a" opacity="0.08"/>
```

3. **Amber accent.** Exactly one small element per scene switches to `#f59e0b` (or is added): a node dot, a chip, a highlight bar — whichever the scene's composition supports. Scenes that already use amber (`delays` has the deadline marker) count as done.

4. **Glass chip highlight (hero scene only).** In `css/pages/home.css`, the `.scene-chip` rule gets `box-shadow: inset 0 1px 0 rgba(255,255,255,0.55), var(--el-1);` added if not already equivalent.

- [ ] **Step 2: Verify**

```bash
php -l partials/illustrations.php
for p in index.php about.php insights.php; do curl -s -o /dev/null -w "%{http_code}  $p\n" http://127.0.0.1:8899/$p; done   # all 200
curl -s http://127.0.0.1:8899/about.php | grep -oE 'id="(dl|in|tm|gr|or|wc)-[a-z]+"' | sort | uniq -d   # expect EMPTY (no duplicate IDs)
```
Visual: scenes show subtle depth, one warm accent each, no rendering glitches on pages showing two scenes (insights.php shows `orbit` + `team`).

- [ ] **Step 3: Commit**

```bash
git add partials/illustrations.php css/pages/home.css
git commit -m "redesign: gradient depth, cast shadows and amber accents across SVG scenes"
```

---

### Task 10: Full verification + budget + wrap-up

**Files:**
- Modify: `CONTENT-CHECKLIST.md` only if anything it states became false (unlikely).

- [ ] **Step 1: CSS budget**

```bash
ls css/*.css css/pages/*.css | xargs wc -c | tail -1
```
Expected: ≤ 143900. If over, trim comments from the newest additions first.

- [ ] **Step 2: Smoke every route**

```bash
for p in "" index.php about.php "service.php?service=web-development" "service.php?service=web-security" insights.php "insight.php?post=bundled-packages-vs-freelancers" privacy.php sitemap.php 404.php thank-you.php; do
  curl -s -o /dev/null -w "%{http_code}  /$p\n" "http://127.0.0.1:8899/$p"
done
```
Expected: 200 everywhere except `404.php` → 404 and `thank-you.php` → 302.

- [ ] **Step 3: Regression greps**

```bash
curl -s http://127.0.0.1:8899/index.php | grep -c "is-placeholder"          # expect 8 (CMS badge logic untouched)
curl -s http://127.0.0.1:8899/insights.php | grep -c 'href="#"'             # expect 0
php -l index.php && php -l partials/footer.php && php -l partials/illustrations.php
```

- [ ] **Step 4: Visual + accessibility sweep (manual, in browser)**

- 375px, 768px, 1440px: hero headline never clips; aurora invisible as "color blobs" (should read as atmosphere); glass nav dropdowns open correctly.
- Keyboard-tab the homepage end to end: visible ring on every stop.
- DevTools reduced-motion emulation: no movement anywhere.
- DevTools Lighthouse quick run on `/index.php`: performance and accessibility not lower than pre-change baseline.

- [ ] **Step 5: Final commit + report**

```bash
git status --short   # expect clean or only intended files
git log --oneline -12
```
Report to the user: what changed per page, the budget number, and anything deferred.

---

## Self-review notes

- **Spec coverage:** every spec section maps to a task — typography (T3), color (T1/T3/T4), surfaces/texture (T2), components (T4/T5/T6), motion (T7), illustrations (T9), article (T8), a11y/perf (T4 step 2, T10). Spec items already satisfied by the codebase are recorded as corrections 2 and 3 rather than dropped silently.
- **Type consistency:** token names (`--fs-display`, `--grad-brand`, `--grad-brand-soft`, `--aurora-*`) are defined in T1 and referenced identically in T2–T8.
- **Known risks called out inline:** dropdown positioning under `backdrop-filter` (T6), `transform` vs `translate` animation collision (T7), page-CSS hover overrides (T5), split-text span destruction (T3/correction 4).
