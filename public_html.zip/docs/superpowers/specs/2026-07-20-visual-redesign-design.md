# Editorial Premium Redesign — Design Spec

**Date:** 2026-07-20
**Scope:** Public pages only (home, about, service, insights, insight, privacy, 404, thank-you). Admin untouched.
**Approach:** Approved — "Editorial premium": transform type, color, texture, illustrations and motion through the existing token system. Markup and IA mostly untouched; CMS wiring untouched.

## Constraints (non-negotiable)

- Light theme throughout — user decision ("jaise light h waise hi").
- No build step, no JS libraries, no external requests. CSP stays `script-src 'self'`; all assets self-hosted.
- Vector-first imagery: no downloaded photos or 3D renders. The hand-drawn SVG system is upgraded, not replaced.
- All contrast stays WCAG AA. `prefers-reduced-motion` fully honored.
- Total CSS growth budget: ~8 KB across all files.
- Existing CMS-driven sections (case studies, testimonials, trust bar, posts) keep their markup contracts — class names used by PHP loops must not change semantics.

## 1. Typography

- New display tier in `00-tokens.css`: `--fs-display: clamp(3.25rem, 2.4rem + 4.2vw, 5.5rem)`, tracking `-0.035em`, line-height `1.05`. Hero headline only.
- Section titles move up one step (use `--fs-3xl` where `--fs-2xl` is used today).
- Eyebrow labels: replace pill-badge styling with uppercase 11px, letter-spacing `0.12em`, `--ink-4` color, optional short rule before the text. The `.section-badge` class is restyled, not renamed.
- Article body (`insight.css`): base size up ~1px, measure unchanged.

## 2. Color

- Brand sweep gradient token: `--grad-brand: linear-gradient(120deg, #0d47a1, #2563eb 55%, #38bdf8)`.
- Used for: text-clip on ONE keyword per hero headline (solid `--primary-color` fallback via `@supports`), primary CTA fill, card hover border-glow, article link underlines, reading progress bar.
- Amber `#f59e0b` promoted to intentional accent: placeholder badges, one stat highlight, one accent element per SVG scene. Never for body text.
- Everything else stays in the existing slate ramp and plane system.

## 3. Surfaces & texture

- Aurora wash utility (in `08-texture.css`): two fixed radial gradients — blue at 3–4% opacity, amber at 2% — applied to hero and pricing sections. Slow drift animation (90s+), disabled under reduced motion.
- Grain texture extended to hero and pricing (classes already exist in `08-texture.css`).
- Footer: navy-tinted light surface (`--tint-blue` family) + grain + hairline top. Stays light.

## 4. Components

- **Primary button:** `--grad-brand` fill, `--el-brand` shadow, inset light lip, hover = 2px lift + glow intensify, active = press down 1px. Transition on transform/box-shadow only.
- **Secondary button:** ghost — transparent fill, `--hair-1` border, hover fills `--tint-blue`, border to `--hair-2`.
- **WhatsApp button:** keeps green identity, inherits identical physics.
- **Cards:** rest = `--hair-1` border + `--el-1`; hover = `--el-2`, `translateY(-4px)`, gradient border-glow via absolutely-positioned `::before` (padding-box mask trick, no markup change). Applies to `.price-card`, `.work-card`, `.blog-card`, `.testimonial-card`, `.card-display`.
- **Featured cards** (`.is-featured`, featured testimonial): permanent soft aurora halo (blurred gradient pseudo-element behind the card).
- **Nav:** glass — `backdrop-filter: blur(14px) saturate(1.4)` over `rgba(255,255,255,0.72)`; hairline bottom edge appears only after scroll (JS scroll flag exists in app.js — add class hook if missing). Dropdown panels get the same glass. Solid-white fallback where `backdrop-filter` unsupported.
- **Focus rings:** consistent `outline: 2px solid var(--secondary-color); outline-offset: 2px` on all interactive elements via `:focus-visible`.

## 5. Motion

- Normalize reveal distance to 12px across all `data-animate` variants (`06-animations.css`).
- Stagger uses `--stagger` token everywhere.
- Hero scene: keep load-in choreography; add idle drift to satellites (translate 2–3px, 6–9s alternate loops, distinct phases).
- Put unused `data-animate="draw"` to work on SVG scene strokes entering viewport.
- Article reading progress bar: thin `--grad-brand` bar fixed under header, `animation-timeline: scroll()` — pure CSS, no JS; absent on browsers without support (progressive enhancement).
- FAQ accordion: smoother open via `grid-template-rows` transition (0fr→1fr) if not already.
- All of the above inside `@media (prefers-reduced-motion: no-preference)` or neutralized by the existing reduced-motion block.

## 6. SVG illustration upgrade (`partials/illustrations.php`)

All seven scenes (`fragmented`, `delays`, `insecure`, `team`, `growth`, `orbit`, `work-cover`):

- Flat fills → subtle linear gradients (2 stops, same hue family).
- Key foreground shapes gain one soft cast shadow (blurred ellipse, ~8% opacity).
- One amber accent element per scene.
- Stroke paths tagged for `data-animate="draw"` where the scene benefits.
- Hero scene: richer gradient core, glass highlight on stat chips.
- `<defs>` gradients get per-scene ID prefixes to avoid collisions when two scenes render on one page.

## 7. Per-page notes

- **Home:** display headline + gradient keyword; aurora hero + pricing; trust-bar numerals in Space Grotesk at `--fs-3xl`; new card/button system throughout; featured pricing halo.
- **About / Insights:** inherit foundations; richer scenes; new blog-card hover.
- **Article:** progress bar; body type +1px; gradient link underlines.
- **Service:** aurora on hero band; FAQ physics.
- **Privacy / 404 / thank-you:** inherit tokens; visual check only.

## 8. Accessibility & performance

- Gradient text always has solid fallback; AA contrast maintained (aurora ≤4% opacity cannot affect text contrast).
- Focus-visible rings everywhere; skip-link kept.
- Zero new HTTP requests, zero JS added beyond small hooks in existing files.
- Lighthouse target: no regression; CSS budget ~8 KB total growth.

## Out of scope

Admin panel styling; dark mode; new photography/3D assets; IA/layout restructuring; pricing content changes.
