<?php
require __DIR__ . '/inc/bootstrap.php';

$page = [
    'id'        => 'insights',
    'title'     => 'Insights | Rafly Digital Growth',
    'desc'      => 'Notes on bundled digital growth, web security, content, marketing, and the systems we build behind every package.',
    'bodyClass' => 'page-insights',
    'styles'    => ['insights'],
];
/**
 * Published posts, newest first.
 *
 * db_available() never throws, so a database that is down degrades to a section
 * with no cards rather than a fatal error on a page whose other two-thirds are
 * static and perfectly serviceable.
 */
$posts = db_available()
    ? all(
        "SELECT slug, title, tag, excerpt
           FROM posts
          WHERE status = 'published'
            AND published_at IS NOT NULL
            AND published_at <= now()
       ORDER BY published_at DESC"
    )
    : [];

if ($posts) {
    $page['schema'][] = schema_collection_list(
        'Insights',
        'insights',
        array_map(
            static fn(array $p): array => ['name' => $p['title'], 'url' => 'insights/' . rawurlencode((string)$p['slug'])],
            $posts
        )
    );
}

require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="insights-hero">
        <h1 style="font-size:36px; margin-bottom:10px;">Rafly Insights</h1>
        <p>Notes on bundled digital growth, web security, content, marketing, and the systems we build behind every package.</p>
    </section>

    <!-- Deep-Dive Corporate Metrics Section Layout -->
    <div class="content-section">
        <div class="grid-2">
            <div class="card-display">
                <h3>Our Operational Core</h3>
                <p style="line-height:1.7; font-size:15px; margin-bottom:15px;">Rafly runs every engagement through one coordinated team instead of scattered vendors. We plan, build, and review website, content, marketing, and e-commerce work together, so nothing falls through the cracks between departments that don't talk to each other.</p>
                <p style="line-height:1.7; font-size:15px;">Every project includes a baseline security pass on forms, sessions, and access handling — whether or not it was the reason you called us.</p>
            </div>
            <?php
            /* No data-animate="mask-reveal" here, deliberately. That primitive
               clips the element to zero width until JS reveals it, which on a
               photograph means an empty box if the reveal is ever delayed or
               fails — the exact bug that made these images invisible before.
               The section around it still fades in. */
            ?>
            <div class="illustration-box is-photo is-tinted">
                <img src="<?= e(asset('assets/photos/engineer-server-room.jpg')) ?>"
                     alt="An engineer holding a laptop beside a rack of servers"
                     width="1400" height="935" loading="lazy" decoding="async">
            </div>
        </div>

        <div class="grid-2">
            <div class="illustration-box is-photo is-tinted">
                <img src="<?= e(asset('assets/photos/developer-desk.jpg')) ?>"
                     alt="Two developers reviewing code together on screen"
                     width="1400" height="934" loading="lazy" decoding="async">
            </div>
            <div class="card-display">
                <h3>Engineering & Solution Teams</h3>
                <p style="line-height:1.7; font-size:15px; margin-bottom:15px;">Our specialists cover web architecture, content strategy, paid and organic marketing, and e-commerce operations — briefed on the same goals, working from the same plan.</p>
                <p style="line-height:1.7; font-size:15px;">Work is scoped in clear bundled packages with defined deliverables, so progress is easy to track and there's no ambiguity about what's included.</p>
            </div>
        </div>

        <!-- NEW: Notes from the Build - Sample Blog Preview Section -->
        <section style="margin-top: 70px;">
            <div class="badge-wrapper" style="text-align:left;"><span class="section-badge" style="background-color:#e0f2fe; color:#0369a1;">Notes From The Build</span></div>
            <h2 style="font-size:30px; color:var(--dark-bg); margin-bottom:10px; font-weight:800;">From The Team Behind Your Package</h2>
            <p style="font-size:15px; color:var(--text-main); max-width:700px; margin-bottom:35px;">Field notes on what's working, what isn't, and what we're building next — written by the people doing the work.</p>
            <?php if ($posts): ?>
                <div class="blog-grid">
                    <?php foreach ($posts as $p): ?>
                        <article class="blog-card">
                            <?php if (!empty($p['tag'])): ?>
                                <div class="blog-card-tag"><?= e((string)$p['tag']) ?></div>
                            <?php endif; ?>
                            <h4><?= e((string)$p['title']) ?></h4>
                            <p><?= e(str_cut((string)$p['excerpt'], 150)) ?></p>
                            <a href="/insights/<?= e(rawurlencode((string)$p['slug'])) ?>" class="blog-read-more">
                                Read More <?= icon('arrow-right') ?>
                            </a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="font-size:15px; color:var(--text-main);">
                    New notes are on the way — <a href="<?= e(whatsapp_link('Hi Rafly team, I would like to hear about your work.')) ?>" target="_blank" rel="noopener">message us</a>
                    in the meantime and we'll answer directly.
                </p>
            <?php endif; ?>
        </section>
    </div>

</main>

<?php require __DIR__ . "/partials/tail.php"; ?>
