<?php
require __DIR__ . '/inc/bootstrap.php';

/**
 * Full case-studies page — Problem -> Approach -> Result per client, versus
 * the homepage's #work section which only ever shows a 3-card snippet.
 *
 * admin/case-studies.php already collects `problem` separately from `action`
 * specifically "kept for a future detail page" (its own comment says so) —
 * this is that page. Nothing new to enter; existing rows already have both
 * fields, they just were never both rendered anywhere until now.
 */

$caseStudies = db_available()
    ? all("SELECT client_name, sector, problem, action, metric_value, metric_label,
                  is_placeholder, tags
             FROM case_studies
            WHERE is_published
         ORDER BY sort_order, id")
    : [];

$page = [
    'id'        => '',
    'title'     => 'Case Studies | Rafly Digital Growth',
    'desc'      => 'How bundled delivery actually plays out — the problem, our approach, and the measurable result for each engagement.',
    'bodyClass' => 'page-case-studies',
    'styles'    => ['home', 'about'],
    'schema'    => array_filter([
        schema_breadcrumbs($crumbs = [
            ['name' => 'Home',          'url' => '/'],
            ['name' => 'Case Studies',  'url' => '/case-studies'],
        ]),
        // Each card gets an id="case-study-N" anchor above so this ItemList
        // can point at a genuinely distinct URL per item, not the same page
        // URL repeated — that's what makes an ItemList meaningful here versus
        // a bare list of names.
        $caseStudies ? schema_collection_list(
            'Case Studies',
            'case-studies',
            array_map(
                static fn(int $i, array $w): array => ['name' => (string)$w['client_name'], 'url' => 'case-studies#case-study-' . $i],
                array_keys($caseStudies),
                $caseStudies
            )
        ) : null,
    ]),
];
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="hero tex-grain">
        <div class="hero-container is-single">
            <?= breadcrumbs($crumbs) ?>
            <div class="hero-copy">
                <div class="badge-wrapper"><span class="section-badge">Case Studies</span></div>
                <h1>What bundled delivery looks like in practice.</h1>
                <p>Every card below follows the same shape: the problem as the client described it, what we actually did about it, and one evidenced result — not a vanity metric picked to look good.</p>
            </div>
        </div>
    </section>

    <section class="section-container">
<?php if (!$caseStudies): ?>
        <div class="empty-state" style="text-align:center; padding: var(--sp-8) 0;">
            <p class="muted">No case studies published yet — check back soon, or <a href="/#contact">get in touch</a> to be our first.</p>
        </div>
<?php else: ?>
        <div class="case-study-list">
<?php foreach ($caseStudies as $i => $w):
        $tags = array_values(array_filter(array_map('trim', explode(',', (string)$w['tags'])), 'strlen'));
        $isPlaceholder = !empty($w['is_placeholder']);
?>
            <article class="card case-study-detail<?= $isPlaceholder ? ' is-placeholder' : '' ?>" id="case-study-<?= (int)$i ?>">
                <div class="badge-wrapper"><span class="section-badge"><?= e((string)$w['sector']) ?></span></div>
                <h2><?= e((string)$w['client_name']) ?></h2>

                <div class="case-study-metric">
                    <span class="work-metric"><?= e((string)$w['metric_value']) ?></span>
                    <span class="muted"><?= e((string)$w['metric_label']) ?></span>
                </div>

<?php if (trim((string)$w['problem']) !== ''): ?>
                <h3>Problem</h3>
                <p><?= nl2br(e((string)$w['problem'])) ?></p>
<?php endif; ?>

<?php if (trim((string)$w['action']) !== ''): ?>
                <h3>Approach</h3>
                <p><?= nl2br(e((string)$w['action'])) ?></p>
<?php endif; ?>

                <h3>Result</h3>
                <p><strong><?= e((string)$w['metric_value']) ?></strong> — <?= e((string)$w['metric_label']) ?></p>

<?php if ($tags): ?>
                <div class="work-tags">
                    <?php foreach ($tags as $t): ?><span><?= e($t) ?></span><?php endforeach; ?>
                </div>
<?php endif; ?>
            </article>
<?php endforeach; ?>
        </div>
<?php endif; ?>

        <p class="muted" style="text-align:center; margin-top:var(--sp-6); font-size:var(--fs-sm)">
            Want a similar result? <a href="/#contact">Request a free consultation</a>.
        </p>
    </section>
</main>
<?php require __DIR__ . "/partials/tail.php"; ?>
