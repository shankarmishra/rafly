# Content checklist

What the site still needs from you before launch.

This replaces an earlier version written before the admin panel existed. Most of
what it listed is now done, and the parts that remain no longer involve editing
PHP — content lives in the database and is edited at `/admin`.

**Anything marked BLOCKS LAUNCH is either visible to visitors as a placeholder,
or is a claim that could be challenged.**

---

## 1. BLOCKS LAUNCH — Case studies

**Where:** `/admin/case-studies.php` · **Renders:** homepage `#work`

Three cards, all flagged as placeholders. They currently show invented metrics
(`+182%`, `3.4x`, `0 incidents`) against the client name "Client Project", and
each says *"example card; a real case study replaces this."*

For each of three projects:

- Client name — or "a Kolkata-based D2C brand" if they have not consented to be named
- The problem, and what you did
- **One measurable outcome you can evidence**

Untick **"Is placeholder"** once a card holds real content. That is what removes
the orange badge — there is no code change.

> The invented metrics are the highest-risk content on the site. A prospect who
> asks "which client was the 182%?" and gets a pause has learned something you
> cannot walk back.

---

## 2. BLOCKS LAUNCH — Testimonials

**Where:** `/admin/testimonials.php` · **Renders:** homepage

Three quotes, all attributed to `[Client Name]`. The quotes read well and are
plausible — they need real attribution: name, role, company.

Each card stays badged until **both** are true:

1. **Is placeholder** is unticked, and
2. **Consent given** is ticked

The consent gate is deliberate. Publishing a named client without permission is
the expensive kind of mistake, so filling in a name alone will not remove the
badge.

---

## 3. BLOCKS LAUNCH — Trust-bar figures

**Where:** `/admin/settings.php` · **Renders:** homepage trust bar

`120 Projects Delivered` and `98% Client Satisfaction` are badged as unverified.
Either confirm each number and tick its **verified** flag, or change the value to
one you can stand behind.

The other two figures (5 services, 24/7) are structural facts about the offer,
not metrics, so they carry no flag.

> If 120 is not accurate, say so. A smaller true number outperforms a larger
> unprovable one the moment a prospect asks about it.

---

## 4. A recommendation — pricing

Every tier says **"Chat for Pricing."** That forces a WhatsApp conversation
before a prospect can tell whether you are in their budget, and it is one of the
most common reasons a good-looking agency site converts poorly. People who
cannot self-qualify usually leave rather than ask.

Even "Starter from ₹X" would help. Entirely your call — the structure supports
either. Edit at `/admin/bundles.php`.

---

## Done — no action needed

Recorded so nobody re-does them:

- **Configuration** — `SITE_DOMAIN` is `rafly.in`; the two conflicting phone
  numbers were consolidated into one `RAW_PHONE`; `robots.txt` carries an
  absolute sitemap URL.
- **Brand assets** — `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`,
  `og-cover.png`, `site.webmanifest` and a reversed logo all exist and are wired
  into `partials/head.php`.
- **Page images** — the four grey placeholder boxes on `about.php` and
  `insights.php` were replaced with the hand-drawn SVG scenes in
  `partials/illustrations.php`. These are on-brand, weigh almost nothing, and
  carry no licensing risk. Swap in photography later if you prefer; the markup
  does not change.
- **Blog posts** — all four articles are written, published, and now reachable.
  `insight.php` renders them; Insights lists them from the database; the sitemap
  includes them. Write more at `/admin/posts.php`.

---

## How content reaches the site

Worth knowing, because it is not obvious from the file tree:

The public pages read from PostgreSQL. Case studies, testimonials, trust
figures, bundles and articles are all edited in `/admin` and appear on the site
immediately — no deploy.

If the database is unreachable, every public page still returns 200. The
database-backed sections render empty and everything else is unaffected. Only
`insight.php` 404s, because an article with no body is not a page.
