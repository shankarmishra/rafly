<?php
/**
 * Core team.
 *
 * Each member is a native <details> card: collapsed it shows the photo, name,
 * role and brief line; the arrow opens it onto the full detail and the profile
 * links.
 */

require __DIR__ . '/inc/bootstrap.php';

$page = [
    'id'        => 'team',
    'title'     => 'Our Team | Rafly Digital Growth',
    'desc'      => 'The people behind Rafly — the developers, marketers and strategists who run every bundled package.',
    'bodyClass' => 'page-team',
    'styles'    => ['team'],
    'schema'    => [
        [
            '@type'       => 'AboutPage',
            '@id'         => schema_id('team'),
            'url'         => SITE_ORIGIN . '/team',
            'name'        => 'Our Team | Rafly Digital Growth',
            'description' => 'The people behind Rafly — the developers, marketers and strategists who run every bundled package.',
            'isPartOf'    => ['@id' => schema_id('website')],
            'about'       => ['@id' => schema_id('organization')],
        ],
        schema_breadcrumbs($crumbs = [
            ['name' => 'Home', 'url' => '/'],
            ['name' => 'Team', 'url' => '/team'],
        ]),
    ],
];

$team = db_available()
    ? all('
        SELECT t.name, t.role, t.brief, t.bio, t.github_url, t.linkedin_url,
               t.is_placeholder,
               m.filename AS photo, m.alt AS photo_alt
          FROM team_members t
          LEFT JOIN media m ON m.id = t.photo_media_id
         WHERE t.is_published
      ORDER BY t.sort_order ASC, t.id ASC
      ')
    : [];

foreach ($team as $p) {
    if (empty($p['is_placeholder'])) {
        $page['schema'][] = schema_person($p);
    }
}

require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/header.php';
?>
<main id="main">
    <section class="hero tex-grain">
        <div class="hero-container is-single">
            <?= breadcrumbs($crumbs) ?>
            <div class="hero-copy">
                <div class="badge-wrapper"><span class="section-badge">Core Team</span></div>
                <h1>The people behind every package.</h1>
                <p>One coordinated team rather than five separate vendors — these are the people who actually do the work.</p>
            </div>
        </div>
    </section>

    <section class="section-container" id="team">
<?php if (!$team): ?>
        <p class="section-subtitle">Team profiles are on their way — <a href="<?= e(whatsapp_link('Hi Rafly team, I would like to know who I would be working with.')) ?>" target="_blank" rel="noopener">message us</a> in the meantime and we'll introduce you directly.</p>
<?php else: ?>
        <h2 class="section-title">Meet the team</h2>
        <p class="section-subtitle">The strip loops on its own. Hover it, or tap a card, to stop it and read more.</p>

        <div class="team-strip" data-animate="fade-in">
        <div class="team-track grid-3 team-grid">
<?php foreach ($team as $i => $p):
            $hasLinks = $p['github_url'] !== '' || $p['linkedin_url'] !== ''; ?>
            <div class="team-slide" style="--i:<?= (int)$i ?>">
            <details class="team-card<?= !empty($p['is_placeholder']) ? ' is-placeholder' : '' ?>">
                
                <summary class="team-card-head">
                    <span class="team-avatar-wrapper">
                        <span class="team-avatar">
<?php if ($p['photo'] !== null): ?>
                            <img src="<?= e(site_path('/uploads/' . rawurlencode((string)$p['photo']))) ?>"
                                 alt="<?= e((string)($p['photo_alt'] !== '' ? $p['photo_alt'] : $p['name'])) ?>"
                                 width="128" height="128" loading="lazy" decoding="async">
<?php else: ?>
                            <?= icon('user') ?>
<?php endif; ?>
                        </span>
                    </span>

                    <span class="team-card-id">
                        <strong><?= e((string)$p['name']) ?></strong>
                        <span class="team-role"><?= e((string)$p['role']) ?></span>
                        <span class="team-brief"><?= e((string)$p['brief']) ?></span>
                    </span>

                    <?= icon('chevron-down', 'team-arrow') ?>
                </summary>

                <div class="team-card-body">
                    <div class="team-card-scroll-area">
<?php if ($p['bio'] !== ''): ?>
                        <p><?= e((string)$p['bio']) ?></p>
<?php endif; ?>
<?php if ($hasLinks): ?>
                        <div class="team-links">
<?php if ($p['github_url'] !== ''): ?>
                            <a href="<?= e((string)$p['github_url']) ?>" target="_blank" rel="noopener noreferrer"
                               aria-label="<?= e($p['name'] . ' on GitHub') ?>">
                                <?= icon('github', 'icon-fill') ?><span>GitHub</span>
                            </a>
<?php endif; ?>
<?php if ($p['linkedin_url'] !== ''): ?>
                            <a href="<?= e((string)$p['linkedin_url']) ?>" target="_blank" rel="noopener noreferrer"
                               aria-label="<?= e($p['name'] . ' on LinkedIn') ?>">
                                <?= icon('linkedin', 'icon-fill') ?><span>LinkedIn</span>
                            </a>
<?php endif; ?>
                        </div>
<?php endif; ?>
                    </div>
                    
                    <div class="team-nav-controls">
                        <button type="button" class="team-btn-prev">&larr; Prev</button>
                        <button type="button" class="team-btn-next">Next &rarr;</button>
                    </div>
                </div>
            </details>
            </div>
<?php endforeach; ?>
        </div>
        </div>
<?php endif; ?>
    </section>
</main>

<!-- Lightweight Vanilla JS for Sequence Navigation and Single-Open Logic -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const teamCards = document.querySelectorAll('.team-card');
    if (!teamCards.length) return;

    teamCards.forEach((card, index) => {
        card.addEventListener('toggle', () => {
            if (card.open) {
                teamCards.forEach((otherCard) => {
                    if (otherCard !== card && otherCard.open) {
                        otherCard.removeAttribute('open');
                    }
                });
            }
        });

        const nextBtn = card.querySelector('.team-btn-next');
        const prevBtn = card.querySelector('.team-btn-prev');

        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                card.removeAttribute('open');
                const nextIndex = (index + 1) % teamCards.length;
                teamCards[nextIndex].setAttribute('open', '');
                teamCards[nextIndex].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                card.removeAttribute('open');
                const prevIndex = (index - 1 + teamCards.length) % teamCards.length;
                teamCards[prevIndex].setAttribute('open', '');
                teamCards[prevIndex].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            });
        }
    });
});
</script>

<?php require __DIR__ . '/partials/tail.php'; ?>