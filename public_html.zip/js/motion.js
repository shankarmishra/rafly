/* ==========================================================================
   motion.js — the site's animation engine. No dependencies.

   Replaces the IntersectionObserver blocks that were duplicated across five
   pages. One shared observer and one shared scroll loop drive everything;
   CSS does the actual animating.

   Usage:
     <div data-animate="fade-up" data-delay="200">
     <div data-animate="stagger" data-stagger="80">
     <h2  data-animate="split-text">
     <span data-animate="counter" data-count="120" data-suffix="+">
     <div data-animate="parallax" data-speed="0.15">
     <a   data-animate="magnetic" data-strength="0.3">
     <div data-animate="tilt" data-max="8">
     <svg data-animate="draw">
   ========================================================================== */

(function () {
    'use strict';

    /**
     * Tell CSS that the reveal system is alive.
     *
     * Every reveal primitive works by hiding an element (opacity 0, or a
     * clip-path that crops it to nothing) and waiting for JS to add .is-in.
     * That is fine right up until JS does not run — a parse error, a blocked
     * file, an over-eager extension — and then the content is not merely
     * un-animated, it is permanently invisible, with the page still laying out
     * space for it. A photograph that never appears and a blank column where it
     * should be is exactly that failure.
     *
     * Scoping every hidden state to .js-motion inverts the risk: no JS means no
     * hiding, and the page renders plainly instead of half-empty. This runs
     * before the observer is even constructed, so there is no window in which
     * the class is missing while the rest of this file is working.
     */
    document.documentElement.classList.add('js-motion');

    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var finePointer = window.matchMedia('(pointer: fine)').matches;

    /* ---------------------------------------------------------------------
       Reveal observer — one instance for every reveal-type animation.
       --------------------------------------------------------------------- */

    var revealTargets = '[data-animate], .reveal';

    var observer = 'IntersectionObserver' in window
        ? new IntersectionObserver(onIntersect, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' })
        : null;

    function onIntersect(entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            activate(entry.target);
            observer.unobserve(entry.target);
        });
    }

    function activate(el) {
        var type = el.dataset.animate;

        if (type === 'counter') {
            runCounter(el);
        }

        // .reveal is the legacy class from the original site; keep it working.
        el.classList.add('is-in');
        if (el.classList.contains('reveal')) el.classList.add('in-view');
    }

    /* ---------------------------------------------------------------------
       Setup per animation type
       --------------------------------------------------------------------- */

    /* Selectors that get a reveal automatically, so existing markup animates
       without every element needing a data-attribute. The original site did
       this inline on each page; it lives here now. */
    /* Deliberately short. Blanketing every card with the same fade-up is why
       everything used to enter identically — motion should mark groups, not
       individual elements. Grids opt in explicitly with data-animate="stagger". */
    var AUTO_REVEAL = [
        '.section-container', '.card-display', '.blog-card',
        '.panel', '.hero-card', '.policy-section', '.policy-toc'
    ].join(',');

    function autoTag(root) {
        // Counters: any [data-count] not already wired.
        root.querySelectorAll('[data-count]').forEach(function (el) {
            if (!el.dataset.animate) el.dataset.animate = 'counter';
        });

        root.querySelectorAll(AUTO_REVEAL).forEach(function (el) {
            if (!el.dataset.animate && !el.classList.contains('reveal')) {
                el.dataset.animate = 'fade-up';
            }
        });
    }

    function init(root) {
        root = root || document;

        autoTag(root);

        var els = root.querySelectorAll(revealTargets);

        els.forEach(function (el) {
            var type = el.dataset.animate;

            if (el.dataset.delay) {
                el.style.setProperty('--_delay', el.dataset.delay + 'ms');
            }

            if (type === 'stagger') setupStagger(el);
            if (type === 'split-text') setupSplitText(el);
            if (type === 'draw') setupDraw(el);
            if (type === 'tilt' && finePointer && !reduceMotion) setupTilt(el);
            if (type === 'magnetic' && finePointer && !reduceMotion) setupMagnetic(el);
            if (type === 'parallax' && !reduceMotion) parallaxEls.push(el);
            if (type === 'progress-line') {
                if (reduceMotion) el.style.setProperty('--p', 1);
                else progressEls.push(el);
            }

            // With reduced motion we skip observation entirely: elements keep
            // their natural, fully-visible state rather than animating faster.
            if (reduceMotion) {
                if (type === 'counter') runCounter(el, true);
                el.classList.add('is-in');
                if (el.classList.contains('reveal')) el.classList.add('in-view');
                return;
            }

            if (observer) {
                observer.observe(el);
            } else {
                activate(el); // No IO support: show everything immediately.
            }
        });

        // .team-strip BEFORE .marquee: setupTeamStrip adds the marquee class and
        // sets track.dataset.cloned, which is the handshake that makes
        // setupMarquee skip the strip. Reversed, the strip would be missed on
        // the first pass and innerHTML-cloned on any re-entry.
        root.querySelectorAll('.team-strip').forEach(setupTeamStrip);
        root.querySelectorAll('.marquee').forEach(setupMarquee);
        root.querySelectorAll('[data-pointer-scene]').forEach(setupPointerScene);
    }

    /* --- Pointer-driven scene -------------------------------------------
       Writes normalised -1..1 pointer position; CSS consumes it at different
       multipliers per depth plane. Damping comes from the CSS transition
       rather than a lerp loop, so there is no extra rAF work.
       --------------------------------------------------------------------- */

    function setupPointerScene(el) {
        // The load-in only plays when JS is present; the composed state is the
        // CSS base state, so no-JS still renders a finished scene.
        requestAnimationFrame(function () { el.classList.add('is-ready'); });

        setupDraw(el);

        // Ring dash lengths, so the draw-in starts from a correct offset.
        el.querySelectorAll('.ring').forEach(function (r) {
            if (typeof r.getTotalLength === 'function') {
                r.style.setProperty('--len', Math.ceil(r.getTotalLength()));
                r.style.strokeDasharray = Math.ceil(r.getTotalLength());
            }
        });

        if (!finePointer || reduceMotion) return;

        el.addEventListener('pointermove', function (e) {
            var r = el.getBoundingClientRect();
            el.style.setProperty('--mx', (((e.clientX - r.left) / r.width) * 2 - 1).toFixed(3));
            el.style.setProperty('--my', (((e.clientY - r.top) / r.height) * 2 - 1).toFixed(3));
        }, { passive: true });

        el.addEventListener('pointerleave', function () {
            el.style.setProperty('--mx', 0);
            el.style.setProperty('--my', 0);
        });
    }

    /* --- Stagger: set --i on children, CSS computes the delay ------------- */

    function setupStagger(el) {
        if (el.dataset.stagger) {
            el.style.setProperty('--_stagger', el.dataset.stagger + 'ms');
        }
        Array.prototype.forEach.call(el.children, function (child, i) {
            child.style.setProperty('--i', i);
        });
    }

    /* --- Split text -------------------------------------------------------
       Word level, not character level: splitting into characters destroys
       screen-reader pronunciation and breaks hyphenation for little gain.
       The original string is preserved in aria-label.
       --------------------------------------------------------------------- */

    function setupSplitText(el) {
        if (el.dataset.splitDone) return;

        var text = el.textContent.trim();
        if (!text) return;

        el.setAttribute('aria-label', text);

        var frag = document.createDocumentFragment();
        text.split(/\s+/).forEach(function (word, i) {
            var span = document.createElement('span');
            span.className = 'split-word';
            span.style.setProperty('--i', i);
            span.setAttribute('aria-hidden', 'true');
            span.textContent = word;
            frag.appendChild(span);
            frag.appendChild(document.createTextNode(' '));
        });

        el.textContent = '';
        el.appendChild(frag);
        el.dataset.splitDone = '1';
    }

    /* --- Counter ---------------------------------------------------------- */

    function runCounter(el, instant) {
        if (el.dataset.counted) return;
        el.dataset.counted = '1';

        var target = parseFloat(el.dataset.count || el.textContent) || 0;
        var suffix = el.dataset.suffix || '';
        var duration = parseInt(el.dataset.duration || '1400', 10);

        if (instant) {
            el.textContent = target + suffix;
            return;
        }

        var start = null;

        function step(now) {
            if (start === null) start = now;
            var progress = Math.min((now - start) / duration, 1);
            // easeOutExpo, so the count decelerates like every other transition
            var eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
            el.textContent = Math.round(target * eased) + suffix;
            if (progress < 1) requestAnimationFrame(step);
        }

        requestAnimationFrame(step);
    }

    /* --- SVG line drawing -------------------------------------------------
       Measures the real path length instead of assuming the hard-coded
       stroke-dasharray:320 the original CSS used, which was correct for
       exactly one polyline.
       --------------------------------------------------------------------- */

    function setupDraw(el) {
        var paths = el.matches('.draw-path') ? [el] : el.querySelectorAll('.draw-path');
        Array.prototype.forEach.call(paths, function (p) {
            if (typeof p.getTotalLength !== 'function') return;
            var len = Math.ceil(p.getTotalLength());
            if (len > 0) p.style.setProperty('--len', len);
        });
    }

    /* --- Tilt -------------------------------------------------------------- */

    function setupTilt(el) {
        var max = parseFloat(el.dataset.max || '8');

        el.addEventListener('pointermove', function (e) {
            var r = el.getBoundingClientRect();
            var px = (e.clientX - r.left) / r.width;
            var py = (e.clientY - r.top) / r.height;

            el.style.setProperty('--ry', ((px - 0.5) * 2 * max).toFixed(2) + 'deg');
            el.style.setProperty('--rx', ((0.5 - py) * 2 * max).toFixed(2) + 'deg');
            el.style.setProperty('--mx', (px * 100).toFixed(1) + '%');
            el.style.setProperty('--my', (py * 100).toFixed(1) + '%');
        });

        el.addEventListener('pointerleave', function () {
            el.style.setProperty('--rx', '0deg');
            el.style.setProperty('--ry', '0deg');
        });
    }

    /* --- Magnetic ---------------------------------------------------------- */

    function setupMagnetic(el) {
        var strength = parseFloat(el.dataset.strength || '0.3');
        var pad = 40;

        function onMove(e) {
            var r = el.getBoundingClientRect();
            var cx = r.left + r.width / 2;
            var cy = r.top + r.height / 2;
            var dx = e.clientX - cx;
            var dy = e.clientY - cy;

            var inRange = Math.abs(dx) < r.width / 2 + pad && Math.abs(dy) < r.height / 2 + pad;

            if (inRange) {
                el.style.setProperty('--tx', (dx * strength).toFixed(1) + 'px');
                el.style.setProperty('--ty', (dy * strength).toFixed(1) + 'px');
            } else {
                reset();
            }
        }

        function reset() {
            el.style.setProperty('--tx', '0px');
            el.style.setProperty('--ty', '0px');
        }

        window.addEventListener('pointermove', onMove, { passive: true });
        el.addEventListener('pointerleave', reset);
    }

    /* --- Parallax + scroll loop -------------------------------------------
       One rAF-throttled listener updates every parallax element and the
       scroll-progress bar. Elements outside the viewport are skipped.
       --------------------------------------------------------------------- */

    var parallaxEls = [];
    var progressEls = [];
    var ticking = false;

    function onScroll() {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(updateScroll);
    }

    function updateScroll() {
        ticking = false;

        var vh = window.innerHeight;

        parallaxEls.forEach(function (el) {
            var r = el.getBoundingClientRect();
            if (r.bottom < -200 || r.top > vh + 200) return;

            var speed = parseFloat(el.dataset.speed || '0.15');
            var offset = (r.top + r.height / 2 - vh / 2) * -speed;
            el.style.setProperty('--py', offset.toFixed(1) + 'px');
        });

        var bar = document.getElementById('scrollProgress');
        if (bar) {
            var max = document.documentElement.scrollHeight - vh;
            var pct = max > 0 ? window.scrollY / max : 0;
            bar.style.transform = 'scaleX(' + Math.min(pct, 1).toFixed(4) + ')';
        }

        // Scroll-linked timeline fill: the connecting line grows as the track
        // travels through the viewport.
        progressEls.forEach(function (el) {
            var r = el.getBoundingClientRect();
            var span = r.height + vh * 0.6;
            var travelled = vh * 0.8 - r.top;
            var p = Math.max(0, Math.min(travelled / span, 1));
            el.style.setProperty('--p', p.toFixed(4));
        });
    }

    /* --- Marquee ----------------------------------------------------------- */

    function setupMarquee(el) {
        var track = el.querySelector('.marquee-track');
        if (!track || track.dataset.cloned) return;

        // Duplicate the content once so the -50% translate loops seamlessly.
        track.innerHTML += track.innerHTML;
        track.dataset.cloned = '1';
    }

    /* --- Team strip --------------------------------------------------------
       A marquee whose items are interactive, which rules out setupMarquee:
       innerHTML += innerHTML re-parses the DOM (dropping listeners), duplicates
       every id, and leaves the copies in the tab order and the accessibility
       tree, so a screen reader would meet each person twice.

       It is also a progressive enhancement. The markup ships as the ordinary
       .team-grid and only this function promotes it, so no-JS and reduced
       motion both keep the plain grid — a width:max-content row inside
       overflow:hidden with its animation killed would strand most of the team.
       ---------------------------------------------------------------------- */

    var STRIP_SPEED = 60;   // px/s — slow enough to read a name in passing

    function setupTeamStrip(el) {
        if (reduceMotion) return;

        var track = el.querySelector('.team-track');
        if (!track || track.dataset.cloned) return;

        var originals = Array.prototype.slice.call(track.children);
        // One card looping past itself looks silly; a single centred card in
        // the grid is the honest presentation.
        if (originals.length < 2) return;

        // Promote first: the width below has to be measured on the flex row
        // that will actually scroll, not on the grid it currently is.
        el.classList.add('marquee');
        track.classList.add('marquee-track');

        var setWidth = track.scrollWidth;
        if (!setWidth) return;

        // Two or three members make one set narrower than the strip, which
        // sends a visible hole travelling across it. Repeat until one half
        // covers the strip, then mirror that half — the -50% keyframe only
        // loops seamlessly if the halves are identical, so the total number of
        // copies must stay even. screen.width is folded in so rotating a phone
        // to landscape does not reopen that hole.
        var fill = Math.max(el.clientWidth, window.screen ? window.screen.width : 0);
        var perHalf = Math.max(1, Math.ceil(fill / setWidth));

        var frag = document.createDocumentFragment();
        for (var copy = 1; copy < perHalf * 2; copy++) {
            originals.forEach(function (node) { frag.appendChild(cloneInert(node)); });
        }
        track.appendChild(frag);
        track.dataset.cloned = '1';

        // Distance per cycle is one half of the track. A fixed duration would
        // make three cards crawl and eight blur past.
        el.style.setProperty('--marquee-dur',
            Math.round((setWidth * perHalf) / STRIP_SPEED) + 's');
    }

    /* A copy that exists for the pointer and not for assistive technology.
       <summary> and <a> are both focusable without a tabindex, so the attribute
       has to be written onto every one. Suppressing focus on mousedown closes
       the last gap: a click would otherwise move focus into an aria-hidden
       subtree, which is exactly what that attribute forbids. Both the details
       toggle and the link fire on click, so neither is affected. */
    function cloneInert(node) {
        var copy = node.cloneNode(true);
        copy.setAttribute('aria-hidden', 'true');
        copy.querySelectorAll('a, summary, button, input, select, textarea, [tabindex]')
            .forEach(function (f) { f.setAttribute('tabindex', '-1'); });
        copy.addEventListener('mousedown', function (e) { e.preventDefault(); });
        return copy;
    }

    /* --------------------------------------------------------------------- */

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { init(); updateScroll(); });
    } else {
        init();
        updateScroll();
    }

    // Exposed so dynamically inserted content can be wired up.
    window.RaflyMotion = { init: init, splitText: setupSplitText };
})();
