/* ==========================================================================
   app.js — site behaviour. No dependencies.
   Consolidates the inline <script> blocks that were duplicated per page.
   ========================================================================== */

(function () {
    'use strict';

    var doc = document;

    // Shared with motion.js's own check — kept local here so app.js has no
    // load-order dependency on it.
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* =====================================================================
       Toasts — replacing alert(), which blocks the main thread.
       ===================================================================== */

    function toast(message, type) {
        var stack = doc.getElementById('toastStack');
        if (!stack) { return; }

        var el = doc.createElement('div');
        el.className = 'toast' + (type ? ' is-' + type : '');
        el.textContent = message;
        stack.appendChild(el);

        setTimeout(function () {
            el.classList.add('is-leaving');
            el.addEventListener('animationend', function () { el.remove(); }, { once: true });
        }, 4500);
    }

    window.raflyToast = toast;

    /* =====================================================================
       Header: shadow, hide-on-scroll-down
       ===================================================================== */

    var header = doc.getElementById('mainHeader');
    var lastY = window.scrollY;
    var DEAD_ZONE = 10;

    function onHeaderScroll() {
        if (!header) return;
        var y = window.scrollY;

        header.classList.toggle('scrolled', y > 20);

        // Never hide the header while a menu or modal is open.
        if (doc.body.classList.contains('nav-open') || doc.body.classList.contains('modal-open')) {
            header.classList.remove('is-hidden');
            lastY = y;
            return;
        }

        if (Math.abs(y - lastY) > DEAD_ZONE) {
            header.classList.toggle('is-hidden', y > lastY && y > 200);
            lastY = y;
        }
    }

    window.addEventListener('scroll', onHeaderScroll, { passive: true });
    onHeaderScroll();

    /* =====================================================================
       Scroll-spy — highlights the matching nav link as homepage one-pager
       sections (#services/#pricing/#contact) cross the viewport. The server
       already renders .is-active for a page-level match (nav_active()); this
       reuses the same class so both mechanisms produce identical styling and
       never fight each other — the homepage's own nav items never carry a
       server-rendered .is-active, so there is nothing to conflict with.
       ===================================================================== */

    (function scrollSpy() {
        if (!('IntersectionObserver' in window)) return;

        var linkMap = {};
        Array.prototype.forEach.call(doc.querySelectorAll('.nav-links > .nav-item > a[href^="index.php#"]'), function (a) {
            var hash = a.getAttribute('href').split('#')[1];
            if (hash) linkMap[hash] = a;
        });

        var sections = Object.keys(linkMap)
            .map(function (id) { return doc.getElementById(id); })
            .filter(Boolean);
        if (!sections.length) return;

        var spy = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                var link = linkMap[entry.target.id];
                var item = link && link.closest('.nav-item');
                if (item) item.classList.toggle('is-active', entry.isIntersecting);
            });
        }, { rootMargin: '-45% 0px -45% 0px' }); // active band = the viewport's vertical center

        sections.forEach(function (s) { spy.observe(s); });
    })();

    /* =====================================================================
       Desktop dropdowns (Services / Pricing) — a11y + hover-intent
       The dropdowns already open on CSS :hover/:focus-within with no JS at
       all, so this only adds what CSS can't: a synced aria-expanded for
       screen readers, a short close-delay so diagonal mouse travel from the
       nav link down into the panel doesn't dismiss it, and Escape-to-close.
       ===================================================================== */

    Array.prototype.forEach.call(doc.querySelectorAll('.nav-item'), function (item) {
        var trigger = item.querySelector(':scope > a[aria-haspopup="true"]');
        var panel = item.querySelector('.dropdown, .mega-dropdown');
        if (!trigger || !panel) return;

        var closeTimer = null;

        function open() {
            clearTimeout(closeTimer);
            item.classList.add('is-open');
            trigger.setAttribute('aria-expanded', 'true');
        }

        function close() {
            item.classList.remove('is-open');
            trigger.setAttribute('aria-expanded', 'false');
        }

        function scheduleClose() {
            clearTimeout(closeTimer);
            // Bridges the gap between the nav link and a panel sitting below
            // it (the mega-dropdown in particular) so leaving the trigger on
            // a diagonal path toward the panel doesn't slam it shut.
            closeTimer = setTimeout(close, 250);
        }

        item.addEventListener('mouseenter', open);
        item.addEventListener('mouseleave', scheduleClose);
        item.addEventListener('focusin', open);
        item.addEventListener('focusout', function (e) {
            if (!item.contains(e.relatedTarget)) close();
        });

        item.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && item.classList.contains('is-open')) {
                close();
                trigger.focus();
            }
        });
    });

    /* =====================================================================
       Focus trap — shared by the modal and the mobile drawer
       ===================================================================== */

    var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

    function trapFocus(container, e) {
        var items = Array.prototype.filter.call(
            container.querySelectorAll(FOCUSABLE),
            function (el) { return el.offsetParent !== null; }
        );
        if (!items.length) return;

        var first = items[0];
        var last = items[items.length - 1];

        if (e.shiftKey && doc.activeElement === first) {
            e.preventDefault();
            last.focus();
        } else if (!e.shiftKey && doc.activeElement === last) {
            e.preventDefault();
            first.focus();
        }
    }

    /* =====================================================================
       Mobile drawer
       Before this existed the nav was display:none under 900px with no
       replacement, so phones had no way to navigate the site.
       ===================================================================== */

    var navToggle = doc.getElementById('navToggle');
    var drawer = doc.getElementById('mobileDrawer');
    var drawerReturnFocus = null;

    function setDrawer(open) {
        if (!drawer || !navToggle) return;

        navToggle.setAttribute('aria-expanded', String(open));
        navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        doc.body.classList.toggle('nav-open', open);

        if (open) {
            drawerReturnFocus = doc.activeElement;
            drawer.hidden = false;
            // Next frame, so the transition runs from the hidden state.
            // The focus call MUST be inside this callback too: until .is-open
            // lands the drawer is still visibility:hidden, and focusing a
            // visibility:hidden element is a silent no-op — so opening the menu
            // left focus stranded behind it.
            requestAnimationFrame(function () {
                drawer.classList.add('is-open');
                var firstLink = drawer.querySelector(FOCUSABLE);
                if (firstLink) firstLink.focus();
            });
        } else {
            drawer.classList.remove('is-open');
            drawer.addEventListener('transitionend', function handler() {
                if (!drawer.classList.contains('is-open')) drawer.hidden = true;
                drawer.removeEventListener('transitionend', handler);
            });
            if (drawerReturnFocus) drawerReturnFocus.focus();
        }
    }

    if (navToggle) {
        navToggle.addEventListener('click', function () {
            setDrawer(navToggle.getAttribute('aria-expanded') !== 'true');
        });
    }

    // Nested accordions inside the drawer (the hover mega-dropdown is
    // unusable on touch).
    doc.querySelectorAll('.mobile-acc-trigger').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var expanded = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', String(!expanded));
        });
    });

    // Close the drawer when navigating to an in-page anchor.
    if (drawer) {
        drawer.addEventListener('click', function (e) {
            var link = e.target.closest('a[href*="#"]');
            if (link) setDrawer(false);
        });
    }

    /* =====================================================================
       Modal
       ===================================================================== */

    var modalReturnFocus = null;

    function setModal(id, open) {
        var modal = doc.getElementById(id);
        if (!modal) return;

        doc.body.classList.toggle('modal-open', open);

        if (open) {
            modalReturnFocus = doc.activeElement;
            modal.hidden = false;

            // Same pattern as the drawer: un-hide, then add .active next frame
            // so the fade/lift has a state to transition from. Focus also waits,
            // because the panel is display:none until .active lands.
            requestAnimationFrame(function () {
                modal.classList.add('active');
                var first = modal.querySelector(FOCUSABLE);
                if (first) first.focus();
            });
        } else {
            modal.classList.remove('active');

            var done = function () {
                if (!modal.classList.contains('active')) modal.hidden = true;
                modal.removeEventListener('transitionend', done);
            };
            modal.addEventListener('transitionend', done);
            // transitionend never fires under prefers-reduced-motion.
            setTimeout(done, 400);

            if (modalReturnFocus) modalReturnFocus.focus();
        }
    }

    // data-* hooks replace the inline onclick="toggleModal(true)" attributes.
    doc.addEventListener('click', function (e) {
        var opener = e.target.closest('[data-modal-open]');
        if (opener) {
            e.preventDefault();
            setModal(opener.dataset.modalOpen, true);
            return;
        }

        var closer = e.target.closest('[data-modal-close]');
        if (closer) {
            e.preventDefault();
            var m = closer.closest('.modal');
            if (m) setModal(m.id, false);
            return;
        }

        // Backdrop click
        if (e.target.classList && e.target.classList.contains('modal')) {
            setModal(e.target.id, false);
        }
    });

    doc.addEventListener('keydown', function (e) {
        var openModal = doc.querySelector('.modal.active');

        if (e.key === 'Escape') {
            if (openModal) { setModal(openModal.id, false); return; }
            if (doc.body.classList.contains('nav-open')) { setDrawer(false); return; }
        }

        if (e.key === 'Tab') {
            if (openModal) { trapFocus(openModal, e); }
            else if (doc.body.classList.contains('nav-open') && drawer) { trapFocus(drawer, e); }
        }
    });

    // Legacy global, kept so any leftover inline handler keeps working.
    window.toggleModal = function (show) { setModal('consultationModal', !!show); };

    /* =====================================================================
       Consultation prompt

       Was: a blind 15-25s timer that opened the modal up to SIX times and
       re-armed itself every time you closed it. On a phone the modal is
       effectively full screen and sets body{overflow:hidden}, so the page got
       hijacked six times a visit.

       Now: at most ONE prompt per browser session, and only once the visitor
       has actually engaged — a third of the page scrolled, or 45s spent on it.

       Suppressed outright below 900px and on touch, where .mobile-sticky-cta
       already offers the same action permanently and without blocking
       anything. A full-screen interstitial duplicating a button that is
       already on screen is strictly worse than the button.
       ===================================================================== */

    var PROMPT_KEY = 'raflyConsultPrompt';
    var contactPromptTimer = null;
    var contactPromptDone = false;

    // Safari in private mode throws on sessionStorage, so every touch of it is
    // guarded. Failing open (prompt allowed) is the safe direction.
    function promptSuppressed() {
        try { return sessionStorage.getItem(PROMPT_KEY) === '1'; } catch (e) { return false; }
    }

    function suppressPrompt() {
        contactPromptDone = true;
        clearTimeout(contactPromptTimer);
        window.removeEventListener('scroll', onPromptScroll);
        try { sessionStorage.setItem(PROMPT_KEY, '1'); } catch (e) {}
    }

    function shouldOpenContactPrompt() {
        if (contactPromptDone || promptSuppressed()) return false;
        if (doc.body.classList.contains('modal-open')) return false;
        if (doc.body.classList.contains('nav-open')) return false;
        if (botWindow && !botWindow.hidden) return false;
        if (!doc.getElementById('consultationModal')) return false;
        return true;
    }

    function firePrompt() {
        if (!shouldOpenContactPrompt()) return;
        suppressPrompt();               // burn the flag BEFORE opening
        setModal('consultationModal', true);
    }

    function onPromptScroll() {
        var max = doc.documentElement.scrollHeight - window.innerHeight;
        if (max > 0 && window.scrollY / max >= 0.35) firePrompt();
    }

    function initContactPrompt() {
        if (window.matchMedia('(max-width: 900px), (pointer: coarse)').matches || promptSuppressed()) {
            contactPromptDone = true;
            return;
        }
        window.addEventListener('scroll', onPromptScroll, { passive: true });
        contactPromptTimer = setTimeout(firePrompt, 45000);
    }

    // Opening it deliberately means we never need to ask.
    doc.addEventListener('click', function (e) {
        if (e.target.closest('[data-modal-open="consultationModal"]')) suppressPrompt();
    });

    // One delegated listener covers every wa.me link on the site (header
    // dropdown, mobile drawer, sticky bar, pricing cards, footer, social
    // rail, thank-you, 404, the failed-submit fallback) with no per-template
    // click handler to keep in sync. No-ops if the Pixel isn't loaded
    // (blocked, or analytics.meta_pixel_id left blank) — never breaks the
    // link itself.
    doc.addEventListener('click', function (e) {
        if (typeof fbq === 'function' && e.target.closest('a[href^="https://wa.me/"]')) {
            fbq('trackCustom', 'WhatsAppClick');
        }
    });

    /* =====================================================================
       FAQ accordion
       ===================================================================== */

    doc.querySelectorAll('.faq-node-header').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var node = btn.closest('.faq-node');
            if (!node) return;

            var isOpen = node.classList.contains('active');

            node.parentElement.querySelectorAll('.faq-node.active').forEach(function (n) {
                n.classList.remove('active');
                var h = n.querySelector('.faq-node-header');
                if (h) h.setAttribute('aria-expanded', 'false');
            });

            if (!isOpen) {
                node.classList.add('active');
                btn.setAttribute('aria-expanded', 'true');
            }
        });
    });

    // Legacy global for markup still using onclick="toggleFaqAccordion(this)".
    window.toggleFaqAccordion = function (el) {
        var header = el.classList && el.classList.contains('faq-node-header')
            ? el
            : el.querySelector('.faq-node-header');
        if (header) header.click();
    };

    /* =====================================================================
       Scroll to top
       ===================================================================== */

    var toTop = doc.getElementById('toTop');
    if (toTop) {
        window.addEventListener('scroll', function () {
            var show = window.scrollY > 600;
            // .is-visible drives both opacity and visibility; visibility:hidden
            // is what actually keeps it out of the tab order.
            toTop.classList.toggle('is-visible', show);
        }, { passive: true });

        toTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
        });
    }

    /* =====================================================================
       Forms — AJAX submit with inline validation
       ===================================================================== */

    doc.querySelectorAll('form[data-ajax-form="true"]').forEach(function (form) {

        // Validate on blur rather than on every keystroke, which is hostile
        // while someone is still typing.
        form.querySelectorAll('.form-control').forEach(function (field) {
            field.addEventListener('blur', function () { validateField(field); });
            field.addEventListener('input', function () {
                if (field.getAttribute('aria-invalid') === 'true') validateField(field);
            });
        });

        // Consent checkbox gets the same inline-error treatment as the text
        // fields, so the eye never has to travel down to a toast to find out
        // which control needs attention.
        var consentInput = form.querySelector('input[name="consent"]');
        if (consentInput) {
            consentInput.addEventListener('change', function () { validateConsent(consentInput); });
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            var valid = true;
            form.querySelectorAll('.form-control').forEach(function (field) {
                if (!validateField(field)) valid = false;
            });

            if (consentInput && !validateConsent(consentInput)) valid = false;

            if (!valid) {
                form.classList.add('is-shaking');
                setTimeout(function () { form.classList.remove('is-shaking'); }, 500);
                return;
            }

            var btn = form.querySelector('.btn-submit, [type="submit"]');
            var original = btn ? btn.textContent : '';

            if (btn) {
                btn.disabled = true;
                btn.classList.add('is-loading');
                btn.textContent = 'Sending…';
            }

            fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(function (res) { return res.json().catch(function () { return { success: false }; }); })
                .then(function (data) {
                    // The server rotates the CSRF token on every successful
                    // submit, so push the new one into every form on the page.
                    // Without this the second form to be used would fail with an
                    // expired-session error.
                    if (data && data.csrf_token) {
                        document.querySelectorAll('input[name="csrf_token"]').forEach(function (input) {
                            input.value = data.csrf_token;
                        });
                    }

                    if (data && data.success) {
                        // csrf_token is only present on a genuine submit — the
                        // server's honeypot path (submit.php) also answers
                        // { success: true } to convince a bot it worked, but
                        // deliberately omits csrf_token there. Gating on it
                        // keeps bot hits out of the Lead conversion count.
                        if (typeof fbq === 'function' && data.csrf_token) {
                            fbq('track', 'Lead');
                        }
                        suppressPrompt();   // they got in touch; stop asking
                        if (btn) {
                            btn.classList.remove('is-loading');
                            btn.textContent = 'Submitted successfully';
                            btn.classList.add('success');
                        }
                        toast('Thanks — we\'ll be in touch within one business day.', 'success');
                        form.reset();

                        // form.reset() only clears values — it doesn't fire blur/change,
                        // so a field's validation state (success tick, aria-invalid,
                        // inline error) would otherwise survive on now-empty inputs.
                        form.querySelectorAll('.form-control[aria-invalid]').forEach(function (field) {
                            field.removeAttribute('aria-invalid');
                            field.removeAttribute('aria-describedby');
                        });
                        form.querySelectorAll('.field-error').forEach(function (el) { el.remove(); });

                        var modal = form.closest('.modal');
                        if (modal) setTimeout(function () { setModal(modal.id, false); }, 1200);

                        setTimeout(function () {
                            if (btn) {
                                btn.textContent = original;
                                btn.classList.remove('success');
                                btn.disabled = false;
                            }
                        }, 4000);
                    } else {
                        throw new Error((data && data.message) || 'Submission failed');
                    }
                })
                .catch(function (err) {
                    toast(err.message || 'Something went wrong. Please try again.', 'error');
                    if (btn) {
                        btn.classList.remove('is-loading');
                        btn.disabled = false;
                        btn.textContent = original;
                    }
                });
        });
    });

    function validateField(field) {
        var value = field.value.trim();
        var ok = true;
        var message = '';

        if (field.hasAttribute('required') && !value) {
            ok = false;
            message = 'This field is required.';
        } else if (field.type === 'tel' && value && !/^[0-9+()\-\s]{6,}$/.test(value)) {
            ok = false;
            message = 'Please enter a valid contact number.';
        }

        field.setAttribute('aria-invalid', String(!ok));

        var errorId = field.id + '-error';
        var errorEl = doc.getElementById(errorId);

        if (!ok) {
            if (!errorEl) {
                errorEl = doc.createElement('span');
                errorEl.className = 'field-error';
                errorEl.id = errorId;
                // role="alert" makes an assistive-tech announcement fire the
                // moment this node is inserted — no wrapping live region needed.
                errorEl.setAttribute('role', 'alert');
                field.insertAdjacentElement('afterend', errorEl);
            }
            errorEl.textContent = message;
            field.setAttribute('aria-describedby', errorId);
        } else if (errorEl) {
            errorEl.remove();
            field.removeAttribute('aria-describedby');
        }

        return ok;
    }

    /* Consent checkbox — same inline-error pattern as validateField(), kept
       separate since a checkbox has no .form-control styling/blur semantics. */
    function validateConsent(consent) {
        var ok = consent.checked;
        var errorId = consent.id + '-error';
        var errorEl = doc.getElementById(errorId);
        var group = consent.closest('.consent-group') || consent.parentElement;

        if (!ok) {
            if (!errorEl) {
                errorEl = doc.createElement('span');
                errorEl.className = 'field-error';
                errorEl.id = errorId;
                errorEl.setAttribute('role', 'alert');
                group.appendChild(errorEl);
            }
            errorEl.textContent = 'Please accept the Privacy Policy to continue.';
            consent.setAttribute('aria-describedby', errorId);
        } else if (errorEl) {
            errorEl.remove();
            consent.removeAttribute('aria-describedby');
        }

        return ok;
    }

    /* =====================================================================
       Chatbot
       ===================================================================== */

    var qaData = [
        { q: 'What services do you offer?', a: 'We bundle web development, content creation, digital marketing, web security and e-commerce support — all under one partner.' },
        { q: 'How much does it cost?', a: 'Every package is tailored during a free consultation. Tell us your goals and we\'ll scope it with you.' },
        { q: 'How do I get started?', a: 'Request a free consultation from any page, or message us on WhatsApp and we\'ll reply the same day.' }
    ];

    var botWindow = doc.getElementById('botWindow');
    var botLogs = doc.querySelector('.bot-logs');
    var botOptions = doc.querySelector('.bot-options');

    var botTrigger = doc.querySelector('.bot-trigger');

    /**
     * The window carries the `hidden` attribute as well as the .active class.
     * Previously it was closed with opacity:0 + pointer-events:none only, which
     * hides it visually but leaves its buttons in the tab order and readable by
     * screen readers — so a keyboard user tabbed into an invisible chat widget.
     */
    function setBot(open) {
        if (!botWindow) return;

        if (botTrigger) {
            botTrigger.setAttribute('aria-expanded', open ? 'true' : 'false');
            botTrigger.setAttribute('aria-label', open ? 'Close the Rafly assistant' : 'Open the Rafly assistant');
        }

        if (open) {
            // Un-hide first, then add .active on the next frame. Adding both in
            // one tick means the element goes straight from display:none to its
            // final state and the opacity/transform transition never runs.
            botWindow.hidden = false;
            requestAnimationFrame(function () {
                botWindow.classList.add('active');
                var firstOption = botOptions && botOptions.querySelector('.opt-btn');
                if (firstOption) firstOption.focus();
            });
        } else {
            botWindow.classList.remove('active');

            // Re-hide only once the fade-out has finished, so it is not yanked
            // out of the layout mid-transition.
            var done = function () {
                botWindow.hidden = true;
                botWindow.removeEventListener('transitionend', done);
            };
            botWindow.addEventListener('transitionend', done);

            // Fallback for reduced-motion, where transitionend never fires.
            setTimeout(function () {
                if (!botWindow.classList.contains('active')) done();
            }, 400);

            if (botTrigger) botTrigger.focus();
        }
    }

    // Legacy global, kept for any markup still calling it inline.
    window.toggleBot = function () {
        setBot(botWindow ? botWindow.hidden : false);
    };

    doc.querySelectorAll('[data-bot-toggle]').forEach(function (btn) {
        btn.addEventListener('click', function () { window.toggleBot(); });
    });

    // Escape closes the assistant, matching the modal and drawer.
    doc.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && botWindow && !botWindow.hidden) {
            setBot(false);
        }
    });

    if (botOptions) {
        qaData.forEach(function (item) {
            var btn = doc.createElement('button');
            btn.type = 'button';
            btn.className = 'opt-btn';
            btn.textContent = item.q;
            btn.addEventListener('click', function () { botRespond(item); });
            botOptions.appendChild(btn);
        });
    }

    initContactPrompt();

    function botRespond(item) {
        if (!botLogs) return;

        var client = doc.createElement('div');
        client.className = 'msg client';
        client.textContent = item.q;
        botLogs.appendChild(client);
        botLogs.scrollTop = botLogs.scrollHeight;

        setTimeout(function () {
            var server = doc.createElement('div');
            server.className = 'msg server';
            server.textContent = item.a;
            botLogs.appendChild(server);
            botLogs.scrollTop = botLogs.scrollHeight;
        }, 300);
    }
})();
