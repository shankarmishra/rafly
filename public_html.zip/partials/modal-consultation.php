<?php
/** Consultation modal — previously duplicated inline on every page. */
?>
<div class="modal" id="consultationModal" role="dialog" aria-modal="true" aria-labelledby="consultationTitle" hidden>
    <div class="modal-content">
        <button class="close-modal" data-modal-close aria-label="Close dialog">&times;</button>
        <h2 id="consultationTitle">Get a Free Consultation</h2>
        <p class="muted mb-4">Tell us what you need and we'll come back to you within one business day.</p>

        <form action="/submit" method="POST" id="consultationForm" data-ajax-form="true" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
            <?= lead_context_fields() ?>
            <?php require __DIR__ . '/honeypot.php'; ?>
            <?php require __DIR__ . '/antibot.php'; ?>

            <div class="form-group">
                <label for="modal_contact_name">Your Name</label>
                <input class="form-control" type="text" id="modal_contact_name" name="contact_name" maxlength="120" required autocomplete="name">
            </div>

            <div class="form-group">
                <label for="modal_contact_email">Email</label>
                <input class="form-control" type="email" id="modal_contact_email" name="contact_email" maxlength="255" required autocomplete="email">
            </div>

            <div class="form-group">
                <label for="modal_company_name">Company Name</label>
                <input class="form-control" type="text" id="modal_company_name" name="company_name" maxlength="100" required autocomplete="organization">
            </div>

            <div class="form-group">
                <label for="modal_contact_number">Contact Number</label>
                <input class="form-control" type="tel" id="modal_contact_number" name="contact_number" maxlength="30" required autocomplete="tel">
            </div>

            <div class="form-group">
                <label for="modal_description">What do you need help with?</label>
                <textarea class="form-control" id="modal_description" name="description" maxlength="2000" required></textarea>
            </div>

            <div class="consent-group">
                <input type="checkbox" id="modal_consent" name="consent" required>
                <label for="modal_consent">
                    I agree to the <a href="/privacy" target="_blank" rel="noopener">Privacy Policy</a>
                    and consent to being contacted about my enquiry.
                </label>
            </div>

            <button class="btn-submit" type="submit">Request Consultation</button>
        </form>
    </div>
</div>
