<?php
/**
 * Site header: logo, desktop nav, pricing mega-dropdown, and the mobile drawer.
 * Previously ~65 identical lines duplicated into every page, which is how the
 * insights.php dropdown lost its transition without anyone noticing.
 */

$currentId = $page['id'] ?? '';

/**
 * Bundle packages — rendered in both the mega-dropdown and the mobile drawer.
 * bundles_all() (inc/helpers.php) is DB-backed via admin/bundles.php, with the
 * same BUNDLES const as a fallback, so this and index.php's pricing grid can
 * no longer disagree about what a package includes.
 */
$bundles = bundles_all();
?>
<header id="mainHeader">
    <nav class="navbar" aria-label="Primary">
        <div class="logo">
            <a href="/"><img src="<?= e(asset('assets/logo.png')) ?>" alt="<?= e(SITE_NAME) ?> logo" width="116" height="36"></a>
        </div>

        <ul class="nav-links">
            <li class="nav-item <?= nav_active('about', $currentId) ?>"><a href="/about">About</a></li>

            <li class="nav-item <?= nav_active('services', $currentId) ?>">
                <a href="/#services" aria-haspopup="true" aria-expanded="false">Services</a>
                <ul class="dropdown">
                    <?php foreach (SERVICES as $slug => $label): ?>
                        <li><a href="/<?= e($slug) ?>"><?= e($label) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </li>

            <li class="nav-item pricing-item <?= nav_active('pricing', $currentId) ?>">
                <a href="/#pricing" aria-haspopup="true" aria-expanded="false">Pricing</a>
                <div class="mega-dropdown">
                    <div class="mega-dropdown-inner">
                        <div class="mega-dropdown-head">
                            <p class="mega-dropdown-title">Bundle Packages</p>
                            <p>Pick a starting point — every package is tailored to you during a free consultation.</p>
                        </div>
                        <div class="bundle-grid">
                            <?php foreach ($bundles as $b): ?>
                                <div class="bundle-card <?= $b['featured'] ? 'featured' : '' ?>">
                                    <?php if ($b['featured']): ?><div class="bundle-tag">Most Popular</div><?php endif; ?>
                                    <p class="bundle-name"><?= e($b['name']) ?> Bundle</p>
                                    <div class="bundle-sub"><?= e($b['sub']) ?></div>
                                    <div class="bundle-price"><?= e($b['price_text']) ?></div>
                                    <ul>
                                        <?php foreach ($b['points'] as $p): ?>
                                            <li><?= icon('circle-check') ?> <?= e($p) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <a class="btn-whatsapp-bundle" target="_blank" rel="noopener"
                                       href="<?= e(whatsapp_link("Hi Rafly team! I'm interested in the {$b['name']} Bundle. Could you share an exact quote?")) ?>">
                                        <?= icon('whatsapp', 'icon-fill') ?> Get exact quote
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mega-dropdown-foot">
                            Prefer to talk first? <a href="/#contact">Request a free consultation</a> instead.
                        </div>
                    </div>
                </div>
            </li>

            <li class="nav-item <?= nav_active('insights', $currentId) ?>"><a href="/insights">Insights</a></li>
            <li class="nav-item <?= nav_active('team', $currentId) ?>"><a href="/team">Team</a></li>
            <li class="nav-item <?= nav_active('contact', $currentId) ?>"><a href="/#contact">Contact</a></li>
        </ul>

        <button class="btn-consultation is-desktop-only" data-modal-open="consultationModal">
            Get a Free Consultation
        </button>

        <!-- Mobile trigger. Before this existed, nav links were simply hidden
             under 900px with no replacement — phones had no navigation at all. -->
        <button class="nav-toggle" id="navToggle" aria-expanded="false" aria-controls="mobileDrawer" aria-label="Open menu">
            <span class="nav-toggle-bar"></span>
            <span class="nav-toggle-bar"></span>
            <span class="nav-toggle-bar"></span>
        </button>

        <div class="scroll-progress" id="scrollProgress" aria-hidden="true"></div>
    </nav>
</header>

<div class="mobile-drawer" id="mobileDrawer" hidden>
    <ul class="mobile-nav-list">
        <li style="--i:0"><a href="/about">About</a></li>

        <li style="--i:1">
            <button class="mobile-acc-trigger" aria-expanded="false">
                Services <?= icon('chevron-down') ?>
            </button>
            <div class="mobile-acc-panel"><div>
                <?php foreach (SERVICES as $slug => $label): ?>
                    <a href="/<?= e($slug) ?>"><?= e($label) ?></a>
                <?php endforeach; ?>
            </div></div>
        </li>

        <li style="--i:2">
            <button class="mobile-acc-trigger" aria-expanded="false">
                Pricing <?= icon('chevron-down') ?>
            </button>
            <div class="mobile-acc-panel"><div>
                <?php foreach ($bundles as $b): ?>
                    <a target="_blank" rel="noopener"
                       href="<?= e(whatsapp_link("Hi Rafly team! I'm interested in the {$b['name']} Bundle. Could you share an exact quote?")) ?>">
                        <?= e($b['name']) ?> Bundle<?= $b['featured'] ? ' — Most Popular' : '' ?> — <?= e($b['price_text']) ?>
                    </a>
                <?php endforeach; ?>
                <a href="/pricing">See full pricing</a>
            </div></div>
        </li>

        <?php /* --i drives the drawer's entrance stagger, so these must stay
                 contiguous — inserting here means renumbering everything after. */ ?>
        <li style="--i:3"><a href="/insights">Insights</a></li>
        <li style="--i:4"><a href="/team">Team</a></li>
        <li style="--i:5"><a href="/#contact">Contact</a></li>
    </ul>

    <div class="mobile-drawer-cta">
        <button class="btn-primary" data-modal-open="consultationModal">Get a Free Consultation</button>
        <a class="btn-whatsapp-bundle" target="_blank" rel="noopener"
           href="<?= e(whatsapp_link('Hi Rafly team, I would like to know more about your bundle packages.')) ?>">
            <?= icon('whatsapp', 'icon-fill') ?> Chat on WhatsApp
        </a>
    </div>

    <div class="mobile-drawer-social">
        <?php foreach (SOCIAL_LINKS as $s): ?>
            <a href="<?= e($s['href']) ?>" target="_blank" rel="noopener" aria-label="<?= e($s['label']) ?>">
                <?= icon($s['icon'], 'icon-fill') ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<?php require __DIR__ . '/social-sidebar.php'; ?>
