<?php
/** Shared site footer. Styles live in css/05-footer.css. */
?>
<footer class="site-footer tex-grain is-dark">
    <div class="footer-inner">
        <div class="footer-col footer-brand">
            <div class="footer-logo">
                <a href="/"><img src="<?= e(asset('assets/logo-reversed.png')) ?>" alt="<?= e(SITE_NAME) ?> logo" width="97" height="30"></a>
            </div>
            <p>One partner, one bundled package — web development, content creation, digital marketing, web security, and e-commerce support, all working together instead of stitched together from five different vendors.</p>
            <div class="footer-social">
                <?php foreach (SOCIAL_LINKS as $s): ?>
                    <a href="<?= e($s['href']) ?>" target="_blank" rel="noopener" aria-label="<?= e($s['label']) ?>">
                        <?= icon($s['icon'], 'icon-fill') ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="footer-col">
            <p class="footer-col-title">Quick Links</p>
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="/about">About</a></li>
                <li><a href="/case-studies">Case Studies</a></li>
                <li><a href="/insights">Insights</a></li>
                <li><a href="/team">Team</a></li>
                <li><a href="/#contact">Contact</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <p class="footer-col-title">Services</p>
            <ul>
                <?php foreach (SERVICES as $slug => $label): ?>
                    <li><a href="/<?= e($slug) ?>"><?= e($label) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="footer-col">
            <p class="footer-col-title">Get in Touch</p>
            <ul class="footer-contact">
                <li><?= icon('map-pin') ?><a href="https://maps.google.com/?q=<?= rawurlencode('A523, T3, NX-One, Tech Zone IV, Greater Noida West, 201306') ?>" target="_blank" rel="noopener">A523, T3, NX-One, Tech Zone IV, Greater Noida West, 201306</a></li>
                <li><?= icon('mail') ?><a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a></li>
                <li><?= icon('phone') ?><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', CONTACT_PHONE)) ?>"><?= e(CONTACT_PHONE) ?></a></li>
<?php $hours = setting('contact.hours', ''); if ($hours !== ''): ?>
                <li><?= icon('hourglass') ?><span><?= e($hours) ?></span></li>
<?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> Rafly Digital Growth Partner. All rights reserved.
<?php
/**
 * Real registration numbers, not invented — both settings default to empty
 * (see inc/tools/seed.php) and simply don't render until an admin fills them
 * in via /admin/settings.php. A blank "CIN: " line would look worse than no
 * line at all.
 */
$cin = setting('legal.cin', '');
$gst = setting('legal.gst', '');
if ($cin !== '' || $gst !== ''):
?>
            <span class="footer-legal-ids">
<?php if ($cin !== ''): ?>CIN: <?= e($cin) ?><?php endif; ?>
<?php if ($cin !== '' && $gst !== ''): ?> &middot; <?php endif; ?>
<?php if ($gst !== ''): ?>GST: <?= e($gst) ?><?php endif; ?>
            </span>
<?php endif; ?>
        </p>
        <ul class="footer-legal">
            <li><a href="/privacy">Privacy Policy</a></li>
        </ul>
    </div>
</footer>
