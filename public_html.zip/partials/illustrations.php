<?php
/**
 * Illustrated SVG scenes, drawn in the brand palette.
 *
 * These replace the grey `.placeholder-img` boxes the original used, which
 * rendered as empty grey rectangles with a small icon floating in them.
 * Vector rather than raster: sharp at any size, a few KB each, no licensing
 * question, and recolourable straight from the design tokens.
 */

function illo(string $name): string
{
    ob_start();
    switch ($name) {

    /* --- Challenge 1: disconnected vendors, none talking to each other --- */
    case 'fragmented': ?>
        <svg viewBox="0 0 400 190" role="img" aria-label="Four disconnected vendor systems with broken links between them">
            <defs><linearGradient id="fg1" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#0d47a1"/><stop offset="1" stop-color="#1565c0"/>
            </linearGradient></defs>
            <g stroke="#94a3b8" stroke-width="2" stroke-dasharray="5 6" opacity="0.55">
                <path d="M108 62 L196 62"/><path d="M240 62 L292 96"/>
                <path d="M108 128 L196 128"/><path d="M92 84 L92 108"/>
            </g>
            <ellipse cx="200" cy="158" rx="175" ry="7" fill="#0f172a" opacity="0.08"/>
            <g fill="url(#fg1)">
                <rect class="float-el" x="52" y="40" width="56" height="44" rx="10"/>
                <rect class="float-el" x="196" y="40" width="56" height="44" rx="10" style="animation-delay:.4s"/>
                <rect class="float-el" x="52" y="106" width="56" height="44" rx="10" style="animation-delay:.8s"/>
                <rect class="float-el" x="292" y="86" width="56" height="44" rx="10" style="animation-delay:.2s"/>
            </g>
            <g fill="#fff" opacity="0.9">
                <rect x="64" y="54" width="32" height="4" rx="2"/><rect x="64" y="64" width="20" height="4" rx="2"/>
                <rect x="208" y="54" width="32" height="4" rx="2"/><rect x="208" y="64" width="20" height="4" rx="2"/>
                <rect x="64" y="120" width="32" height="4" rx="2"/><rect x="64" y="130" width="20" height="4" rx="2"/>
                <rect x="304" y="100" width="32" height="4" rx="2"/><rect x="304" y="110" width="20" height="4" rx="2"/>
            </g>
            <circle cx="100" cy="48" r="3" fill="#f59e0b"/>
            <g stroke="#dc2626" stroke-width="2.5" stroke-linecap="round" opacity="0.8">
                <path d="M146 55 L160 69"/><path d="M160 55 L146 69"/>
                <path d="M146 121 L160 135"/><path d="M160 121 L146 135"/>
            </g>
        </svg>
    <?php break;

    /* --- Challenge 2: launches slipping, everyone waiting on someone --- */
    case 'delays': ?>
        <svg viewBox="0 0 400 190" role="img" aria-label="A delivery timeline slipping past its deadline">
            <defs>
                <linearGradient id="dl-a" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
                </linearGradient>
                <linearGradient id="dl-b" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#42a5f5"/><stop offset="1" stop-color="#1565c0"/>
                </linearGradient>
                <linearGradient id="dl-c" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#93c5fd"/><stop offset="1" stop-color="#60a5fa"/>
                </linearGradient>
            </defs>
            <g stroke="#cbd5e1" stroke-width="2"><path d="M40 150 H360"/></g>
            <ellipse cx="180" cy="158" rx="158" ry="7" fill="#0f172a" opacity="0.08"/>
            <g>
                <rect class="float-el" x="48" y="112" width="76" height="22" rx="7" fill="url(#dl-a)"/>
                <rect class="float-el" x="132" y="82" width="94" height="22" rx="7" fill="url(#dl-b)" style="animation-delay:.3s"/>
                <rect class="float-el" x="200" y="52" width="112" height="22" rx="7" fill="url(#dl-c)" style="animation-delay:.6s"/>
            </g>
            <g stroke="#f59e0b" stroke-width="2.5" stroke-dasharray="6 5"><path d="M286 32 V158"/></g>
            <circle cx="286" cy="32" r="5" fill="#f59e0b"/>
            <g fill="#94a3b8" font-size="11" font-family="Inter, sans-serif">
                <text x="296" y="30">deadline</text>
            </g>
            <!-- Positioning transform lives on the outer group; the animation
                 class goes on an inner group. Putting both on one element lets
                 the reduced-motion `transform: none` reset wipe the position. -->
            <g transform="translate(330,104)">
                <g class="float-el" style="animation-delay:.9s">
                    <circle r="21" fill="none" stroke="#0d47a1" stroke-width="3"/>
                    <path d="M0,-12 V0 L9,6" fill="none" stroke="#0d47a1" stroke-width="3" stroke-linecap="round"/>
                </g>
            </g>
        </svg>
    <?php break;

    /* --- Challenge 3: unverified security --- */
    case 'insecure': ?>
        <svg viewBox="0 0 400 190" role="img" aria-label="A shield protecting customer data, with unresolved warnings">
            <defs><linearGradient id="in-a" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
            </linearGradient></defs>
            <ellipse cx="200" cy="163" rx="56" ry="7" fill="#0f172a" opacity="0.08"/>
            <!-- Positioning transforms sit on outer groups so the reduced-motion
                 `transform: none` reset cannot move these to the origin. -->
            <g transform="translate(200,95)"><g class="float-el">
                <path d="M0,-58 L46,-38 V6 C46,36 22,52 0,60 C-22,52 -46,36 -46,6 V-38 Z" fill="url(#in-a)"/>
                <path d="M-16,2 L-4,15 L18,-11" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
            </g></g>
            <g opacity="0.85">
                <g transform="translate(78,58)"><g class="float-el" style="animation-delay:.35s">
                    <circle r="17" fill="#fee2e2"/><path d="M0,-8 V2" stroke="#dc2626" stroke-width="3" stroke-linecap="round"/>
                    <circle cy="7" r="1.8" fill="#dc2626"/>
                </g></g>
                <g transform="translate(316,72)"><g class="float-el" style="animation-delay:.7s">
                    <circle r="15" fill="#fef3c7"/><path d="M0,-7 V1" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
                    <circle cy="6" r="1.6" fill="#f59e0b"/>
                </g></g>
                <g transform="translate(96,140)"><g class="float-el" style="animation-delay:1s">
                    <circle r="13" fill="#fee2e2"/><path d="M0,-6 V1" stroke="#dc2626" stroke-width="2.6" stroke-linecap="round"/>
                    <circle cy="6" r="1.5" fill="#dc2626"/>
                </g></g>
            </g>
        </svg>
    <?php break;

    /* --- Who we are: one coordinated team --- */
    case 'team': ?>
        <svg viewBox="0 0 420 300" role="img" aria-label="One coordinated team working from a shared system">
            <defs>
                <linearGradient id="tm-a" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
                </linearGradient>
                <linearGradient id="tm-b" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#42a5f5"/><stop offset="1" stop-color="#1565c0"/>
                </linearGradient>
            </defs>
            <circle cx="86" cy="72" r="34" fill="url(#tm-a)" opacity="0.10" class="float-el"/>
            <circle cx="344" cy="226" r="46" fill="url(#tm-b)" opacity="0.09" class="float-el" style="animation-delay:1s"/>
            <ellipse cx="209" cy="233" rx="125" ry="7" fill="#0f172a" opacity="0.08"/>
            <g class="float-el" style="animation-delay:.3s"><circle cx="132" cy="140" r="25" fill="url(#tm-a)"/><rect x="107" y="169" width="50" height="58" rx="16" fill="url(#tm-b)"/></g>
            <g class="float-el" style="animation-delay:.6s"><circle cx="208" cy="118" r="30" fill="url(#tm-b)"/><rect x="178" y="153" width="60" height="72" rx="18" fill="url(#tm-a)"/></g>
            <g class="float-el" style="animation-delay:.9s"><circle cx="286" cy="140" r="25" fill="url(#tm-a)"/><rect x="261" y="169" width="50" height="58" rx="16" fill="url(#tm-b)"/></g>
            <g stroke="#38bdf8" stroke-width="2" opacity="0.55" stroke-linecap="round">
                <path d="M157 150 H178"/><path d="M238 150 H261"/>
            </g>
            <circle cx="230" cy="96" r="5" fill="#f59e0b"/>
            <rect x="72" y="243" width="276" height="10" rx="5" fill="#94a3b8" opacity="0.3"/>
        </svg>
    <?php break;

    /* --- Growth chart --- */
    case 'growth': ?>
        <svg viewBox="0 0 340 230" role="img" aria-label="A chart showing steady growth">
            <defs>
                <linearGradient id="gr-a" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stop-color="#93c5fd"/><stop offset="1" stop-color="#60a5fa"/>
                </linearGradient>
                <linearGradient id="gr-b" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stop-color="#42a5f5"/><stop offset="1" stop-color="#1565c0"/>
                </linearGradient>
                <linearGradient id="gr-c" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
                </linearGradient>
            </defs>
            <line x1="24" y1="200" x2="316" y2="200" stroke="#cbd5e1" stroke-width="2"/>
            <ellipse cx="166" cy="208" rx="150" ry="7" fill="#0f172a" opacity="0.08"/>
            <g>
                <rect class="float-el" x="44" y="126" width="36" height="74" rx="7" fill="#bfdbfe"/>
                <rect class="float-el" x="96" y="96" width="36" height="104" rx="7" fill="#93c5fd" style="animation-delay:.2s"/>
                <rect class="float-el" x="148" y="66" width="36" height="134" rx="7" fill="url(#gr-a)" style="animation-delay:.4s"/>
                <rect class="float-el" x="200" y="36" width="36" height="164" rx="7" fill="url(#gr-b)" style="animation-delay:.6s"/>
                <rect class="float-el" x="252" y="80" width="36" height="120" rx="7" fill="url(#gr-c)" style="animation-delay:.8s"/>
            </g>
            <polyline class="draw-path" points="62,140 114,104 166,78 218,48 270,92" fill="none"
                      stroke="#38bdf8" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
            <g fill="#38bdf8">
                <circle cx="62" cy="140" r="4"/><circle cx="114" cy="104" r="4"/><circle cx="166" cy="78" r="4"/>
                <circle cx="218" cy="48" r="4" fill="#f59e0b"/><circle cx="270" cy="92" r="4"/>
            </g>
        </svg>
    <?php break;

    /* --- Orbit system for the dark feature panel --- */
    case 'orbit': ?>
        <svg viewBox="0 0 300 240" role="img" aria-label="Five services orbiting one coordinated core">
            <defs><linearGradient id="or-a" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
            </linearGradient></defs>
            <g fill="none" stroke="#38bdf8" stroke-opacity="0.22" stroke-width="1.5">
                <ellipse cx="150" cy="120" rx="120" ry="52"/>
                <ellipse cx="150" cy="120" rx="120" ry="52" transform="rotate(60 150 120)"/>
                <ellipse cx="150" cy="120" rx="120" ry="52" transform="rotate(-60 150 120)"/>
            </g>
            <ellipse cx="150" cy="158" rx="36" ry="7" fill="#0f172a" opacity="0.08"/>
            <circle cx="150" cy="120" r="30" fill="url(#or-a)"/>
            <circle cx="150" cy="120" r="30" fill="none" stroke="#38bdf8" stroke-width="2" opacity="0.8"/>
            <circle cx="150" cy="120" r="46" fill="none" stroke="#7dd3fc" stroke-width="1" opacity="0.3" class="float-el"/>
            <g fill="#38bdf8">
                <circle class="float-el" cx="270" cy="120" r="8" fill="#f59e0b"/>
                <circle class="float-el" cx="90" cy="16" r="8" style="animation-delay:.4s"/>
                <circle class="float-el" cx="210" cy="224" r="8" style="animation-delay:.8s"/>
                <circle class="float-el" cx="30" cy="120" r="8" style="animation-delay:1.2s"/>
                <circle class="float-el" cx="210" cy="16" r="8" style="animation-delay:1.6s"/>
            </g>
        </svg>
    <?php break;

    /* --- Generic case-study cover; $variant tints it --- */
    case 'work-cover':
        /* This scene renders once per work card, so several copies can share a
           page. The counter suffixes the gradient IDs to keep them unique. */
        static $wcN = 0;
        $wcN++; ?>
        <svg viewBox="0 0 400 190" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Project preview">
            <defs>
                <linearGradient id="wc-a<?= $wcN ?>" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#42a5f5"/><stop offset="1" stop-color="#1565c0"/>
                </linearGradient>
                <linearGradient id="wc-b<?= $wcN ?>" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#1565c0"/><stop offset="1" stop-color="#0d47a1"/>
                </linearGradient>
                <linearGradient id="wc-c<?= $wcN ?>" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#7dd3fc"/><stop offset="1" stop-color="#38bdf8"/>
                </linearGradient>
            </defs>
            <rect width="400" height="190" fill="#eaf3ff"/>
            <ellipse cx="200" cy="166" rx="170" ry="7" fill="#0f172a" opacity="0.08"/>
            <g opacity="0.9">
                <rect x="30" y="28" width="150" height="10" rx="5" fill="#0d47a1" opacity="0.55"/>
                <rect x="30" y="48" width="96" height="8" rx="4" fill="#94a3b8" opacity="0.6"/>
                <rect x="30" y="82" width="118" height="76" rx="10" fill="url(#wc-a<?= $wcN ?>)" opacity="0.18"/>
                <rect x="160" y="82" width="118" height="76" rx="10" fill="url(#wc-b<?= $wcN ?>)" opacity="0.28"/>
                <rect x="290" y="82" width="80" height="76" rx="10" fill="url(#wc-c<?= $wcN ?>)" opacity="0.35"/>
                <polyline points="40,140 80,116 120,126 160,96 200,108 240,74 280,90 320,58"
                          fill="none" stroke="#0d47a1" stroke-width="3" stroke-linecap="round" opacity="0.5"/>
                <circle cx="320" cy="58" r="4" fill="#f59e0b"/>
            </g>
        </svg>
    <?php break;
    }

    return (string)ob_get_clean();
}
