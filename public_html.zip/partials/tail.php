<?php
/** Closes the document: modal, footer, scripts. */
?>
<?php
/* No `hidden` attribute here: .to-top is shown/hidden with visibility, which
   already removes it from the tab order AND lets the fade transition run.
   `hidden` was inert anyway — the UA [hidden] rule loses to the `display: flex`
   in 07-utilities.css, so it looked like a control that did nothing. */
?>
    <button class="to-top" id="toTop" type="button" aria-label="Back to top">
        <?= icon('arrow-up') ?>
    </button>

    <?php
    /* Below 900px the header's "Get a Free Consultation" button is hidden
       (.is-desktop-only) and the social rail is hidden below 768px, so a
       phone visitor scrolling a long page has no persistent way to convert.
       This bar fills that gap; it hides itself while the drawer or a modal
       is open (see 04-nav.css) so it never fights either overlay. */
    ?>
    <div class="mobile-sticky-cta">
        <button type="button" class="btn-primary" data-modal-open="consultationModal">Book a free consultation</button>
        <a class="mobile-sticky-whatsapp" target="_blank" rel="noopener"
           href="<?= e(whatsapp_link('Hi Rafly team, I would like to know more about your bundle packages.')) ?>"
           aria-label="Chat with us on WhatsApp">
            <?= icon('whatsapp', 'icon-fill') ?>
        </a>
    </div>

    <div class="toast-stack" id="toastStack" role="status" aria-live="polite" aria-atomic="false"></div>

<?php
require __DIR__ . '/modal-consultation.php';
require __DIR__ . '/footer.php';
?>

    <script src="<?= e(asset('js/motion.js')) ?>" defer></script>
    <script src="<?= e(asset('js/app.js')) ?>" defer></script>
<?php foreach (($page['scripts'] ?? []) as $s): ?>
    <script src="<?= e(asset("js/pages/{$s}.js")) ?>" defer></script>
<?php endforeach; ?>
</body>
</html>
