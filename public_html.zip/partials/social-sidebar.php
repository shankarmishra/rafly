<?php
/** Floating social rail. Hidden below 768px — the links live in the mobile drawer. */
?>
<div class="social-sidebar" aria-label="Social links">
    <?php foreach (SOCIAL_LINKS as $s): ?>
        <a class="sidebar-icon s-<?= e($s['key']) ?>"
           href="<?= e($s['href']) ?>"
           target="_blank" rel="noopener"
           aria-label="<?= e($s['label']) ?>">
            <?= icon($s['icon'], 'icon-fill') ?>
        </a>
    <?php endforeach; ?>
</div>
